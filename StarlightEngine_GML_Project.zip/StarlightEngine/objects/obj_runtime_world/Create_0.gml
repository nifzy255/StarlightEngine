/// @description ST★RLIGHT ENGINE - Runtime World Controller Object
// Delegated through scene_update() and scene_draw_gui() when ENGINE_SCENE.RUNTIME_PLAY is active.
runtime_init_state();
