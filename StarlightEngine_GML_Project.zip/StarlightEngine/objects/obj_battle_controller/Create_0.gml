/// @description ST★RLIGHT ENGINE - Battle Controller Object
// Delegated through scene_update() and scene_draw_gui() when ENGINE_SCENE.RUNTIME_BATTLE is active.
battle_init_state();
