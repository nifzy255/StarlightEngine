/// @description ST★RLIGHT ENGINE - Editor Controller Object
// Delegated through scene_update() and scene_draw_gui() when ENGINE_SCENE.EDITOR is active.
editor_init_state();
