/// @description ST★RLIGHT ENGINE Master Controller - Create Event
starlight_engine_boot();
