/// @description ST★RLIGHT ENGINE Master Controller - CleanUp Event
core_assets_clear_cache();
core_audio_cleanup_streams();
