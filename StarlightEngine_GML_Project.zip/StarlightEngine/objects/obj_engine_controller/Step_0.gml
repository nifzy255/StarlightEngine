/// @description ST★RLIGHT ENGINE Master Controller - Step Event
global.engine.frame_counter++;
core_input_update();
scene_update();
