/// @description ST★RLIGHT ENGINE Master Controller - Draw GUI Event
scene_draw_gui();
