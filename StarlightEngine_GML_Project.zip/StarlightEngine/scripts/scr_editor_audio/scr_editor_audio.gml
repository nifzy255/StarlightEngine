/// @description ST★RLIGHT ENGINE - Audio Manager & Default UI Sound Import Helpers
/// Imports OGG music and SFX, allows custom Audio IDs, previews tracks, configures looping & volume, and assigns map BGM.

function editor_audio_import_ogg(_is_music) {
    var _src = get_open_filename("OGG Vorbis Audio (*.ogg)|*.ogg", "");
    if (_src == "" || !file_exists(_src)) return false;
    
    var _fname = filename_name(_src);
    var _rel = "audio/" + _fname;
    if (global.project_path != "") {
        directory_create(global.project_path + "audio/");
        file_copy(_src, global.project_path + _rel);
    }
    
    var _nid = (_is_music ? "bgm_" : "sfx_") + string(array_length(global.project.audio) + 1);
    array_push(global.project.audio, {
        id: _nid,
        name: _fname,
        type: _is_music ? "music" : "sfx",
        file_path: _rel,
        volume: 0.85,
        loop: _is_music
    });
    global.project_dirty = true;
    core_log_toast("Imported OGG " + (_is_music ? "Music" : "SFX") + ": " + _fname);
    return true;
}

/// @function editor_audio_import_default_category_ogg(_event_key)
/// @description Imports or replaces a custom .ogg sound effect for one of the 23 Project-Wide Default Sound Categories.
function editor_audio_import_default_category_ogg(_event_key) {
    if (is_undefined(global.project) || !is_struct(global.project)) return false;
    core_audio_normalize_project_sounds(global.project);
    if (!variable_struct_exists(global.project.default_sounds, _event_key)) return false;
    
    var _src = get_open_filename("OGG Vorbis Sound Effect (*.ogg)|*.ogg", "");
    if (_src == "" || !file_exists(_src)) return false;
    
    var _fname = filename_name(_src);
    var _rel = "audio/ui_" + _event_key + "_" + _fname;
    if (global.project_path != "") {
        directory_create(global.project_path + "audio/");
        file_copy(_src, global.project_path + _rel);
    } else {
        _rel = _src;
    }
    
    var _cfg = variable_struct_get(global.project.default_sounds, _event_key);
    _cfg.file_path = _rel;
    _cfg.name = _fname;
    _cfg.enabled = true;
    
    // Also register or update in global.project.audio for central tracking
    var _aid = "sfx_def_" + _event_key;
    _cfg.audio_id = _aid;
    var _found = false;
    for (var i = 0; i < array_length(global.project.audio); i++) {
        if (global.project.audio[i].id == _aid) {
            global.project.audio[i].name = _fname;
            global.project.audio[i].file_path = _rel;
            global.project.audio[i].volume = _cfg.volume;
            _found = true;
            break;
        }
    }
    if (!_found) {
        array_push(global.project.audio, {
            id: _aid,
            name: _fname,
            type: "sfx",
            file_path: _rel,
            volume: _cfg.volume,
            loop: false
        });
    }
    
    // Clear cached stream for this key so replacement plays immediately
    var _cache_id = "def_sfx__" + _event_key + "__" + _rel;
    if (variable_struct_exists(global.audio.stream_cache, _cache_id)) {
        variable_struct_remove(global.audio.stream_cache, _cache_id);
    }
    if (variable_struct_exists(global.audio.stream_cache, _aid)) {
        variable_struct_remove(global.audio.stream_cache, _aid);
    }
    
    global.project_dirty = true;
    core_audio_preview_default_sound(_event_key);
    core_log_toast("Assigned '" + _fname + "' to " + _event_key);
    return true;
}

/// @function editor_audio_remove_default_category_ogg(_event_key)
/// @description Removes the custom .ogg assigned to a default sound category, restoring the built-in default sound.
function editor_audio_remove_default_category_ogg(_event_key) {
    if (is_undefined(global.project) || !is_struct(global.project)) return false;
    core_audio_normalize_project_sounds(global.project);
    if (!variable_struct_exists(global.project.default_sounds, _event_key)) return false;
    
    var _cfg = variable_struct_get(global.project.default_sounds, _event_key);
    _cfg.file_path = "";
    _cfg.audio_id = "";
    _cfg.name = "Built-In Default";
    global.project_dirty = true;
    core_log_toast("Restored built-in default sound for " + _event_key);
    return true;
}

function editor_audio_draw_modal(_map) {
    var _ed = global.editor;
    var _pal = global.palette;
    var _audio_list = global.project.audio;
    
    render_window_frame(110, 44, 1170, 676, "AUDIO MANAGER — OGG MUSIC & SOUND EFFECTS", _pal.accent_gold);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    if (render_ui_button(136, 86, 396, 126, "+ Import OGG Music Track...", false, true)) {
        editor_audio_import_ogg(true);
    }
    if (render_ui_button(408, 86, 668, 126, "+ Import OGG Sound Effect...", false, true)) {
        editor_audio_import_ogg(false);
    }
    if (render_ui_button(680, 86, 840, 126, "Pause Preview", false, true)) {
        core_audio_pause_music();
    }
    if (render_ui_button(850, 86, 990, 126, "Resume", false, true)) {
        core_audio_resume_music();
    }
    if (render_ui_button(1000, 86, 1140, 126, "Stop", false, true)) {
        core_audio_stop_music();
    }
    
    if (is_struct(_map)) {
        draw_set_color(_pal.accent_cyan);
        draw_text(136, 140, "Active Map (" + _map.name + ") Assigned BGM ID: " + (_map.bgm_id != "" ? _map.bgm_id : "None"));
    }
    
    if (array_length(_audio_list) == 0) {
        draw_set_color(_pal.text_secondary);
        draw_text(136, 196, "No audio tracks imported yet. Click '+ Import OGG Music Track' above.");
    } else {
        var _max_vis = min(5, array_length(_audio_list));
        for (var i = 0; i < _max_vis; i++) {
            var _a = _audio_list[i];
            var _ay1 = 176 + i * 82;
            var _ay2 = _ay1 + 74;
            
            draw_set_color(_pal.panel_alt);
            draw_rectangle(136, _ay1, 1140, _ay2, false);
            draw_set_color(_pal.border_inner);
            draw_rectangle(136, _ay1, 1140, _ay2, true);
            
            draw_set_color(_pal.accent_gold);
            draw_text(148, _ay1 + 10, "[" + string_upper(_a.type) + "] ID:");
            render_ui_custom_id_field("aud_cid_" + string(i), "audio", _a, 272, _ay1 + 4, 468, _ay1 + 36);
            
            draw_set_color(_pal.text_secondary);
            draw_text(478, _ay1 + 10, "Name:");
            _a.name = render_ui_text_field("aud_name_" + string(i), 542, _ay1 + 4, 718, _ay1 + 36, _a.name, 40);
            
            if (render_ui_button(726, _ay1 + 4, 842, _ay1 + 36, "Vol: " + string(round(_a.volume * 100)) + "%", false, true)) {
                _a.volume = (_a.volume >= 1.0) ? 0.25 : clamp(_a.volume + 0.25, 0.0, 1.0);
                global.project_dirty = true;
            }
            if (render_ui_button(850, _ay1 + 4, 966, _ay1 + 36, "Loop: " + (_a.loop ? "ON" : "OFF"), _a.loop, true)) {
                _a.loop = !_a.loop;
                global.project_dirty = true;
            }
            if (render_ui_button(974, _ay1 + 4, 1058, _ay1 + 36, "▶ Play", false, true)) {
                if (_a.type == "music") core_audio_start_music(_a.id, _a.loop);
                else core_audio_play_sfx(_a.id);
            }
            if (render_ui_button(1066, _ay1 + 4, 1132, _ay1 + 36, "Del", false, true)) {
                array_delete(_audio_list, i, 1);
                global.project_dirty = true;
                return;
            }
            
            draw_set_color(_pal.text_secondary);
            draw_text(148, _ay1 + 44, "File: " + render_fit_text(_a.file_path, 680));
            if (is_struct(_map) && _a.type == "music") {
                if (render_ui_button(870, _ay1 + 40, 1132, _ay1 + 68, "Assign to Active Map", (_map.bgm_id == _a.id), true)) {
                    _map.bgm_id = _a.id;
                    global.project_dirty = true;
                    core_log_toast("Assigned " + _a.name + " to " + _map.name);
                }
            }
        }
    }
    
    if (render_ui_button(136, 620, 496, 660, "Default UI & Gameplay Sounds (F1)...", false, true)) {
        input_end_text_edit();
        _ed.pm_tab_idx = 1;
        _ed.active_modal = EDITOR_MODAL.PROJECT_MANAGER;
        return;
    }
    
    if (render_ui_button(940, 620, 1140, 660, "Done (Esc)", true, true)) {
        input_end_text_edit();
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}
