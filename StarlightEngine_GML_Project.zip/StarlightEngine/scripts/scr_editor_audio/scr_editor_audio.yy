{
  "$GMScript": "v1",
  "%Name": "scr_editor_audio",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_editor_audio",
  "parent": {
    "name": "Editor",
    "path": "folders/Engine/Editor.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}