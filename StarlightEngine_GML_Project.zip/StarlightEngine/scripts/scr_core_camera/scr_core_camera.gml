/// @description ST★RLIGHT ENGINE - Dual Independent Camera & Aspect Ratio System
/// Separates the Editor Map Camera (WASD + Zoom) from the Runtime Player Camera (16:9 or 8:7).

function core_camera_init() {
    global.camera = {
        editor: {
            x: 0,
            y: 0,
            target_x: 0,
            target_y: 0,
            zoom: 1.0,
            target_zoom: 1.0,
            min_zoom: 0.5,
            max_zoom: 3.0,
            pan_speed: 10.0,
            viewport_x: 190,
            viewport_y: 44,
            viewport_w: 820,
            viewport_h: 636
        },
        runtime: {
            x: 0,
            y: 0,
            target_x: 0,
            target_y: 0,
            zoom: 2.0,
            shake_timer: 0,
            shake_magnitude: 0,
            viewport_x: 0,
            viewport_y: 0,
            viewport_w: STARLIGHT_BASE_WIDTH,
            viewport_h: STARLIGHT_BASE_HEIGHT
        }
    };
}

/// @function camera_runtime_sync_aspect_ratio()
/// @description Updates runtime camera viewport bounds for 16:9 Widescreen or 8:7 Classic EarthBound mode.
function camera_runtime_sync_aspect_ratio() {
    var _cam = global.camera.runtime;
    var _aspect = (!is_undefined(global.project) && variable_struct_exists(global.project, "aspect_ratio"))
        ? global.project.aspect_ratio : "16:9";
        
    if (_aspect == "8:7") {
        // 8:7 Classic SNES / EarthBound aspect ratio at 720p height = 824x720 centered
        _cam.viewport_w = 824;
        _cam.viewport_h = STARLIGHT_BASE_HEIGHT;
        _cam.viewport_x = 228;
        _cam.viewport_y = 0;
    } else {
        // 16:9 Standard Widescreen (1280x720)
        _cam.viewport_w = STARLIGHT_BASE_WIDTH;
        _cam.viewport_h = STARLIGHT_BASE_HEIGHT;
        _cam.viewport_x = 0;
        _cam.viewport_y = 0;
    }
}

/// @function runtime_draw_aspect_frame()
/// @description Draws clean retro pillarbox framing when the project is configured for 8:7 aspect ratio.
function runtime_draw_aspect_frame() {
    camera_runtime_sync_aspect_ratio();
    var _cam = global.camera.runtime;
    if (_cam.viewport_x <= 0) return;
    
    var _pal = global.palette;
    var _lx2 = _cam.viewport_x;
    var _rx1 = _cam.viewport_x + _cam.viewport_w;
    
    // Left and right non-stretched retro pillarbox regions
    draw_set_color(make_color_rgb(4, 5, 14));
    draw_rectangle(0, 0, _lx2 - 1, STARLIGHT_BASE_HEIGHT, false);
    draw_rectangle(_rx1 + 1, 0, STARLIGHT_BASE_WIDTH, STARLIGHT_BASE_HEIGHT, false);
    
    // Subtle decorative retro bezel lines
    draw_set_color(_pal.border_inner);
    draw_line(_lx2 - 4, 0, _lx2 - 4, STARLIGHT_BASE_HEIGHT);
    draw_line(_rx1 + 4, 0, _rx1 + 4, STARLIGHT_BASE_HEIGHT);
    draw_set_color(_pal.border_outer);
    draw_line(_lx2 - 1, 0, _lx2 - 1, STARLIGHT_BASE_HEIGHT);
    draw_line(_rx1 + 1, 0, _rx1 + 1, STARLIGHT_BASE_HEIGHT);
}

/// @function camera_editor_update(_map_pixel_w, _map_pixel_h, _allow_input)
/// @description Updates the Editor camera independently of gameplay.
function camera_editor_update(_map_pixel_w, _map_pixel_h, _allow_input) {
    var _cam = global.camera.editor;
    
    if (_allow_input && !global.input.text_input_active) {
        var _spd = _cam.pan_speed / max(0.5, _cam.zoom);
        if (keyboard_check(vk_shift)) _spd *= 1.8;
        
        var _ctrl = keyboard_check(vk_control);
        if (!_ctrl) {
            var _dx = (keyboard_check(ord("D")) ? 1 : 0) - (keyboard_check(ord("A")) ? 1 : 0);
            var _dy = (keyboard_check(ord("S")) ? 1 : 0) - (keyboard_check(ord("W")) ? 1 : 0);
            _cam.target_x += _dx * _spd;
            _cam.target_y += _dy * _spd;
        }
        
        // Zoom via mouse wheel when hovering inside the map canvas
        if (input_mouse_in_rect(_cam.viewport_x, _cam.viewport_y,
            _cam.viewport_x + _cam.viewport_w, _cam.viewport_y + _cam.viewport_h)) {
            if (global.input.wheel_up) {
                _cam.target_zoom = clamp(_cam.target_zoom + 0.25, _cam.min_zoom, _cam.max_zoom);
            } else if (global.input.wheel_down) {
                _cam.target_zoom = clamp(_cam.target_zoom - 0.25, _cam.min_zoom, _cam.max_zoom);
            }
        }
    }
    
    _cam.zoom = lerp(_cam.zoom, _cam.target_zoom, 0.25);
    
    // Respect map boundaries with comfortable editor margin
    var _margin = 160;
    var _min_x = -_margin;
    var _min_y = -_margin;
    var _max_x = max(_min_x, _map_pixel_w - (_cam.viewport_w / _cam.zoom) + _margin);
    var _max_y = max(_min_y, _map_pixel_h - (_cam.viewport_h / _cam.zoom) + _margin);
    
    _cam.target_x = clamp(_cam.target_x, _min_x, _max_x);
    _cam.target_y = clamp(_cam.target_y, _min_y, _max_y);
    
    _cam.x = lerp(_cam.x, _cam.target_x, 0.28);
    _cam.y = lerp(_cam.y, _cam.target_y, 0.28);
}

function camera_editor_screen_to_world_x(_screen_x) {
    var _cam = global.camera.editor;
    return _cam.x + ((_screen_x - _cam.viewport_x) / _cam.zoom);
}

function camera_editor_screen_to_world_y(_screen_y) {
    var _cam = global.camera.editor;
    return _cam.y + ((_screen_y - _cam.viewport_y) / _cam.zoom);
}

function camera_editor_world_to_screen_x(_world_x) {
    var _cam = global.camera.editor;
    return _cam.viewport_x + ((_world_x - _cam.x) * _cam.zoom);
}

function camera_editor_world_to_screen_y(_world_y) {
    var _cam = global.camera.editor;
    return _cam.viewport_y + ((_world_y - _cam.y) * _cam.zoom);
}

/// @function camera_runtime_update(_focus_x, _focus_y, _map_pixel_w, _map_pixel_h, _snap_immediate)
/// @description Updates the Playable Runtime camera following the player within map bounds and aspect ratio.
function camera_runtime_update(_focus_x, _focus_y, _map_pixel_w, _map_pixel_h, _snap_immediate) {
    camera_runtime_sync_aspect_ratio();
    var _cam = global.camera.runtime;
    var _view_w = _cam.viewport_w / _cam.zoom;
    var _view_h = _cam.viewport_h / _cam.zoom;
    
    var _tx = _focus_x - (_view_w * 0.5);
    var _ty = _focus_y - (_view_h * 0.5);
    
    if (_map_pixel_w > _view_w) {
        _tx = clamp(_tx, 0, _map_pixel_w - _view_w);
    } else {
        _tx = (_map_pixel_w - _view_w) * 0.5;
    }
    
    if (_map_pixel_h > _view_h) {
        _ty = clamp(_ty, 0, _map_pixel_h - _view_h);
    } else {
        _ty = (_map_pixel_h - _view_h) * 0.5;
    }
    
    _cam.target_x = _tx;
    _cam.target_y = _ty;
    
    if (_snap_immediate) {
        _cam.x = _tx;
        _cam.y = _ty;
    } else {
        _cam.x = lerp(_cam.x, _tx, 0.22);
        _cam.y = lerp(_cam.y, _ty, 0.22);
    }
    
    if (_cam.shake_timer > 0) {
        _cam.shake_timer--;
    }
}

function camera_runtime_trigger_shake(_frames, _magnitude) {
    global.camera.runtime.shake_timer = _frames;
    global.camera.runtime.shake_magnitude = _magnitude;
}
