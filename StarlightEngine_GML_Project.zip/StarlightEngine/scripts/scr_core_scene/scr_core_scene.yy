{
  "$GMScript": "v1",
  "%Name": "scr_core_scene",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_core_scene",
  "parent": {
    "name": "Core",
    "path": "folders/Engine/Core.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}