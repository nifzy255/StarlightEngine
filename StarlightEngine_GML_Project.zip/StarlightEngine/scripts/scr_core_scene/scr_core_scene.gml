/// @description ST★RLIGHT ENGINE - Scene Management & Front-End Menus
/// Controls Main Menu, Projects Menu (New, Saved, Import, Delete Confirm), Settings, and Credits.

function core_scene_init() {
    global.scene = {
        current: ENGINE_SCENE.MAIN_MENU,
        previous: ENGINE_SCENE.MAIN_MENU,
        main_menu_index: 0,
        projects_submenu: PROJECTS_SUBMENU.ROOT,
        projects_menu_index: 0,
        saved_projects_list: [],
        saved_scroll_offset: 0,
        selected_project_idx: 0,
        delete_target_project: undefined,
        import_pending_data: undefined,
        import_pending_source: "",
        
        // New Project form fields
        new_proj_name: "My Starlight RPG",
        new_proj_author: "Creator",
        new_proj_desc: "An EarthBound-inspired 16-bit adventure.",
        new_proj_field_idx: 0,
        
        // Settings menu index
        settings_index: 0,
        
        // Screen fade overlay
        fade_alpha: 0.0,
        fade_target: 0.0,
        fade_speed: 0.08,
        fade_color: c_black
    };
}

function scene_switch_to(_target_scene) {
    input_end_text_edit();
    input_consume_all();
    global.scene.previous = global.scene.current;
    global.scene.current = _target_scene;
    
    if (_target_scene == ENGINE_SCENE.PROJECTS_MENU) {
        global.scene.projects_submenu = PROJECTS_SUBMENU.ROOT;
        global.scene.projects_menu_index = 0;
        global.scene.saved_projects_list = core_saveload_scan_projects();
    }
}

function scene_update() {
    // Always animate the outer-space starfield while in menus
    if (global.scene.current == ENGINE_SCENE.MAIN_MENU ||
        global.scene.current == ENGINE_SCENE.PROJECTS_MENU ||
        global.scene.current == ENGINE_SCENE.SETTINGS_MENU ||
        global.scene.current == ENGINE_SCENE.CREDITS_MENU) {
        core_starfield_update();
    }
    
    // Update screen fade
    if (global.scene.fade_alpha != global.scene.fade_target) {
        global.scene.fade_alpha = lerp(global.scene.fade_alpha, global.scene.fade_target, global.scene.fade_speed);
        if (abs(global.scene.fade_alpha - global.scene.fade_target) < 0.01) {
            global.scene.fade_alpha = global.scene.fade_target;
        }
    }
    
    switch (global.scene.current) {
        case ENGINE_SCENE.MAIN_MENU:
            scene_update_main_menu();
            break;
        case ENGINE_SCENE.PROJECTS_MENU:
            scene_update_projects_menu();
            break;
        case ENGINE_SCENE.SETTINGS_MENU:
            scene_update_settings_menu();
            break;
        case ENGINE_SCENE.CREDITS_MENU:
            scene_update_credits_menu();
            break;
        case ENGINE_SCENE.EDITOR:
            editor_update();
            break;
        case ENGINE_SCENE.RUNTIME_PLAY:
            runtime_update();
            break;
        case ENGINE_SCENE.RUNTIME_BATTLE:
            battle_update();
            break;
        case ENGINE_SCENE.GAME_OVER:
            gameover_update();
            break;
    }
}

function scene_draw_gui() {
    draw_set_font(fnt_starlight_ui);
    switch (global.scene.current) {
        case ENGINE_SCENE.MAIN_MENU:
            scene_draw_main_menu();
            break;
        case ENGINE_SCENE.PROJECTS_MENU:
            scene_draw_projects_menu();
            break;
        case ENGINE_SCENE.SETTINGS_MENU:
            scene_draw_settings_menu();
            break;
        case ENGINE_SCENE.CREDITS_MENU:
            scene_draw_credits_menu();
            break;
        case ENGINE_SCENE.EDITOR:
            editor_draw_gui();
            break;
        case ENGINE_SCENE.RUNTIME_PLAY:
            runtime_draw_gui();
            break;
        case ENGINE_SCENE.RUNTIME_BATTLE:
            battle_draw_gui();
            break;
        case ENGINE_SCENE.GAME_OVER:
            gameover_draw_gui();
            break;
    }
    
    // Draw fade transition overlay if active
    if (global.scene.fade_alpha > 0.01) {
        draw_set_alpha(global.scene.fade_alpha);
        draw_set_color(global.scene.fade_color);
        draw_rectangle(0, 0, STARLIGHT_BASE_WIDTH, STARLIGHT_BASE_HEIGHT, false);
        draw_set_alpha(1.0);
    }
    
    // Draw diagnostic/notification toast overlay on top of everything
    core_error_draw_toasts();
}

// ============================================================================
// MAIN MENU
// ============================================================================

function scene_update_main_menu() {
    if (global.input.key_consumed) return;
    
    if (global.input.nav_up) {
        global.scene.main_menu_index = (global.scene.main_menu_index + 3) mod 4;
        core_audio_play_sfx_ui("ui_move");
    } else if (global.input.nav_down) {
        global.scene.main_menu_index = (global.scene.main_menu_index + 1) mod 4;
        core_audio_play_sfx_ui("ui_move");
    } else if (global.input.nav_confirm) {
        core_audio_play_sfx_ui("ui_select");
        scene_activate_main_menu_option(global.scene.main_menu_index);
    }
}

function scene_activate_main_menu_option(_index) {
    switch (_index) {
        case 0:
            scene_switch_to(ENGINE_SCENE.PROJECTS_MENU);
            break;
        case 1:
            scene_switch_to(ENGINE_SCENE.SETTINGS_MENU);
            break;
        case 2:
            scene_switch_to(ENGINE_SCENE.CREDITS_MENU);
            break;
        case 3:
            core_config_save();
            game_end();
            break;
    }
}

function scene_draw_main_menu() {
    render_starfield_bg();
    var _pal = global.palette;
    
    // Upper-left Title Block
    var _tx = 72;
    var _ty = 68;
    
    draw_set_font(fnt_starlight_title);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    // Pixel shadow
    draw_set_color(c_black);
    draw_text(_tx + 3, _ty + 3, STARLIGHT_ENGINE_NAME);
    
    // Main title
    draw_set_color(_pal.accent_gold);
    draw_text(_tx, _ty, STARLIGHT_ENGINE_NAME);
    
    draw_set_font(fnt_starlight_ui);
    draw_set_color(_pal.accent_cyan);
    draw_text(_tx + 2, _ty + 44, "16-BIT EARTHBOUND-INSPIRED 2D RPG CREATION ENGINE");
    
    // Buttons placed directly underneath the title
    var _labels = ["Projects", "Settings", "Credits", "Exit"];
    var _bx1 = 72;
    var _bx2 = 352;
    var _by_start = 160;
    var _bh = 48;
    var _bgap = 16;
    
    for (var i = 0; i < 4; i++) {
        var _by1 = _by_start + i * (_bh + _bgap);
        var _by2 = _by1 + _bh;
        if (input_mouse_in_rect(_bx1, _by1, _bx2, _by2)) {
            global.scene.main_menu_index = i;
        }
        if (render_ui_button(_bx1, _by1, _bx2, _by2, _labels[i], (global.scene.main_menu_index == i), true)) {
            scene_activate_main_menu_option(i);
            return;
        }
    }
    
    // Right-side Engine Info / Quick Status Card
    render_window_frame(440, 160, 1190, 580, "ENGINE OVERVIEW & QUICK GUIDE", _pal.border_outer);
    draw_set_color(_pal.text_primary);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_text(468, 212, "Welcome to ST★RLIGHT ENGINE v" + STARLIGHT_VERSION_STRING);
    draw_set_color(_pal.text_secondary);
    draw_text(468, 244, "• Build complete 16-bit RPGs without writing GML code.");
    draw_text(468, 272, "• Visual Map, Collision, Multi-Layer Tile, Event, Object, NPC, and Enemy Editors.");
    draw_text(468, 300, "• Built-in Character, Item, Variable, Sprite Animation, and OGG Audio Managers.");
    draw_text(468, 328, "• Customizable EarthBound-inspired turn-based Battle System with rolling HP.");
    draw_text(468, 356, "• Includes playable regression-test RPG: 'Starfall Valley Demo' in Saved Projects.");
    
    draw_set_color(_pal.accent_gold);
    draw_text(468, 412, "KEYBOARD & EDITOR CONTROLS:");
    draw_set_color(_pal.text_secondary);
    draw_text(468, 440, "• Menus: Arrow Keys / WASD + Z / Enter to Confirm, X / Esc to Return.");
    draw_text(468, 468, "• Editor: WASD pans Map Camera | Z toggles Place/Erase | Right-Click inspects.");
    draw_text(468, 496, "• Editor: Ctrl+Z Undo | Ctrl+Y Redo | F1 Project Manager | F4 Fullscreen.");
    draw_text(468, 524, "• Runtime: Z / Enter Interact | X Cancel | C / Esc Game Menu | F4 Fullscreen.");
    
    // Footer version badge
    draw_set_color(_pal.text_muted);
    draw_text(72, STARLIGHT_BASE_HEIGHT - 36, "BUILD v" + STARLIGHT_VERSION_STRING + "  |  MODULAR DATA-DRIVEN ARCHITECTURE");
}

// ============================================================================
// PROJECTS MENU (Root, New Project, Saved Projects, Import, Delete Confirm)
// ============================================================================

function scene_update_projects_menu() {
    if (global.input.key_consumed) return;
    
    switch (global.scene.projects_submenu) {
        case PROJECTS_SUBMENU.ROOT:
            if (global.input.nav_cancel) {
                core_audio_play_sfx_ui("ui_cancel");
                scene_switch_to(ENGINE_SCENE.MAIN_MENU);
                return;
            }
            if (global.input.nav_up) {
                global.scene.projects_menu_index = (global.scene.projects_menu_index + 3) mod 4;
                core_audio_play_sfx_ui("ui_move");
            } else if (global.input.nav_down) {
                global.scene.projects_menu_index = (global.scene.projects_menu_index + 1) mod 4;
                core_audio_play_sfx_ui("ui_move");
            } else if (global.input.nav_confirm) {
                core_audio_play_sfx_ui("ui_select");
                scene_activate_projects_root_option(global.scene.projects_menu_index);
            }
            break;
            
        case PROJECTS_SUBMENU.NEW_PROJECT:
            if (global.input.nav_cancel && !global.input.text_input_active) {
                core_audio_play_sfx_ui("ui_cancel");
                global.scene.projects_submenu = PROJECTS_SUBMENU.ROOT;
                input_consume_all();
            }
            break;
            
        case PROJECTS_SUBMENU.SAVED_PROJECTS:
            if (global.input.nav_cancel) {
                core_audio_play_sfx_ui("ui_cancel");
                global.scene.projects_submenu = PROJECTS_SUBMENU.ROOT;
                input_consume_all();
                return;
            }
            var _count = array_length(global.scene.saved_projects_list);
            if (_count > 0) {
                if (global.input.nav_up || global.input.wheel_up) {
                    global.scene.selected_project_idx = max(0, global.scene.selected_project_idx - 1);
                    if (global.scene.selected_project_idx < global.scene.saved_scroll_offset) {
                        global.scene.saved_scroll_offset = global.scene.selected_project_idx;
                    }
                } else if (global.input.nav_down || global.input.wheel_down) {
                    global.scene.selected_project_idx = min(_count - 1, global.scene.selected_project_idx + 1);
                    if (global.scene.selected_project_idx >= global.scene.saved_scroll_offset + 4) {
                        global.scene.saved_scroll_offset = global.scene.selected_project_idx - 3;
                    }
                }
            }
            break;
            
        case PROJECTS_SUBMENU.DELETE_CONFIRM:
        case PROJECTS_SUBMENU.IMPORT_CONFIRM:
            if (global.input.nav_cancel) {
                global.scene.delete_target_project = undefined;
                global.scene.import_pending_data = undefined;
                global.scene.projects_submenu = PROJECTS_SUBMENU.SAVED_PROJECTS;
                input_consume_all();
            }
            break;
    }
}

function scene_activate_projects_root_option(_idx) {
    switch (_idx) {
        case 0: // New Project
            global.scene.new_proj_name = "New Starlight RPG";
            global.scene.new_proj_author = "Creator";
            global.scene.new_proj_desc = "Created with ST★RLIGHT ENGINE.";
            global.scene.projects_submenu = PROJECTS_SUBMENU.NEW_PROJECT;
            input_consume_all();
            break;
            
        case 1: // Saved Projects
            global.scene.saved_projects_list = core_saveload_scan_projects();
            global.scene.selected_project_idx = 0;
            global.scene.saved_scroll_offset = 0;
            global.scene.projects_submenu = PROJECTS_SUBMENU.SAVED_PROJECTS;
            input_consume_all();
            break;
            
        case 2: // Import Project
            core_saveload_import_project_dialog();
            break;
            
        case 3: // Back
            scene_switch_to(ENGINE_SCENE.MAIN_MENU);
            break;
    }
}

function scene_draw_projects_menu() {
    render_starfield_bg();
    var _pal = global.palette;
    
    // Title Header
    draw_set_font(fnt_starlight_title);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(_pal.accent_gold);
    draw_text(72, 52, STARLIGHT_ENGINE_NAME + "  //  PROJECTS");
    draw_set_font(fnt_starlight_ui);
    
    // Left Navigation Column
    var _opts = ["New Project", "Saved Projects", "Import Project", "Back"];
    var _bx1 = 72;
    var _bx2 = 340;
    var _by0 = 136;
    var _bh = 48;
    var _gap = 14;
    
    var _root_active = (global.scene.projects_submenu == PROJECTS_SUBMENU.ROOT);
    for (var i = 0; i < 4; i++) {
        var _by1 = _by0 + i * (_bh + _gap);
        var _by2 = _by1 + _bh;
        if (_root_active && input_mouse_in_rect(_bx1, _by1, _bx2, _by2)) {
            global.scene.projects_menu_index = i;
        }
        var _sel = (global.scene.projects_menu_index == i);
        if (render_ui_button(_bx1, _by1, _bx2, _by2, _opts[i], _sel, true)) {
            global.scene.projects_menu_index = i;
            scene_activate_projects_root_option(i);
            return;
        }
    }
    
    // Right Content Panel based on active submenu
    var _px1 = 380;
    var _py1 = 136;
    var _px2 = 1208;
    var _py2 = 660;
    
    switch (global.scene.projects_submenu) {
        case PROJECTS_SUBMENU.ROOT:
            render_window_frame(_px1, _py1, _px2, _py2, "PROJECT MANAGEMENT", _pal.border_outer);
            draw_set_color(_pal.text_primary);
            draw_text(_px1 + 28, _py1 + 56, "Select an option on the left to manage your RPG projects:");
            draw_set_color(_pal.text_secondary);
            draw_text(_px1 + 28, _py1 + 100, "• New Project: Creates a completely fresh, empty project folder and opens the Editor.");
            draw_text(_px1 + 28, _py1 + 134, "• Saved Projects: Browse existing projects to Play, Edit, or Delete.");
            draw_text(_px1 + 28, _py1 + 168, "• Import Project: Select an exported .slproj file via the Windows file dialog.");
            draw_text(_px1 + 28, _py1 + 202, "• Back: Return to the Main Menu (Shortcut: Escape).");
            break;
            
        case PROJECTS_SUBMENU.NEW_PROJECT:
            render_window_frame(_px1, _py1, _px2, _py2, "CREATE NEW PROJECT", _pal.accent_gold);
            draw_set_color(_pal.text_secondary);
            draw_text(_px1 + 28, _py1 + 52, "Creates a brand-new, empty project directory without modifying any existing project.");
            
            draw_set_color(_pal.text_primary);
            draw_text(_px1 + 28, _py1 + 98, "Project Name (Required):");
            global.scene.new_proj_name = render_ui_text_field("new_proj_name", _px1 + 28, _py1 + 124, _px2 - 40, _py1 + 162, global.scene.new_proj_name, 48);
            
            draw_text(_px1 + 28, _py1 + 186, "Author (Required):");
            global.scene.new_proj_author = render_ui_text_field("new_proj_author", _px1 + 28, _py1 + 212, _px2 - 40, _py1 + 250, global.scene.new_proj_author, 40);
            
            draw_text(_px1 + 28, _py1 + 274, "Description (Optional):");
            global.scene.new_proj_desc = render_ui_text_field("new_proj_desc", _px1 + 28, _py1 + 300, _px2 - 40, _py1 + 338, global.scene.new_proj_desc, 120);
            
            var _can_create = (string_trim(global.scene.new_proj_name) != "" && string_trim(global.scene.new_proj_author) != "");
            if (render_ui_button(_px1 + 28, _py2 - 72, _px1 + 280, _py2 - 24, "Create & Open Editor", true, _can_create)) {
                input_end_text_edit();
                var _created = core_saveload_create_new_project(
                    string_trim(global.scene.new_proj_name),
                    string_trim(global.scene.new_proj_author),
                    string_trim(global.scene.new_proj_desc)
                );
                if (_created) {
                    editor_open_current_project();
                    scene_switch_to(ENGINE_SCENE.EDITOR);
                }
            }
            if (render_ui_button(_px1 + 300, _py2 - 72, _px1 + 480, _py2 - 24, "Cancel", false, true)) {
                input_end_text_edit();
                global.scene.projects_submenu = PROJECTS_SUBMENU.ROOT;
            }
            break;
            
        case PROJECTS_SUBMENU.SAVED_PROJECTS:
            render_window_frame(_px1, _py1, _px2, _py2, "SAVED PROJECTS", _pal.accent_cyan);
            var _list = global.scene.saved_projects_list;
            var _total = array_length(_list);
            
            if (_total == 0) {
                draw_set_color(_pal.text_secondary);
                draw_text(_px1 + 28, _py1 + 70, "No saved projects found. Select 'New Project' or 'Import Project' to begin.");
            } else {
                var _vis = 4;
                var _start = clamp(global.scene.saved_scroll_offset, 0, max(0, _total - _vis));
                var _end = min(_total, _start + _vis);
                var _card_h = 104;
                var _card_gap = 12;
                var _cy0 = _py1 + 46;
                
                for (var i = _start; i < _end; i++) {
                    var _entry = _list[i];
                    var _slot = i - _start;
                    var _cy1 = _cy0 + _slot * (_card_h + _card_gap);
                    var _cy2 = _cy1 + _card_h;
                    var _cx1 = _px1 + 20;
                    var _cx2 = _px2 - 32;
                    var _is_sel = (global.scene.selected_project_idx == i);
                    
                    draw_set_color(_is_sel ? make_color_rgb(28, 34, 66) : _pal.panel_alt);
                    draw_rectangle(_cx1, _cy1, _cx2, _cy2, false);
                    draw_set_color(_is_sel ? _pal.accent_gold : _pal.border_inner);
                    draw_rectangle(_cx1, _cy1, _cx2, _cy2, true);
                    
                    // Thumbnail preview box
                    var _tx1 = _cx1 + 12;
                    var _ty1 = _cy1 + 12;
                    var _tx2 = _tx1 + 80;
                    var _ty2 = _cy2 - 12;
                    draw_set_color(make_color_rgb(10, 14, 28));
                    draw_rectangle(_tx1, _ty1, _tx2, _ty2, false);
                    draw_set_color(_pal.accent_cyan);
                    draw_rectangle(_tx1, _ty1, _tx2, _ty2, true);
                    draw_set_halign(fa_center);
                    draw_set_valign(fa_middle);
                    draw_text(mean(_tx1, _tx2), mean(_ty1, _ty2), "★ RPG");
                    
                    // Project metadata
                    draw_set_halign(fa_left);
                    draw_set_valign(fa_top);
                    draw_set_color(_pal.text_primary);
                    draw_text(_tx2 + 16, _cy1 + 12, render_fit_text(_entry.name, 360));
                    draw_set_color(_pal.accent_cyan);
                    draw_text(_tx2 + 16, _cy1 + 38, "Author: " + render_fit_text(_entry.author, 200) + "   |   Modified: " + _entry.last_modified);
                    draw_set_color(_pal.text_secondary);
                    draw_text(_tx2 + 16, _cy1 + 64, render_fit_text(_entry.description, 420));
                    
                    // Action buttons: Play Project, Edit Project, Delete Project
                    var _btn_w = 108;
                    var _btn_y1 = _cy1 + 30;
                    var _btn_y2 = _cy1 + 74;
                    var _del_x2 = _cx2 - 12;
                    var _del_x1 = _del_x2 - _btn_w;
                    var _edit_x2 = _del_x1 - 8;
                    var _edit_x1 = _edit_x2 - _btn_w;
                    var _play_x2 = _edit_x1 - 8;
                    var _play_x1 = _play_x2 - _btn_w;
                    
                    if (render_ui_button(_play_x1, _btn_y1, _play_x2, _btn_y2, "Play", false, true)) {
                        if (core_saveload_load_project(_entry.folder_path)) {
                            global.playtest_active = false;
                            runtime_start_project(false);
                            scene_switch_to(ENGINE_SCENE.RUNTIME_PLAY);
                            return;
                        }
                    }
                    if (render_ui_button(_edit_x1, _btn_y1, _edit_x2, _btn_y2, "Edit", false, true)) {
                        if (core_saveload_load_project(_entry.folder_path)) {
                            editor_open_current_project();
                            scene_switch_to(ENGINE_SCENE.EDITOR);
                            return;
                        }
                    }
                    if (render_ui_button(_del_x1, _btn_y1, _del_x2, _btn_y2, "Delete", false, true)) {
                        global.scene.delete_target_project = _entry;
                        global.scene.projects_submenu = PROJECTS_SUBMENU.DELETE_CONFIRM;
                        input_consume_all();
                        return;
                    }
                }
                
                render_scrollbar(_px2 - 18, _cy0, _py2 - 20, _total, _vis, _start);
            }
            break;
            
        case PROJECTS_SUBMENU.DELETE_CONFIRM:
            var _target = global.scene.delete_target_project;
            var _tname = is_struct(_target) ? _target.name : "Unknown Project";
            render_window_frame(_px1 + 80, _py1 + 100, _px2 - 80, _py2 - 120, "CONFIRM PROJECT DELETION", _pal.accent_red);
            draw_set_halign(fa_left);
            draw_set_valign(fa_top);
            draw_set_color(_pal.text_primary);
            draw_text(_px1 + 112, _py1 + 156, "Are you sure you want to permanently delete project:");
            draw_set_color(_pal.accent_gold);
            draw_text(_px1 + 112, _py1 + 192, "\"" + _tname + "\" ?");
            draw_set_color(_pal.accent_red);
            draw_text(_px1 + 112, _py1 + 232, "WARNING: This action will delete all maps, characters, items, and saves.");
            
            if (render_ui_button(_px1 + 112, _py2 - 190, _px1 + 340, _py2 - 142, "Yes, Delete Project", false, true)) {
                if (is_struct(_target)) {
                    core_saveload_delete_project(_target.folder_path);
                }
                global.scene.delete_target_project = undefined;
                global.scene.saved_projects_list = core_saveload_scan_projects();
                global.scene.selected_project_idx = 0;
                global.scene.saved_scroll_offset = 0;
                global.scene.projects_submenu = PROJECTS_SUBMENU.SAVED_PROJECTS;
                input_consume_all();
            }
            if (render_ui_button(_px1 + 364, _py2 - 190, _px1 + 560, _py2 - 142, "Cancel", true, true)) {
                global.scene.delete_target_project = undefined;
                global.scene.projects_submenu = PROJECTS_SUBMENU.SAVED_PROJECTS;
                input_consume_all();
            }
            break;
            
        case PROJECTS_SUBMENU.IMPORT_CONFIRM:
            var _imp = global.scene.import_pending_data;
            var _iname = is_struct(_imp) ? _imp.name : "Imported Project";
            render_window_frame(_px1 + 80, _py1 + 100, _px2 - 80, _py2 - 120, "CONFIRM PROJECT OVERWRITE", _pal.accent_gold);
            draw_set_halign(fa_left);
            draw_set_valign(fa_top);
            draw_set_color(_pal.text_primary);
            draw_text(_px1 + 112, _py1 + 156, "A project named \"" + _iname + "\" already exists in Saved Projects.");
            draw_set_color(_pal.text_secondary);
            draw_text(_px1 + 112, _py1 + 192, "Do you want to overwrite it or import as a new copy?");
            
            if (render_ui_button(_px1 + 112, _py2 - 190, _px1 + 312, _py2 - 142, "Overwrite Existing", false, true)) {
                core_saveload_finalize_import(_imp, true);
                global.scene.import_pending_data = undefined;
                global.scene.saved_projects_list = core_saveload_scan_projects();
                global.scene.projects_submenu = PROJECTS_SUBMENU.SAVED_PROJECTS;
                input_consume_all();
            }
            if (render_ui_button(_px1 + 328, _py2 - 190, _px1 + 528, _py2 - 142, "Import As Copy", true, true)) {
                core_saveload_finalize_import(_imp, false);
                global.scene.import_pending_data = undefined;
                global.scene.saved_projects_list = core_saveload_scan_projects();
                global.scene.projects_submenu = PROJECTS_SUBMENU.SAVED_PROJECTS;
                input_consume_all();
            }
            if (render_ui_button(_px1 + 544, _py2 - 190, _px1 + 680, _py2 - 142, "Cancel", false, true)) {
                global.scene.import_pending_data = undefined;
                global.scene.projects_submenu = PROJECTS_SUBMENU.ROOT;
                input_consume_all();
            }
            break;
    }
}

// ============================================================================
// SETTINGS MENU & CREDITS MENU
// ============================================================================

function scene_update_settings_menu() {
    if (global.input.key_consumed) return;
    if (global.input.nav_cancel) {
        core_config_save();
        core_audio_play_sfx_ui("ui_cancel");
        scene_switch_to(ENGINE_SCENE.MAIN_MENU);
        return;
    }
    if (global.input.nav_up) {
        global.scene.settings_index = (global.scene.settings_index + 4) mod 5;
        core_audio_play_sfx_ui("ui_move");
    } else if (global.input.nav_down) {
        global.scene.settings_index = (global.scene.settings_index + 1) mod 5;
        core_audio_play_sfx_ui("ui_move");
    } else if (global.input.nav_left || global.input.nav_right) {
        var _dir = global.input.nav_right ? 1 : -1;
        scene_adjust_setting(global.scene.settings_index, _dir);
    } else if (global.input.nav_confirm && global.scene.settings_index == 4) {
        core_config_save();
        scene_switch_to(ENGINE_SCENE.MAIN_MENU);
    }
}

function scene_adjust_setting(_idx, _dir) {
    switch (_idx) {
        case 0:
            global.config.music_volume = clamp(global.config.music_volume + (_dir * 0.1), 0.0, 1.0);
            core_audio_sync_volumes();
            break;
        case 1:
            global.config.sfx_volume = clamp(global.config.sfx_volume + (_dir * 0.1), 0.0, 1.0);
            break;
        case 2:
            global.config.fullscreen = !global.config.fullscreen;
            core_config_apply_display();
            break;
        case 3:
            global.config.default_grid_size = (global.config.default_grid_size == 32) ? 16 : 32;
            break;
    }
    core_audio_play_sfx_ui("ui_move");
}

function scene_draw_settings_menu() {
    render_starfield_bg();
    var _pal = global.palette;
    
    render_window_frame(220, 110, 1060, 610, "ST★RLIGHT ENGINE  //  SETTINGS", _pal.accent_cyan);
    
    var _rows = [
        "Music Volume: " + string(round(global.config.music_volume * 100)) + "%",
        "Sound Effect Volume: " + string(round(global.config.sfx_volume * 100)) + "%",
        "Display Mode: " + (global.config.fullscreen ? "Fullscreen" : "Windowed (1280x720)"),
        "Default Editor Grid Size: " + string(global.config.default_grid_size) + "x" + string(global.config.default_grid_size) + " px",
        "Save & Return to Main Menu"
    ];
    
    for (var i = 0; i < 5; i++) {
        var _by1 = 180 + i * 72;
        var _by2 = _by1 + 52;
        if (input_mouse_in_rect(280, _by1, 1000, _by2)) {
            global.scene.settings_index = i;
        }
        if (render_ui_button(280, _by1, 1000, _by2, _rows[i], (global.scene.settings_index == i), true)) {
            if (i < 4) {
                scene_adjust_setting(i, 1);
            } else {
                core_config_save();
                scene_switch_to(ENGINE_SCENE.MAIN_MENU);
            }
        }
    }
}

function scene_update_credits_menu() {
    if (global.input.key_consumed) return;
    if (global.input.nav_cancel || global.input.nav_confirm) {
        core_audio_play_sfx_ui("ui_cancel");
        scene_switch_to(ENGINE_SCENE.MAIN_MENU);
    }
}

function scene_draw_credits_menu() {
    render_starfield_bg();
    var _pal = global.palette;
    
    render_window_frame(220, 110, 1060, 610, "ST★RLIGHT ENGINE  //  CREDITS", _pal.accent_gold);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(_pal.accent_gold);
    draw_text(268, 176, "ST★RLIGHT ENGINE — 16-BIT 2D RPG CREATION ENGINE");
    draw_set_color(_pal.text_primary);
    draw_text(268, 218, "Inspired by EarthBound (Mother 2), Undertale, and classic 16-bit SNES RPGs.");
    draw_set_color(_pal.text_secondary);
    draw_text(268, 268, "Engine Architecture: Modular Data-Driven GML Framework");
    draw_text(268, 300, "Core Systems: Map/Tile/Collision Editor, Visual Event & Dialogue Tree Engine");
    draw_text(268, 332, "Combat Engine: Rolling-HP Turn-Based Battle System with Custom Formulas");
    draw_text(268, 364, "Bundled Demo RPG: 'Starfall Valley' (Regression Test & Sample Project)");
    
    if (render_ui_button(268, 520, 560, 568, "Back to Main Menu (Esc)", true, true)) {
        scene_switch_to(ENGINE_SCENE.MAIN_MENU);
    }
}
