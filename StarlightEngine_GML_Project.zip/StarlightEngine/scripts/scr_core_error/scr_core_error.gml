/// @description ST★RLIGHT ENGINE - Error Handling, Validation & Diagnostic Logging
/// Ensures missing assets, invalid parameters, or corrupted files are reported clearly without crashing.

function core_error_init() {
    global.error_log = {
        entries: [],
        toasts: [],
        max_entries: 200
    };
}

function core_log_record(_level, _subsystem, _message) {
    if (!variable_global_exists("error_log") || !is_struct(global.error_log)) return;
    var _line = "[" + _level + "] (" + string(_subsystem) + ") " + string(_message);
    show_debug_message(_line);
    
    array_push(global.error_log.entries, {
        level: _level,
        subsystem: _subsystem,
        message: _message,
        frame: variable_global_exists("engine") ? global.engine.frame_counter : 0
    });
    
    if (array_length(global.error_log.entries) > global.error_log.max_entries) {
        array_delete(global.error_log.entries, 0, 1);
    }
}

function core_log_info(_message) {
    core_log_record("INFO", "Engine", _message);
}

function core_log_warning(_subsystem, _message) {
    core_log_record("WARN", _subsystem, _message);
    core_log_toast("Warning (" + _subsystem + "): " + _message);
}

function core_log_error(_subsystem, _message) {
    core_log_record("ERROR", _subsystem, _message);
    core_log_toast("Error (" + _subsystem + "): " + _message);
}

function core_log_toast(_text) {
    if (!variable_global_exists("error_log") || !is_struct(global.error_log)) return;
    array_push(global.error_log.toasts, {
        text: string(_text),
        timer: 180
    });
    if (array_length(global.error_log.toasts) > 4) {
        array_delete(global.error_log.toasts, 0, 1);
    }
}

function core_error_draw_toasts() {
    if (!variable_global_exists("error_log") || !is_struct(global.error_log)) return;
    var _toasts = global.error_log.toasts;
    var _count = array_length(_toasts);
    if (_count == 0) return;
    
    var _pal = global.palette;
    var _ty = 12;
    for (var i = _count - 1; i >= 0; i--) {
        var _t = _toasts[i];
        _t.timer--;
        if (_t.timer <= 0) {
            array_delete(_toasts, i, 1);
            continue;
        }
        var _w = clamp(string_width(_t.text) + 32, 240, 560);
        var _x1 = STARLIGHT_BASE_WIDTH - _w - 16;
        var _x2 = STARLIGHT_BASE_WIDTH - 16;
        var _y1 = _ty;
        var _y2 = _ty + 32;
        
        draw_set_alpha(clamp(_t.timer / 30, 0.0, 0.92));
        draw_set_color(_pal.panel_header);
        draw_rectangle(_x1, _y1, _x2, _y2, false);
        draw_set_color(_pal.accent_gold);
        draw_rectangle(_x1, _y1, _x2, _y2, true);
        draw_set_halign(fa_left);
        draw_set_valign(fa_middle);
        draw_set_color(_pal.text_primary);
        draw_text(_x1 + 12, mean(_y1, _y2), render_fit_text(_t.text, _w - 24));
        draw_set_alpha(1.0);
        
        _ty += 38;
    }
}
