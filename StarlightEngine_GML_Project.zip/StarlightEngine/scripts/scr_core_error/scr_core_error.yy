{
  "$GMScript": "v1",
  "%Name": "scr_core_error",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_core_error",
  "parent": {
    "name": "Core",
    "path": "folders/Engine/Core.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}