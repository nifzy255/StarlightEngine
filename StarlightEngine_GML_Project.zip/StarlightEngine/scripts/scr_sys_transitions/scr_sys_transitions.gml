/// @description ST★RLIGHT ENGINE - Map Transition & Runtime World Controller
/// Manages playable runtime initialization, map loading, collision, player/NPC movement, and interactions.

function runtime_init_state() {
    global.runtime = {
        current_map_id: "",
        player_x: 160,
        player_y: 160,
        player_facing: DIR_FACING.DOWN,
        player_move_speed: 3.0,
        player_anim_state: "Idle",
        player_anim_frame: 0,
        player_movement_enabled: true,
        battle_grace_timer: 0,
        playtime_seconds: 0,
        gold: 50,
        party: [],
        inventory: [],
        variables: {},
        quests: {},
        defeated_enemies: {},
        completed_events: {},
        stats_telemetry: sys_stats_create_telemetry(),
        
        // Active map runtime entity instances
        active_npcs: [],
        active_objects: [],
        active_enemies: [],
        active_auto_event_Lock: "",
        
        // Dialogue & Event subsystems
        dialogue: sys_dialogue_init_state(),
        event_runner: sys_event_init_runner(),
        
        // Pause Menu state
        pause_menu_open: false,
        pause_tab_index: 0,
        pause_sub_index: 0,
        bg_override_str: ""
    };
}

/// @function runtime_start_project(_is_playtest)
/// @description Launches the currently loaded project in Playable Runtime mode.
function runtime_start_project(_is_playtest) {
    if (is_undefined(global.project)) return false;
    global.playtest_active = _is_playtest;
    
    runtime_init_state();
    sys_variable_init_runtime();
    sys_quest_init_runtime();
    sys_party_init_starting_roster();
    
    global.runtime.gold = variable_struct_exists(global.project, "starting_gold") ? global.project.starting_gold : 50;
    
    var _start_map_id = variable_struct_exists(global.project, "starting_map_id") ? global.project.starting_map_id : "";
    var _m = editor_map_find_by_id(_start_map_id);
    if (!is_struct(_m) && array_length(global.project.maps) > 0) {
        _m = global.project.maps[0];
        _start_map_id = _m.id;
    }
    
    var _tsize = is_struct(_m) ? _m.tile_size : 32;
    var _sx = (variable_struct_exists(global.project, "starting_x") ? global.project.starting_x : 4) * _tsize;
    var _sy = (variable_struct_exists(global.project, "starting_y") ? global.project.starting_y : 4) * _tsize;
    
    sys_transition_load_map(_start_map_id, _sx, _sy, DIR_FACING.DOWN, false);
    return true;
}

/// @function sys_transition_load_map(_map_id, _pixel_x, _pixel_y, _facing, _with_fade)
/// @description Loads a destination map, spawns NPCs/Objects/Enemies, sets player position, and switches music.
function sys_transition_load_map(_map_id, _pixel_x, _pixel_y, _facing, _with_fade) {
    var _map = editor_map_find_by_id(_map_id);
    if (!is_struct(_map)) {
        core_log_error("Map Transition", "Destination map not found: " + string(_map_id));
        return false;
    }
    
    var _rt = global.runtime;
    _rt.current_map_id = _map.id;
    _rt.player_x = _pixel_x;
    _rt.player_y = _pixel_y;
    _rt.player_facing = is_undefined(_facing) ? DIR_FACING.DOWN : _facing;
    _rt.active_auto_event_Lock = "";
    
    if (_with_fade) {
        global.scene.fade_alpha = 0.85;
        global.scene.fade_target = 0.0;
    }
    
    // Instantiate map NPCs
    _rt.active_npcs = [];
    if (variable_struct_exists(_map, "npcs") && is_array(_map.npcs)) {
        for (var i = 0; i < array_length(_map.npcs); i++) {
            var _n = _map.npcs[i];
            var _nx = _n.grid_x * _map.tile_size;
            var _ny = _n.grid_y * _map.tile_size;
            array_push(_rt.active_npcs, {
                id: _n.id,
                name: _n.name,
                sprite_id: variable_struct_exists(_n, "sprite_id") ? _n.sprite_id : "spr_npc_default",
                portrait_sprite_id: variable_struct_exists(_n, "portrait_sprite_id") ? _n.portrait_sprite_id : "",
                sprite_scale: variable_struct_exists(_n, "sprite_scale") ? sys_sprite_clamp_scale(_n.sprite_scale) : 1.0,
                x: _nx,
                y: _ny,
                spawn_x: _nx,
                spawn_y: _ny,
                facing: variable_struct_exists(_n, "facing") ? _n.facing : DIR_FACING.DOWN,
                move_mode: variable_struct_exists(_n, "move_mode") ? _n.move_mode : NPC_MOVE_MODE.STAY_STILL,
                move_speed: variable_struct_exists(_n, "move_speed") ? _n.move_speed : 1.2,
                wander_radius: variable_struct_exists(_n, "wander_radius") ? _n.wander_radius : 64,
                wait_frames: variable_struct_exists(_n, "wait_frames") ? _n.wait_frames : 60,
                wait_timer: 45,
                wander_vx: 0,
                wander_vy: 0,
                path_points: variable_struct_exists(_n, "path_points") && is_array(_n.path_points) ? _n.path_points : [],
                path_index: 0,
                path_finished: false,
                condition_var: variable_struct_exists(_n, "condition_var") ? _n.condition_var : "",
                condition_val: variable_struct_exists(_n, "condition_val") ? _n.condition_val : true,
                dialogue_tree: variable_struct_exists(_n, "dialogue_tree") && is_array(_n.dialogue_tree)
                    ? _n.dialogue_tree : sys_dialogue_create_default_tree("Hello there!"),
                anim_state: "Idle",
                anim_frame: 0
            });
        }
    }
    
    // Instantiate map Objects
    _rt.active_objects = [];
    if (variable_struct_exists(_map, "objects") && is_array(_map.objects)) {
        for (var j = 0; j < array_length(_map.objects); j++) {
            var _o = _map.objects[j];
            array_push(_rt.active_objects, {
                id: _o.id,
                sprite_id: variable_struct_exists(_o, "sprite_id") ? _o.sprite_id : "spr_obj_sign",
                sprite_scale: variable_struct_exists(_o, "sprite_scale") ? sys_sprite_clamp_scale(_o.sprite_scale) : 1.0,
                visible: variable_struct_exists(_o, "visible") ? _o.visible : true,
                x: _o.grid_x * _map.tile_size,
                y: _o.grid_y * _map.tile_size,
                solid: variable_struct_exists(_o, "solid") ? _o.solid : true,
                interact_range: variable_struct_exists(_o, "interact_range") ? _o.interact_range : 42,
                interact_dir: variable_struct_exists(_o, "interact_dir") ? _o.interact_dir : "ANY",
                dialogue_tree: variable_struct_exists(_o, "dialogue_tree") && is_array(_o.dialogue_tree)
                    ? _o.dialogue_tree : sys_dialogue_create_default_tree("It's an ordinary object.")
            });
        }
    }
    
    // Instantiate map Enemies
    _rt.active_enemies = [];
    if (variable_struct_exists(_map, "enemies") && is_array(_map.enemies)) {
        for (var k = 0; k < array_length(_map.enemies); k++) {
            var _e = _map.enemies[k];
            var _ekey = _map.id + "__" + _e.id;
            var _edef = sys_enemy_find_def(_e.enemy_id);
            if (!is_struct(_edef)) _edef = sys_enemy_create_default(_e.enemy_id, "Foe");
            
            var _perm_dead = variable_struct_exists(_rt.defeated_enemies, _ekey);
            var _ex = _e.grid_x * _map.tile_size;
            var _ey = _e.grid_y * _map.tile_size;
            
            array_push(_rt.active_enemies, {
                instance_key: _ekey,
                id: _e.id,
                enemy_id: _edef.id,
                name: _edef.name,
                sprite_id: _edef.sprite_id,
                sprite_scale: variable_struct_exists(_edef, "overworld_scale") ? sys_sprite_clamp_scale(_edef.overworld_scale) : 1.0,
                x: _ex,
                y: _ey,
                spawn_x: _ex,
                spawn_y: _ey,
                ai_behavior: variable_struct_exists(_e, "ai_override") && _e.ai_override >= 0 ? _e.ai_override : _edef.ai_behavior,
                detection_radius: _edef.detection_radius,
                wander_radius: _edef.wander_radius,
                move_speed: _edef.move_speed,
                defeat_mode: _edef.defeat_mode,
                respawn_seconds: _edef.respawn_seconds,
                respawn_timer: 0,
                defeated: _perm_dead,
                defeat_var: variable_struct_exists(_e, "defeat_var") ? _e.defeat_var : "",
                condition_var: variable_struct_exists(_e, "condition_var") ? _e.condition_var : "",
                condition_val: variable_struct_exists(_e, "condition_val") ? _e.condition_val : true,
                wander_timer: 30,
                wander_vx: 0,
                wander_vy: 0,
                facing: DIR_FACING.DOWN,
                anim_state: "Idle",
                anim_frame: 0
            });
        }
    }
    
    // Start map-specific background music if assigned
    if (variable_struct_exists(_map, "bgm_id") && _map.bgm_id != "") {
        core_audio_start_music(_map.bgm_id, true);
    }
    
    camera_runtime_update(_rt.player_x, _rt.player_y, _map.width * _map.tile_size, _map.height * _map.tile_size, true);
    return true;
}

/// @function runtime_check_tile_collision(_map, _px, _py, _bbox_w, _bbox_h)
/// @description Checks whether a bounding box at (_px, _py) collides with map boundaries, collision grid, or solid entities.
function runtime_check_tile_collision(_map, _px, _py, _bbox_w, _bbox_h) {
    if (!is_struct(_map)) return false;
    var _tsize = _map.tile_size;
    var _map_pw = _map.width * _tsize;
    var _map_ph = _map.height * _tsize;
    
    // Map boundary check
    if (_px < 0 || _py < 0 || (_px + _bbox_w) > _map_pw || (_py + _bbox_h) > _map_ph) {
        return true;
    }
    
    // Check 4 corners against invisible collision tile grid
    var _gx1 = floor((_px + 2) / _tsize);
    var _gy1 = floor((_py + 2) / _tsize);
    var _gx2 = floor((_px + _bbox_w - 2) / _tsize);
    var _gy2 = floor((_py + _bbox_h - 2) / _tsize);
    
    for (var gy = _gy1; gy <= _gy2; gy++) {
        for (var gx = _gx1; gx <= _gx2; gx++) {
            if (editor_collision_get_cell(_map, gx, gy)) {
                return true;
            }
        }
    }
    
    // Check solid stationary Objects
    var _objs = global.runtime.active_objects;
    for (var i = 0; i < array_length(_objs); i++) {
        var _o = _objs[i];
        if (_o.solid) {
            if (rectangle_in_rectangle(_px + 2, _py + 2, _px + _bbox_w - 2, _py + _bbox_h - 2,
                _o.x + 2, _o.y + 2, _o.x + _tsize - 2, _o.y + _tsize - 2) > 0) {
                return true;
            }
        }
    }
    return false;
}
