/// @description ST★RLIGHT ENGINE - Stationary Interactable Object Editor
/// Places and configures stationary objects (signs, chests, doors, books, custom PNG sprites, and invisible triggers).

function editor_objects_place_at(_map, _gx, _gy) {
    if (!is_struct(_map)) return;
    if (editor_objects_inspect_at(_map, _gx, _gy)) return;
    
    var _new_id = "obj_" + string(array_length(_map.objects) + 1) + "_" + string(_gx) + "_" + string(_gy);
    var _obj = {
        id: _new_id,
        sprite_id: "spr_obj_sign",
        sprite_scale: 1.0,
        visible: true,
        grid_x: _gx,
        grid_y: _gy,
        solid: true,
        interact_range: 42,
        interact_dir: "ANY",
        dialogue_tree: sys_dialogue_create_default_tree("A weathered wooden signpost stands here.")
    };
    array_push(_map.objects, _obj);
    global.project_dirty = true;
    core_log_toast("Placed Object (Right-click to configure)");
}

function editor_objects_remove_at(_map, _gx, _gy) {
    if (!is_struct(_map) || !is_array(_map.objects)) return;
    for (var i = array_length(_map.objects) - 1; i >= 0; i--) {
        if (_map.objects[i].grid_x == _gx && _map.objects[i].grid_y == _gy) {
            array_delete(_map.objects, i, 1);
            global.project_dirty = true;
            core_log_toast("Removed Object.");
            return;
        }
    }
}

function editor_objects_inspect_at(_map, _gx, _gy) {
    if (!is_struct(_map) || !is_array(_map.objects)) return false;
    for (var i = 0; i < array_length(_map.objects); i++) {
        var _o = _map.objects[i];
        if (_o.grid_x == _gx && _o.grid_y == _gy) {
            if (!variable_struct_exists(_o, "visible")) _o.visible = true;
            global.editor.inspect_object = _o;
            global.editor.dlg_active_branch = "starter";
            global.editor.dlg_tab_scroll = 0;
            global.editor.dlg_node_scroll = 0;
            global.editor.active_modal = EDITOR_MODAL.OBJECT_INSPECTOR;
            input_consume_all();
            return true;
        }
    }
    return false;
}

function editor_objects_draw_inspector_modal(_map) {
    var _ed = global.editor;
    var _pal = global.palette;
    var _obj = _ed.inspect_object;
    if (!is_struct(_obj)) {
        _ed.active_modal = EDITOR_MODAL.NONE;
        return;
    }
    if (!variable_struct_exists(_obj, "visible")) _obj.visible = true;
    if (!variable_struct_exists(_obj, "sprite_scale")) _obj.sprite_scale = 1.0;
    _obj.sprite_scale = sys_sprite_clamp_scale(_obj.sprite_scale);
    
    render_window_frame(96, 36, 1184, 684, "STATIONARY OBJECT EDITOR (CUSTOM SPRITES, SCALE & INVISIBLE TRIGGERS)", _pal.accent_gold);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    // Left Column: Object Identity, Live Scaled Preview, Custom PNG Import, Scale, Visibility Toggle, & Collision
    draw_set_color(_pal.accent_gold);
    draw_text(120, 82, "Object ID:");
    _obj.id = render_ui_text_field("obj_id", 220, 78, 456, 110, _obj.id, 36);
    
    draw_set_color(_pal.text_secondary);
    draw_text(120, 116, "Grid: (" + string(_obj.grid_x) + ", " + string(_obj.grid_y) + ") — Scale: " + string(_obj.sprite_scale) + "x");
    
    // Live Object Sprite Preview Box (64x64) + Sprite ID & Scale Field
    if (_obj.visible) {
        var _ofps = core_assets_get_anim_fps(_obj.sprite_id, "Idle", DIR_FACING.DOWN);
        var _oframe = global.engine.frame_counter * (_ofps / 60.0);
        core_assets_draw_scaled_preview_box(120, 142, 188, 210, _obj.sprite_id, "Idle", _oframe, DIR_FACING.DOWN, undefined, _obj.sprite_scale, _pal.accent_gold);
    } else {
        draw_set_color(make_color_rgb(10, 14, 28));
        draw_rectangle(120, 142, 188, 210, false);
        draw_set_color(_pal.accent_magenta);
        draw_rectangle(120, 142, 188, 210, true);
        draw_text(126, 166, "INVIS");
    }
    
    draw_set_color(_pal.accent_cyan);
    draw_text(198, 140, "Sprite ID:");
    _obj.sprite_id = render_ui_text_field("obj_sprite_id", 290, 136, 456, 168, _obj.sprite_id, 40);
    
    draw_set_color(_pal.accent_gold);
    draw_text(198, 180, "Scale:");
    var _new_osc = render_ui_number_field("obj_scale", 258, 174, 344, 208, _obj.sprite_scale, 0.1, 8.0, true);
    if (_new_osc != _obj.sprite_scale) {
        _obj.sprite_scale = sys_sprite_clamp_scale(_new_osc);
        global.project_dirty = true;
    }
    if (render_ui_button(352, 174, 456, 208, "1.0x Reset", (_obj.sprite_scale == 1.0), true)) {
        _obj.sprite_scale = 1.0;
        global.project_dirty = true;
    }
    
    // Custom PNG Import, Replace, Remove & Presets
    if (render_ui_button(120, 222, 344, 258, "+ Import / Replace PNG...", false, true)) {
        input_end_text_edit();
        if (_obj.sprite_id == "" || _obj.sprite_id == "spr_obj_sign" || _obj.sprite_id == "spr_obj_chest") {
            _obj.sprite_id = "spr_custom_" + _obj.id;
        }
        if (editor_sprites_import_entity_png(_obj.sprite_id, "Object " + _obj.id, "sign", 1)) {
            _obj.visible = true;
        }
        return;
    }
    if (render_ui_button(352, 222, 456, 258, "Reset Def", false, true)) {
        input_end_text_edit();
        editor_sprites_clear_entity_custom_png(_obj.sprite_id);
        _obj.sprite_id = "spr_obj_sign";
        global.project_dirty = true;
        core_log_toast("Reset object sprite to default.");
        return;
    }
    
    if (render_ui_button(120, 264, 228, 298, "Preset: Sign", (_obj.sprite_id == "spr_obj_sign"), true)) {
        _obj.sprite_id = "spr_obj_sign";
        global.project_dirty = true;
    }
    if (render_ui_button(236, 264, 344, 298, "Preset: Chest", (_obj.sprite_id == "spr_obj_chest"), true)) {
        _obj.sprite_id = "spr_obj_chest";
        global.project_dirty = true;
    }
    if (render_ui_button(352, 264, 456, 298, "Frames...", false, true)) {
        input_end_text_edit();
        if (_obj.sprite_id == "" || _obj.sprite_id == "spr_obj_sign" || _obj.sprite_id == "spr_obj_chest") {
            _obj.sprite_id = "spr_custom_" + _obj.id;
        }
        editor_sprites_open_for_id(_obj.sprite_id);
        return;
    }
    
    // Visibility Toggle (Visible Sprite vs Invisible Interactable Object) & Solid Collision
    var _vis_lbl = _obj.visible ? "Visibility: VISIBLE ON MAP" : "Visibility: INVISIBLE (Hidden Trigger)";
    if (render_ui_button(120, 308, 456, 344, _vis_lbl, !_obj.visible, true)) {
        _obj.visible = !_obj.visible;
        global.project_dirty = true;
        core_log_toast("Object visibility: " + (_obj.visible ? "VISIBLE" : "INVISIBLE (Editor indicator only)"));
    }
    
    if (render_ui_button(120, 352, 456, 388, "Collision Solid: " + (_obj.solid ? "YES (Blocks Movement)" : "NO (Walk-Through)"), _obj.solid, true)) {
        _obj.solid = !_obj.solid;
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.text_secondary);
    draw_text(120, 404, "Range(px):");
    _obj.interact_range = render_ui_number_field("obj_range", 230, 400, 316, 432, _obj.interact_range, 16, 128, false);
    if (render_ui_button(326, 400, 456, 432, "Dir: " + _obj.interact_dir, false, true)) {
        var _dirs = ["ANY", "UP", "DOWN", "LEFT", "RIGHT"];
        var _cur_i = 0;
        for (var d = 0; d < 5; d++) if (_dirs[d] == _obj.interact_dir) _cur_i = d;
        _obj.interact_dir = _dirs[(_cur_i + 1) mod 5];
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.accent_cyan);
    draw_text(120, 448, "QUICK TEMPLATES:");
    if (render_ui_button(120, 472, 456, 510, "Configure As YES/NO Item Chest", false, true)) {
        _obj.sprite_id = "spr_obj_chest";
        _obj.dialogue_tree = [
            {
                id: "starter_0",
                branch_path: "starter",
                text: "You found a Starlight Box! Open it?",
                condition_var: "VAR_CHEST_01_OPENED",
                condition_val: false,
                fallback_node_id: "starter_empty",
                choices: [
                    {
                        label: "YES",
                        next_node_id: "yes/starter_0",
                        set_var: "VAR_CHEST_01_OPENED",
                        set_val: true,
                        event_commands: []
                    },
                    {
                        label: "NO",
                        next_node_id: "no/starter_0",
                        set_var: "",
                        set_val: false,
                        event_commands: []
                    }
                ],
                next_node_id: "END",
                event_commands: []
            },
            {
                id: "yes/starter_0",
                branch_path: "yes/starter",
                text: "You opened the box and found a Star Burger!",
                condition_var: "",
                condition_val: true,
                fallback_node_id: "",
                choices: [],
                next_node_id: "END",
                event_commands: [
                    sys_event_create_command("add_item", "item_star_burger", "1"),
                    sys_event_create_command("set_variable", "VAR_CHEST_01_OPENED", "TRUE")
                ]
            },
            {
                id: "no/starter_0",
                branch_path: "no/starter",
                text: "You decided to leave the box closed for now.",
                condition_var: "",
                condition_val: true,
                fallback_node_id: "",
                choices: [],
                next_node_id: "END",
                event_commands: []
            },
            {
                id: "starter_empty",
                branch_path: "starter",
                text: "The Starlight Box is empty.",
                condition_var: "",
                condition_val: true,
                fallback_node_id: "",
                choices: [],
                next_node_id: "END",
                event_commands: []
            }
        ];
        _ed.dlg_active_branch = "starter";
        _ed.dlg_node_scroll = 0;
        global.project_dirty = true;
        core_log_toast("Configured YES/NO Item Chest template.");
    }
    
    // Right Column: Scrollable Hierarchical Dialogue Tree Editor
    editor_draw_hierarchical_dialogue_panel(_obj.dialogue_tree, 480, 82, 1160, 616, "obj_dlg");
    
    if (render_ui_button(956, 628, 1160, 668, "Done (Esc)", true, true)) {
        input_end_text_edit();
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}
