/// @description ST★RLIGHT ENGINE - EarthBound-Inspired Turn-Based Battle System & Game Over Sequence
/// Features rolling HP counters, configurable damage formulas, abilities, items, enemy AI, and dramatic Game Over.

enum BATTLE_PHASE {
    INTRO = 0,
    PLAYER_COMMAND = 1,
    PLAYER_SUBMENU_ABILITY = 2,
    PLAYER_SUBMENU_ITEM = 3,
    TURN_EXECUTION = 4,
    VICTORY = 5,
    DEFEAT = 6
}

function battle_init_state() {
    global.battle = {
        active: false,
        phase: BATTLE_PHASE.INTRO,
        enemies: [],
        overworld_instance_ref: undefined,
        active_actor_idx: 0,
        command_idx: 0,
        submenu_idx: 0,
        turn_queue: [],
        turn_step_idx: 0,
        turn_wait_timer: 0,
        log_lines: [],
        bg_wave_phase: 0,
        enemy_flash_timer: 0,
        reward_summary: "",
        defeat_fade_timer: 0,
        gameover_timer: 0,
        gameover_option_idx: 0,
        gameover_load_open: false,
        gameover_slot_idx: 0
    };
}

function battle_add_log(_text) {
    array_push(global.battle.log_lines, string(_text));
    if (array_length(global.battle.log_lines) > 3) {
        array_delete(global.battle.log_lines, 0, 1);
    }
}

/// @function sys_battle_initiate_by_enemy_id(_enemy_id, _overworld_inst)
/// @description Initiates a turn-based battle against the specified enemy definition.
function sys_battle_initiate_by_enemy_id(_enemy_id, _overworld_inst) {
    // Prevent repeated battle initiation while a battle is already active
    if (global.battle.active || global.scene.current == ENGINE_SCENE.RUNTIME_BATTLE || global.scene.current == ENGINE_SCENE.GAME_OVER) {
        return false;
    }
    
    var _edef = sys_enemy_find_def(_enemy_id);
    if (is_undefined(_edef)) {
        _edef = sys_enemy_create_default(_enemy_id, "Stardust Foe");
    }
    
    var _e_inst = {
        id: _edef.id,
        name: _edef.name,
        sprite_id: variable_struct_exists(_edef, "battle_sprite_id") && _edef.battle_sprite_id != "" ? _edef.battle_sprite_id : _edef.sprite_id,
        sprite_scale: variable_struct_exists(_edef, "battle_scale") ? sys_sprite_clamp_scale(_edef.battle_scale) : 1.0,
        max_hp: max(1, _edef.max_hp),
        current_hp: max(1, _edef.max_hp),
        attack: max(1, _edef.attack),
        defense: max(0, _edef.defense),
        speed: max(1, _edef.speed),
        weakness: variable_struct_exists(_edef, "weakness") ? _edef.weakness : "",
        resistance: variable_struct_exists(_edef, "resistance") ? _edef.resistance : "",
        reward_exp: variable_struct_exists(_edef, "reward_exp") ? _edef.reward_exp : 20,
        reward_gold: variable_struct_exists(_edef, "reward_gold") ? _edef.reward_gold : 15,
        reward_item_id: variable_struct_exists(_edef, "reward_item_id") ? _edef.reward_item_id : "",
        reward_event_id: variable_struct_exists(_edef, "reward_event_id") ? _edef.reward_event_id : "",
        abilities: variable_struct_exists(_edef, "abilities") && is_array(_edef.abilities) ? _edef.abilities : [],
        status_effect: ""
    };
    
    global.battle.active = true;
    global.battle.phase = BATTLE_PHASE.PLAYER_COMMAND;
    global.battle.enemies = [_e_inst];
    global.battle.overworld_instance_ref = _overworld_inst;
    global.battle.active_actor_idx = 0;
    global.battle.command_idx = 0;
    global.battle.submenu_idx = 0;
    global.battle.turn_queue = [];
    global.battle.turn_step_idx = 0;
    global.battle.turn_wait_timer = 0;
    global.battle.log_lines = [];
    global.battle.enemy_flash_timer = 0;
    global.battle.defeat_fade_timer = 0;
    
    // Clear defending flags on party members
    for (var i = 0; i < array_length(global.runtime.party); i++) {
        var _pm = global.runtime.party[i];
        _pm.is_defending = false;
        _pm.rolling_hp = _pm.current_hp;
    }
    
    global.runtime.stats_telemetry.battles_fought++;
    battle_add_log("* You encountered " + _e_inst.name + "!");
    battle_add_log("* What will " + global.runtime.party[0].name + " do?");
    
    core_audio_play_default_sound("battle_start");
    scene_switch_to(ENGINE_SCENE.RUNTIME_BATTLE);
    return true;
}

/// @function battle_calculate_damage(_atk_val, _def_val, _power_bonus, _is_weak, _is_resist, _is_defending)
/// @description Uses configurable project combat formulas to compute damage and critical hits.
function battle_calculate_damage(_atk_val, _def_val, _power_bonus, _is_weak, _is_resist, _is_defending) {
    var _cfg = (!is_undefined(global.project) && variable_struct_exists(global.project, "combat_config"))
        ? global.project.combat_config
        : { attack_multiplier: 1.0, defense_multiplier: 0.5, crit_chance: 0.08, crit_multiplier: 1.75 };
        
    var _raw = ((_atk_val * _cfg.attack_multiplier) + _power_bonus) - (_def_val * _cfg.defense_multiplier);
    _raw = max(1, _raw * random_range(0.9, 1.12));
    
    var _is_crit = (random(1.0) < _cfg.crit_chance);
    if (_is_crit) {
        _raw *= _cfg.crit_multiplier;
    }
    if (_is_weak) _raw *= 1.45;
    if (_is_resist) _raw *= 0.65;
    if (_is_defending) _raw *= 0.5;
    
    return {
        damage: max(1, round(_raw)),
        is_crit: _is_crit
    };
}

function battle_update() {
    if (!global.battle.active) return;
    global.battle.bg_wave_phase += 0.04;
    if (global.battle.enemy_flash_timer > 0) global.battle.enemy_flash_timer--;
    
    // Quick return to Editor during Playtest via F1
    if (global.playtest_active && global.input.shortcut_project_mgr) {
        global.battle.active = false;
        runtime_exit_playtest_to_editor();
        return;
    }
    
    // Update EarthBound-inspired rolling HP odometers on party members
    for (var i = 0; i < array_length(global.runtime.party); i++) {
        var _m = global.runtime.party[i];
        if (!variable_struct_exists(_m, "rolling_hp")) _m.rolling_hp = _m.current_hp;
        if (_m.rolling_hp > _m.current_hp) {
            _m.rolling_hp = max(_m.current_hp, _m.rolling_hp - 0.18);
        } else if (_m.rolling_hp < _m.current_hp) {
            _m.rolling_hp = min(_m.current_hp, _m.rolling_hp + 0.45);
        }
    }
    
    switch (global.battle.phase) {
        case BATTLE_PHASE.PLAYER_COMMAND:
            battle_update_player_command();
            break;
        case BATTLE_PHASE.PLAYER_SUBMENU_ABILITY:
            battle_update_submenu_ability();
            break;
        case BATTLE_PHASE.PLAYER_SUBMENU_ITEM:
            battle_update_submenu_item();
            break;
        case BATTLE_PHASE.TURN_EXECUTION:
            battle_update_turn_execution();
            break;
        case BATTLE_PHASE.VICTORY:
            if (global.input.nav_confirm || global.input.mb_left_pressed) {
                battle_end_return_to_map();
            }
            break;
        case BATTLE_PHASE.DEFEAT:
            // Deliberate, gradual fade-out transition away from the battle scene
            global.battle.defeat_fade_timer++;
            if (global.battle.defeat_fade_timer >= 95 ||
                (global.battle.defeat_fade_timer >= 35 && (global.input.nav_confirm || global.input.mb_left_pressed))) {
                battle_handle_party_defeat();
            }
            break;
    }
}

function battle_update_player_command() {
    if (global.input.nav_left || global.input.nav_up) {
        global.battle.command_idx = (global.battle.command_idx + 4) mod 5;
        core_audio_play_sfx_ui("ui_move");
    } else if (global.input.nav_right || global.input.nav_down) {
        global.battle.command_idx = (global.battle.command_idx + 1) mod 5;
        core_audio_play_sfx_ui("ui_move");
    } else if (global.input.nav_confirm) {
        battle_activate_command(global.battle.command_idx);
    }
}

function battle_activate_command(_cmd_idx) {
    var _actor = global.runtime.party[global.battle.active_actor_idx];
    core_audio_play_sfx_ui("ui_select");
    
    switch (_cmd_idx) {
        case 0: // Attack
            battle_queue_player_action({ type: "attack", actor: _actor });
            break;
        case 1: // Abilities (PSI / Star Skills)
            global.battle.submenu_idx = 0;
            global.battle.phase = BATTLE_PHASE.PLAYER_SUBMENU_ABILITY;
            input_consume_all();
            break;
        case 2: // Items
            global.battle.submenu_idx = 0;
            global.battle.phase = BATTLE_PHASE.PLAYER_SUBMENU_ITEM;
            input_consume_all();
            break;
        case 3: // Defend
            battle_queue_player_action({ type: "defend", actor: _actor });
            break;
        case 4: // Run
            var _allow_run = (!is_undefined(global.project) && variable_struct_exists(global.project.combat_config, "allow_run"))
                ? global.project.combat_config.allow_run : true;
            if (!_allow_run) {
                battle_add_log("* Cannot run from this battle!");
            } else {
                battle_queue_player_action({ type: "run", actor: _actor });
            }
            break;
    }
}

function battle_update_submenu_ability() {
    if (global.input.nav_cancel) {
        core_audio_play_default_sound("menu_cancel");
        global.battle.phase = BATTLE_PHASE.PLAYER_COMMAND;
        input_consume_all();
        return;
    }
    var _actor = global.runtime.party[global.battle.active_actor_idx];
    var _abils = sys_character_get_unlocked_abilities(_actor);
    var _count = array_length(_abils);
    if (_count == 0) return;
    
    var _pp_enabled = sys_project_pp_enabled();
    
    if (global.input.nav_up) {
        global.battle.submenu_idx = (global.battle.submenu_idx + _count - 1) mod _count;
        core_audio_play_default_sound("menu_move");
    } else if (global.input.nav_down) {
        global.battle.submenu_idx = (global.battle.submenu_idx + 1) mod _count;
        core_audio_play_default_sound("menu_move");
    } else if (global.input.nav_confirm) {
        var _chosen = _abils[global.battle.submenu_idx];
        if (_pp_enabled && _actor.current_mp < _chosen.mp_cost) {
            core_audio_play_default_sound("menu_cancel");
            battle_add_log("* Not enough PP/MP for " + _chosen.name + "!");
        } else {
            core_audio_play_default_sound("menu_confirm");
            battle_queue_player_action({ type: "ability", actor: _actor, ability: _chosen });
        }
    }
}

function battle_update_submenu_item() {
    if (global.input.nav_cancel) {
        core_audio_play_default_sound("menu_cancel");
        global.battle.phase = BATTLE_PHASE.PLAYER_COMMAND;
        input_consume_all();
        return;
    }
    var _inv = global.runtime.inventory;
    var _count = array_length(_inv);
    if (_count == 0) return;
    
    if (global.input.nav_up) {
        global.battle.submenu_idx = (global.battle.submenu_idx + _count - 1) mod _count;
        core_audio_play_default_sound("menu_move");
    } else if (global.input.nav_down) {
        global.battle.submenu_idx = (global.battle.submenu_idx + 1) mod _count;
        core_audio_play_default_sound("menu_move");
    } else if (global.input.nav_confirm) {
        core_audio_play_default_sound("menu_confirm");
        var _actor = global.runtime.party[global.battle.active_actor_idx];
        var _entry = _inv[global.battle.submenu_idx];
        battle_queue_player_action({ type: "item", actor: _actor, item_id: _entry.item_id });
    }
}

function battle_queue_player_action(_action) {
    global.battle.turn_queue = [];
    _action.speed = sys_stats_get_effective_speed(_action.actor);
    array_push(global.battle.turn_queue, _action);
    
    // Queue Enemy AI actions
    for (var i = 0; i < array_length(global.battle.enemies); i++) {
        var _en = global.battle.enemies[i];
        if (_en.current_hp > 0) {
            array_push(global.battle.turn_queue, {
                type: "enemy_turn",
                enemy: _en,
                speed: _en.speed
            });
        }
    }
    
    // Sort turn order by Speed descending
    if (array_length(global.battle.turn_queue) == 2) {
        if (global.battle.turn_queue[1].speed > global.battle.turn_queue[0].speed) {
            var _tmp = global.battle.turn_queue[0];
            global.battle.turn_queue[0] = global.battle.turn_queue[1];
            global.battle.turn_queue[1] = _tmp;
        }
    }
    
    global.battle.turn_step_idx = 0;
    global.battle.turn_wait_timer = 15;
    global.battle.phase = BATTLE_PHASE.TURN_EXECUTION;
    input_consume_all();
}

function battle_update_turn_execution() {
    if (global.battle.turn_wait_timer > 0) {
        global.battle.turn_wait_timer--;
        return;
    }
    
    if (global.battle.turn_step_idx >= array_length(global.battle.turn_queue)) {
        // Check end-of-round conditions
        if (sys_party_is_defeated()) {
            core_audio_play_default_sound("battle_defeat");
            battle_add_log("* The party lost consciousness...");
            global.battle.phase = BATTLE_PHASE.DEFEAT;
            global.battle.defeat_fade_timer = 0;
            return;
        }
        var _enemy = global.battle.enemies[0];
        if (_enemy.current_hp <= 0) {
            battle_enter_victory();
            return;
        }
        global.battle.phase = BATTLE_PHASE.PLAYER_COMMAND;
        return;
    }
    
    var _act = global.battle.turn_queue[global.battle.turn_step_idx];
    global.battle.turn_step_idx++;
    global.battle.turn_wait_timer = 42;
    
    var _foe = global.battle.enemies[0];
    var _hero = global.runtime.party[0];
    var _pp_enabled = sys_project_pp_enabled();
    
    switch (_act.type) {
        case "attack":
            if (_hero.current_hp <= 0 || _foe.current_hp <= 0) break;
            core_audio_play_default_sound("battle_attack");
            var _res = battle_calculate_damage(
                sys_stats_get_effective_attack(_hero),
                _foe.defense,
                0,
                false,
                false,
                false
            );
            _foe.current_hp = max(0, _foe.current_hp - _res.damage);
            global.battle.enemy_flash_timer = 16;
            if (_res.is_crit) {
                core_audio_play_default_sound("battle_crit");
            } else {
                core_audio_play_default_sound("battle_damage");
            }
            
            // Distinguish ordinary damage vs mortal/fatal damage that actually defeats the enemy
            if (_foe.current_hp <= 0) {
                core_audio_play_default_sound("battle_enemy_defeated");
                if (_res.is_crit) {
                    battle_add_log("* SMAAAASH!! " + _hero.name + " dealt " + string(_res.damage) + " mortal damage to " + _foe.name + "!");
                } else {
                    battle_add_log("* " + _hero.name + " attacks! Dealt " + string(_res.damage) + " mortal damage to " + _foe.name + "!");
                }
                battle_enter_victory();
                return;
            } else {
                if (_res.is_crit) {
                    battle_add_log("* SMAAAASH!! " + _hero.name + " dealt " + string(_res.damage) + " damage to " + _foe.name + "!");
                } else {
                    battle_add_log("* " + _hero.name + " attacks! Dealt " + string(_res.damage) + " damage to " + _foe.name + "!");
                }
            }
            break;
            
        case "ability":
            if (_hero.current_hp <= 0) break;
            var _ab = _act.ability;
            if (_pp_enabled) {
                _hero.current_mp = max(0, _hero.current_mp - _ab.mp_cost);
            }
            if (variable_struct_exists(_ab, "is_healing") && _ab.is_healing) {
                var _old_hp = _hero.current_hp;
                _hero.current_hp = min(_hero.max_hp, _hero.current_hp + _ab.power);
                _hero.rolling_hp = _hero.current_hp;
                var _healed = _hero.current_hp - _old_hp;
                core_audio_play_default_sound("battle_heal");
                battle_add_log("* " + _hero.name + " used " + _ab.name + "! Recovered " + string(_healed) + " HP!");
            } else {
                core_audio_play_default_sound("battle_attack");
                var _is_weak = (_foe.weakness == "star");
                var _ares = battle_calculate_damage(
                    sys_stats_get_effective_attack(_hero),
                    _foe.defense,
                    _ab.power,
                    _is_weak,
                    false,
                    false
                );
                _foe.current_hp = max(0, _foe.current_hp - _ares.damage);
                global.battle.enemy_flash_timer = 20;
                if (_ares.is_crit) {
                    core_audio_play_default_sound("battle_crit");
                } else {
                    core_audio_play_default_sound("battle_damage");
                }
                if (_foe.current_hp <= 0) {
                    core_audio_play_default_sound("battle_enemy_defeated");
                    battle_add_log("* " + _hero.name + " used " + _ab.name + "! Dealt " + string(_ares.damage) + " mortal damage to " + _foe.name + "!");
                    battle_enter_victory();
                    return;
                } else {
                    battle_add_log("* " + _hero.name + " used " + _ab.name + "! Dealt " + string(_ares.damage) + " damage to " + _foe.name + "!");
                }
            }
            break;
            
        case "item":
            var _use_res = sys_inventory_use_item(_act.item_id, _hero, true);
            battle_add_log("* " + _use_res.message);
            break;
            
        case "defend":
            _hero.is_defending = true;
            battle_add_log("* " + _hero.name + " is on guard!");
            break;
            
        case "run":
            if (random(1.0) < 0.75) {
                battle_add_log("* Got away safely!");
                global.runtime.battle_grace_timer = 90;
                battle_end_return_to_map();
                return;
            } else {
                battle_add_log("* Tried to run, but couldn't get away!");
            }
            break;
            
        case "enemy_turn":
            var _en = _act.enemy;
            if (_en.current_hp <= 0 || _hero.current_hp <= 0) break;
            
            var _skill_name = "Attack";
            var _skill_pow = 0;
            if (array_length(_en.abilities) > 0 && irandom(100) < 45) {
                var _pick = _en.abilities[irandom(array_length(_en.abilities) - 1)];
                _skill_name = _pick.name;
                _skill_pow = _pick.power;
            }
            var _eres = battle_calculate_damage(
                _en.attack,
                sys_stats_get_effective_defense(_hero),
                _skill_pow,
                false,
                false,
                variable_struct_exists(_hero, "is_defending") ? _hero.is_defending : false
            );
            _hero.current_hp = max(0, _hero.current_hp - _eres.damage);
            camera_runtime_trigger_shake(12, 4);
            if (_eres.is_crit) {
                core_audio_play_default_sound("battle_crit");
            } else {
                core_audio_play_default_sound("battle_damage");
            }
            
            // Only use "mortal damage" wording when the attack actually defeats the character!
            if (_hero.current_hp <= 0) {
                _hero.rolling_hp = 0;
                core_audio_play_default_sound("battle_defeat");
                battle_add_log("* " + _en.name + " used " + _skill_name + "! " + _hero.name + " took " + string(_eres.damage) + " mortal damage!");
                battle_add_log("* " + _hero.name + " got hurt and collapsed...");
                global.battle.phase = BATTLE_PHASE.DEFEAT;
                global.battle.defeat_fade_timer = 0;
                return;
            } else {
                battle_add_log("* " + _en.name + " used " + _skill_name + "! " + _hero.name + " took " + string(_eres.damage) + " damage!");
            }
            break;
    }
}

function battle_enter_victory() {
    global.battle.phase = BATTLE_PHASE.VICTORY;
    core_audio_play_default_sound("battle_victory");
    var _foe = global.battle.enemies[0];
    var _exp = _foe.reward_exp;
    var _gold = _foe.reward_gold;
    
    global.runtime.gold += _gold;
    global.runtime.stats_telemetry.battles_won++;
    global.runtime.stats_telemetry.enemies_defeated++;
    global.runtime.stats_telemetry.total_gold_earned += _gold;
    global.runtime.stats_telemetry.total_exp_earned += _exp;
    
    battle_add_log("* " + _foe.name + " was defeated! Gained " + string(_exp) + " EXP and $" + string(_gold) + " Gold!");
    
    for (var i = 0; i < array_length(global.runtime.party); i++) {
        var _m = global.runtime.party[i];
        _m.rolling_hp = _m.current_hp;
        var _lvl_ups = sys_leveling_add_exp(_m, _exp);
        for (var l = 0; l < array_length(_lvl_ups); l++) {
            battle_add_log("* " + _lvl_ups[l]);
        }
    }
    
    // Item reward
    if (_foe.reward_item_id != "") {
        sys_inventory_add_item(_foe.reward_item_id, 1);
        var _idef = sys_item_find_def(_foe.reward_item_id);
        var _iname = is_struct(_idef) ? _idef.name : _foe.reward_item_id;
        battle_add_log("* The enemy left behind a present: " + _iname + "!");
    }
    
    // Apply defeat behavior to the overworld enemy instance
    var _ow = global.battle.overworld_instance_ref;
    if (is_struct(_ow)) {
        _ow.defeated = true;
        if (_ow.defeat_mode == ENEMY_DEFEAT_MODE.DISAPPEAR_PERMANENT) {
            variable_struct_set(global.runtime.defeated_enemies, _ow.instance_key, true);
        } else if (_ow.defeat_mode == ENEMY_DEFEAT_MODE.RESPAWN_TIMED) {
            _ow.respawn_timer = max(60, _ow.respawn_seconds * 60);
        }
        if (variable_struct_exists(_ow, "defeat_var") && _ow.defeat_var != "") {
            sys_variable_set(_ow.defeat_var, true);
        }
    }
    
    // Trigger configured post-battle event
    if (_foe.reward_event_id != "") {
        sys_event_trigger_by_id(_foe.reward_event_id);
    }
}

function battle_end_return_to_map() {
    global.battle.active = false;
    global.battle.enemies = [];
    global.battle.overworld_instance_ref = undefined;
    global.runtime.battle_grace_timer = 60;
    scene_switch_to(ENGINE_SCENE.RUNTIME_PLAY);
}

function battle_handle_party_defeat() {
    // Clear active battle state so player can never accidentally return to the defeated battle
    global.battle.active = false;
    global.battle.enemies = [];
    global.battle.overworld_instance_ref = undefined;
    global.battle.gameover_timer = 0;
    global.battle.gameover_option_idx = 0;
    global.battle.gameover_load_open = false;
    global.battle.gameover_slot_idx = 0;
    scene_switch_to(ENGINE_SCENE.GAME_OVER);
}

function battle_draw_gui() {
    var _pal = global.palette;
    camera_runtime_sync_aspect_ratio();
    var _cam = global.camera.runtime;
    var _vx1 = _cam.viewport_x;
    var _vw = _cam.viewport_w;
    var _vcx = _vx1 + (_vw * 0.5);
    var _pp_enabled = sys_project_pp_enabled();
    
    // 1. EarthBound-inspired Geometric Wave Background
    var _phase = global.battle.bg_wave_phase;
    draw_rectangle_color(_vx1, 0, _vx1 + _vw, STARLIGHT_BASE_HEIGHT,
        make_color_rgb(14, 10, 36), make_color_rgb(28, 14, 58),
        make_color_rgb(10, 22, 48), make_color_rgb(18, 12, 40), false);
        
    for (var b = 0; b < 12; b++) {
        var _by = (b * 64) + sin(_phase + b * 0.6) * 18;
        var _col = (b mod 2 == 0) ? make_color_rgb(44, 24, 92) : make_color_rgb(24, 52, 102);
        draw_set_alpha(0.32);
        draw_set_color(_col);
        draw_rectangle(_vx1, _by, _vx1 + _vw, _by + 28, false);
    }
    draw_set_alpha(1.0);
    
    // 2. Top Battle Narration Window (scales to fit 16:9 or 8:7 cleanly)
    var _log_x1 = _vx1 + 24;
    var _log_x2 = _vx1 + _vw - 24;
    render_window_frame(_log_x1, 24, _log_x2, 156, "BATTLE LOG", _pal.border_outer);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(_pal.text_primary);
    for (var i = 0; i < array_length(global.battle.log_lines); i++) {
        draw_text(_log_x1 + 20, 66 + i * 28, render_fit_text(global.battle.log_lines[i], (_log_x2 - _log_x1) - 40));
    }
    
    // 3. Center Enemy Showcase
    if (array_length(global.battle.enemies) > 0) {
        var _foe = global.battle.enemies[0];
        var _ex = _vcx - 64;
        var _ey = 216;
        
        if (_foe.current_hp > 0) {
            var _flash = (global.battle.enemy_flash_timer mod 4 >= 2);
            var _tint = _flash ? c_white : make_color_rgb(235, 76, 96);
            var _bfps = core_assets_get_anim_fps(_foe.sprite_id, "Idle", DIR_FACING.DOWN);
            var _bframe = global.engine.frame_counter * (_bfps / 60.0);
            var _f_sc = variable_struct_exists(_foe, "sprite_scale") ? sys_sprite_clamp_scale(_foe.sprite_scale) : 1.0;
            core_assets_draw_entity_sprite_scaled(_foe.sprite_id, "Idle", _bframe, _ex, _ey, 128, 128, DIR_FACING.DOWN, _tint, _f_sc, true);
            
            // Enemy Name & HP Bar
            render_window_frame(_ex - 48, _ey + 136, _ex + 176, _ey + 196, "", _pal.accent_magenta);
            draw_set_halign(fa_center);
            draw_set_color(_pal.text_primary);
            draw_text(_ex + 64, _ey + 144, _foe.name);
            var _hp_pct = clamp(_foe.current_hp / max(1, _foe.max_hp), 0, 1);
            draw_set_color(make_color_rgb(40, 16, 28));
            draw_rectangle(_ex - 24, _ey + 172, _ex + 152, _ey + 184, false);
            draw_set_color(_pal.accent_green);
            draw_rectangle(_ex - 24, _ey + 172, _ex - 24 + (176 * _hp_pct), _ey + 184, false);
        }
    }
    
    // 4. Bottom EarthBound-Style Party Status Cards with Rolling HP Drum
    var _party = global.runtime.party;
    var _pcount = array_length(_party);
    var _card_w = 240;
    var _total_w = _pcount * _card_w + max(0, _pcount - 1) * 16;
    var _start_x = _vcx - (_total_w * 0.5);
    var _cy1 = 528;
    var _cy2 = 696;
    
    for (var p = 0; p < _pcount; p++) {
        var _pm = _party[p];
        var _cx1 = _start_x + p * (_card_w + 16);
        var _cx2 = _cx1 + _card_w;
        render_window_frame(_cx1, _cy1, _cx2, _cy2, _pm.name + "  Lv." + string(_pm.level), _pal.accent_gold);
        
        // Rolling HP Odometer Display
        var _disp_hp = round(variable_struct_exists(_pm, "rolling_hp") ? _pm.rolling_hp : _pm.current_hp);
        draw_set_halign(fa_left);
        draw_set_color(_pal.text_secondary);
        draw_text(_cx1 + 16, _cy1 + 48, "HP");
        draw_set_color(_disp_hp <= (_pm.max_hp * 0.25) ? _pal.accent_red : _pal.accent_green);
        draw_text(_cx1 + 64, _cy1 + 48, string(_disp_hp) + " / " + string(_pm.max_hp));
        
        if (_pp_enabled) {
            draw_set_color(_pal.text_secondary);
            draw_text(_cx1 + 16, _cy1 + 80, "PP");
            draw_set_color(_pal.accent_cyan);
            draw_text(_cx1 + 64, _cy1 + 80, string(_pm.current_mp) + " / " + string(_pm.max_mp));
            
            draw_set_color(_pal.text_muted);
            draw_text(_cx1 + 16, _cy1 + 114, "EXP: " + string(_pm.exp) + "/" + string(sys_leveling_exp_for_next_level(_pm)));
        } else {
            draw_set_color(_pal.text_muted);
            draw_text(_cx1 + 16, _cy1 + 88, "EXP: " + string(_pm.exp) + "/" + string(sys_leveling_exp_for_next_level(_pm)));
        }
    }
    
    // 5. Command Bar / Submenus
    if (global.battle.phase == BATTLE_PHASE.PLAYER_COMMAND) {
        var _cmds = ["Attack", "Abilities", "Items", "Defend", "Run"];
        var _gap = 10;
        var _bw = floor(((_vw - 48) - (_gap * 4)) / 5);
        var _bx0 = _vx1 + 24;
        for (var c = 0; c < 5; c++) {
            var _bx1 = _bx0 + c * (_bw + _gap);
            var _bx2 = _bx1 + _bw;
            if (input_mouse_in_rect(_bx1, 462, _bx2, 512)) {
                global.battle.command_idx = c;
            }
            if (render_ui_button(_bx1, 462, _bx2, 512, _cmds[c], (global.battle.command_idx == c), true)) {
                battle_activate_command(c);
                return;
            }
        }
    } else if (global.battle.phase == BATTLE_PHASE.PLAYER_SUBMENU_ABILITY) {
        var _sx1 = _vx1 + 36;
        var _sx2 = _vx1 + _vw - 36;
        render_window_frame(_sx1, 250, _sx2, 512, "SELECT ABILITY (X / ESC TO CANCEL)", _pal.accent_cyan);
        var _actor = _party[global.battle.active_actor_idx];
        var _abils = sys_character_get_unlocked_abilities(_actor);
        if (array_length(_abils) == 0) {
            draw_set_color(_pal.text_secondary);
            draw_text(_sx1 + 24, 304, "No abilities learned yet.");
        } else {
            for (var a = 0; a < array_length(_abils); a++) {
                var _ab = _abils[a];
                var _ay1 = 296 + a * 46;
                var _cost_str = _pp_enabled ? ("  (PP: " + string(_ab.mp_cost) + ")") : "";
                var _label = _ab.name + _cost_str + " — " + _ab.description;
                var _can_use = !_pp_enabled || (_actor.current_mp >= _ab.mp_cost);
                if (render_ui_button(_sx1 + 20, _ay1, _sx2 - 20, _ay1 + 40, _label, (global.battle.submenu_idx == a), _can_use)) {
                    battle_queue_player_action({ type: "ability", actor: _actor, ability: _ab });
                    return;
                }
            }
        }
    } else if (global.battle.phase == BATTLE_PHASE.PLAYER_SUBMENU_ITEM) {
        var _ix1 = _vx1 + 36;
        var _ix2 = _vx1 + _vw - 36;
        render_window_frame(_ix1, 250, _ix2, 512, "SELECT ITEM (X / ESC TO CANCEL)", _pal.accent_gold);
        var _inv = global.runtime.inventory;
        if (array_length(_inv) == 0) {
            draw_set_color(_pal.text_secondary);
            draw_text(_ix1 + 24, 304, "Inventory is empty.");
        } else {
            var _max_vis = min(4, array_length(_inv));
            for (var it = 0; it < _max_vis; it++) {
                var _slot = _inv[it];
                var _iy1 = 296 + it * 46;
                var _ilabel = _slot.name + " x" + string(_slot.quantity);
                if (render_ui_button(_ix1 + 20, _iy1, _ix2 - 20, _iy1 + 40, _ilabel, (global.battle.submenu_idx == it), true)) {
                    battle_queue_player_action({ type: "item", actor: _party[0], item_id: _slot.item_id });
                    return;
                }
            }
        }
    } else if (global.battle.phase == BATTLE_PHASE.VICTORY) {
        if (render_ui_button(_vcx - 160, 462, _vcx + 160, 512, "Continue Adventure (Z / Enter)", true, true)) {
            battle_end_return_to_map();
        }
    } else if (global.battle.phase == BATTLE_PHASE.DEFEAT) {
        // Deliberate dark fade overlay over the battle scene before transitioning to Game Over
        var _fade_a = clamp(global.battle.defeat_fade_timer / 75.0, 0.0, 1.0);
        draw_set_alpha(_fade_a);
        draw_set_color(make_color_rgb(4, 2, 10));
        draw_rectangle(0, 0, STARLIGHT_BASE_WIDTH, STARLIGHT_BASE_HEIGHT, false);
        draw_set_alpha(1.0);
    }
    
    // Draw 8:7 aspect ratio pillarbox if enabled
    runtime_draw_aspect_frame();
}

// ============================================================================
// DRAMATIC GAME OVER PRESENTATION (Load a Save | Quit To Menu — No Saving)
// ============================================================================

function gameover_update() {
    global.battle.gameover_timer++;
    core_starfield_update();
    
    if (global.battle.gameover_load_open) {
        if (global.input.nav_cancel) {
            global.battle.gameover_load_open = false;
            core_audio_play_sfx_ui("ui_cancel");
            input_consume_all();
            return;
        }
        var _slots = core_game_get_save_slots(4);
        if (global.input.nav_up) {
            global.battle.gameover_slot_idx = (global.battle.gameover_slot_idx + 3) mod 4;
            core_audio_play_sfx_ui("ui_move");
        } else if (global.input.nav_down) {
            global.battle.gameover_slot_idx = (global.battle.gameover_slot_idx + 1) mod 4;
            core_audio_play_sfx_ui("ui_move");
        } else if (global.input.nav_confirm) {
            var _sel_slot = _slots[global.battle.gameover_slot_idx];
            if (_sel_slot.exists && !_sel_slot.corrupted) {
                gameover_execute_load_slot(_sel_slot.slot);
            } else {
                core_log_toast("Slot " + string(_sel_slot.slot) + " has no valid save data.");
            }
            input_consume_all();
        }
        return;
    }
    
    // Wait briefly during the dramatic title fade-in before accepting option input
    if (global.battle.gameover_timer < 25) return;
    
    if (global.input.nav_left || global.input.nav_up || global.input.nav_right || global.input.nav_down) {
        global.battle.gameover_option_idx = 1 - global.battle.gameover_option_idx;
        core_audio_play_sfx_ui("ui_move");
    } else if (global.input.nav_confirm) {
        core_audio_play_sfx_ui("ui_select");
        if (global.battle.gameover_option_idx == 0) {
            global.battle.gameover_load_open = true;
            global.battle.gameover_slot_idx = 0;
        } else {
            gameover_quit_to_menu();
        }
        input_consume_all();
    }
}

function gameover_execute_load_slot(_slot_num) {
    global.battle.active = false;
    global.battle.enemies = [];
    global.battle.overworld_instance_ref = undefined;
    global.battle.gameover_load_open = false;
    if (core_game_load_slot(_slot_num)) {
        global.runtime.battle_grace_timer = 120;
        scene_switch_to(ENGINE_SCENE.RUNTIME_PLAY);
    }
}

function gameover_quit_to_menu() {
    global.battle.active = false;
    global.battle.enemies = [];
    global.battle.overworld_instance_ref = undefined;
    global.battle.gameover_load_open = false;
    if (global.playtest_active && !is_undefined(global.playtest_snapshot)) {
        global.project = json_parse(global.playtest_snapshot);
        global.playtest_snapshot = undefined;
        global.playtest_active = false;
    }
    scene_switch_to(ENGINE_SCENE.MAIN_MENU);
}

function gameover_draw_gui() {
    var _pal = global.palette;
    camera_runtime_sync_aspect_ratio();
    var _cam = global.camera.runtime;
    var _vx1 = _cam.viewport_x;
    var _vw = _cam.viewport_w;
    var _vcx = _vx1 + (_vw * 0.5);
    var _t = global.battle.gameover_timer;
    
    // Deep crimson-navy cosmic void backdrop
    draw_rectangle_color(0, 0, STARLIGHT_BASE_WIDTH, STARLIGHT_BASE_HEIGHT,
        make_color_rgb(4, 2, 10), make_color_rgb(4, 2, 10),
        make_color_rgb(24, 6, 18), make_color_rgb(16, 4, 22), false);
        
    // Dim drifting embers in the void
    if (variable_global_exists("starfield") && !is_undefined(global.starfield)) {
        var _stars = global.starfield.stars;
        for (var i = 0; i < array_length(_stars); i += 2) {
            var _s = _stars[i];
            draw_set_alpha(0.25);
            draw_set_color(_pal.accent_red);
            draw_rectangle(_s.x, _s.y, _s.x + _s.size, _s.y + _s.size, false);
        }
        draw_set_alpha(1.0);
    }
    
    var _title_alpha = clamp(_t / 45.0, 0.0, 1.0);
    draw_set_alpha(_title_alpha);
    
    // Dramatic GAME OVER Title Banner
    draw_set_font(fnt_starlight_title);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_black);
    draw_text(_vcx + 3, 143, "G A M E   O V E R");
    draw_set_color(_pal.accent_red);
    draw_text(_vcx, 140, "G A M E   O V E R");
    
    draw_set_font(fnt_starlight_ui);
    draw_set_color(_pal.accent_gold);
    draw_text(_vcx, 196, "The starlight faded into the cosmic void...");
    draw_set_color(_pal.text_secondary);
    draw_text(_vcx, 228, "Yet your determination echoes across the stars.");
    draw_set_alpha(1.0);
    
    if (global.battle.gameover_load_open) {
        // Load-Only Save Slot Selector (Saving is strictly forbidden on Game Over)
        var _lx1 = _vx1 + 40;
        var _lx2 = _vx1 + _vw - 40;
        render_window_frame(_lx1, 260, _lx2, 668, "LOAD A SAVE FILE (SAVING DISABLED ON GAME OVER)", _pal.accent_cyan);
        
        var _slots = core_game_get_save_slots(4);
        var _any_valid = false;
        for (var v = 0; v < array_length(_slots); v++) {
            if (_slots[v].exists && !_slots[v].corrupted) _any_valid = true;
        }
        
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        if (!_any_valid) {
            draw_set_color(_pal.accent_red);
            draw_text(_lx1 + 24, 302, "No valid save files exist for this project. Choose 'Back' or 'Quit To Menu'.");
        }
        
        for (var s = 0; s < array_length(_slots); s++) {
            var _sl = _slots[s];
            var _sy1 = 332 + s * 68;
            var _sy2 = _sy1 + 60;
            var _is_sel = (global.battle.gameover_slot_idx == s);
            draw_set_color(_is_sel ? make_color_rgb(32, 38, 72) : _pal.panel_alt);
            draw_rectangle(_lx1 + 20, _sy1, _lx2 - 20, _sy2, false);
            draw_set_color(_is_sel ? _pal.accent_gold : (_sl.exists ? _pal.accent_cyan : _pal.border_inner));
            draw_rectangle(_lx1 + 20, _sy1, _lx2 - 20, _sy2, true);
            
            draw_set_color(_pal.accent_gold);
            draw_text(_lx1 + 34, _sy1 + 8, "SLOT " + string(_sl.slot) + ": " + _sl.save_name);
            draw_set_color(_pal.text_secondary);
            draw_text(_lx1 + 34, _sy1 + 32, "Map: " + _sl.map_name + "  |  Time: " + sys_stats_format_playtime(_sl.playtime_seconds));
            
            // ONLY Load button — NO Save button on Game Over screen
            if (render_ui_button(_lx2 - 170, _sy1 + 10, _lx2 - 34, _sy2 - 10, "Load Save", _is_sel, _sl.exists && !_sl.corrupted)) {
                gameover_execute_load_slot(_sl.slot);
                return;
            }
        }
        
        if (render_ui_button(_lx1 + 20, 614, _lx1 + 220, 654, "Back (X / Esc)", false, true)) {
            global.battle.gameover_load_open = false;
            return;
        }
        if (render_ui_button(_lx2 - 240, 614, _lx2 - 20, 654, "Quit To Menu", false, true)) {
            gameover_quit_to_menu();
            return;
        }
    } else if (_t >= 25) {
        // Primary Game Over Choices: Load a Save | Quit To Menu
        var _card_w = min(560, _vw - 80);
        var _cx1 = _vcx - (_card_w * 0.5);
        var _cx2 = _vcx + (_card_w * 0.5);
        render_window_frame(_cx1, 310, _cx2, 520, "CHOOSE YOUR FATE", _pal.accent_red);
        
        var _b1_y1 = 368;
        var _b2_y1 = 436;
        if (input_mouse_in_rect(_cx1 + 40, _b1_y1, _cx2 - 40, _b1_y1 + 50)) global.battle.gameover_option_idx = 0;
        if (input_mouse_in_rect(_cx1 + 40, _b2_y1, _cx2 - 40, _b2_y1 + 50)) global.battle.gameover_option_idx = 1;
        
        if (render_ui_button(_cx1 + 40, _b1_y1, _cx2 - 40, _b1_y1 + 50, "Load a Save", (global.battle.gameover_option_idx == 0), true)) {
            global.battle.gameover_load_open = true;
            global.battle.gameover_slot_idx = 0;
            return;
        }
        if (render_ui_button(_cx1 + 40, _b2_y1, _cx2 - 40, _b2_y1 + 50, "Quit To Menu", (global.battle.gameover_option_idx == 1), true)) {
            gameover_quit_to_menu();
            return;
        }
    }
    
    runtime_draw_aspect_frame();
}
