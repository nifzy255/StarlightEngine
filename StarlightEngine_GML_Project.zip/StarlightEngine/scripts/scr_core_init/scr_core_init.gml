/// @description ST★RLIGHT ENGINE - Core Initialization & Boot System
/// Initializes all engine singletons, enumerations, starfield background, and project directories.

#macro STARLIGHT_ENGINE_NAME "ST★RLIGHT ENGINE"
#macro STARLIGHT_VERSION_STRING "1.0.0"
#macro STARLIGHT_SCHEMA_VERSION 1
#macro STARLIGHT_BASE_WIDTH 1280
#macro STARLIGHT_BASE_HEIGHT 720

enum ENGINE_SCENE {
    MAIN_MENU = 0,
    PROJECTS_MENU = 1,
    SETTINGS_MENU = 2,
    CREDITS_MENU = 3,
    EDITOR = 4,
    RUNTIME_PLAY = 5,
    RUNTIME_BATTLE = 6,
    GAME_OVER = 7
}

enum PROJECTS_SUBMENU {
    ROOT = 0,
    NEW_PROJECT = 1,
    SAVED_PROJECTS = 2,
    DELETE_CONFIRM = 3,
    IMPORT_CONFIRM = 4
}

enum EDITOR_TOOL {
    COLLISION = 0,
    TILES = 1,
    EVENTS = 2,
    OBJECTS = 3,
    NPCS = 4,
    ENEMIES = 5
}

enum EDITOR_MODAL {
    NONE = 0,
    TILE_SELECTOR = 1,
    EVENT_INSPECTOR = 2,
    OBJECT_INSPECTOR = 3,
    NPC_INSPECTOR = 4,
    ENEMY_INSPECTOR = 5,
    CHARACTER_MANAGER = 6,
    ITEM_MANAGER = 7,
    VARIABLE_MANAGER = 8,
    AUDIO_MANAGER = 9,
    SPRITE_MANAGER = 10,
    PROJECT_MANAGER = 11,
    MAP_MANAGER = 12,
    UNSAVED_CONFIRM = 13
}

enum MOUSE_EDIT_MODE {
    PLACE = 0,
    ERASE = 1
}

enum MAP_LAYER_TYPE {
    BACKGROUND = 0,
    GROUND = 1,
    DECORATIONS = 2,
    FOREGROUND = 3
}

enum DIR_FACING {
    DOWN = 0,
    LEFT = 1,
    RIGHT = 2,
    UP = 3
}

enum NPC_MOVE_MODE {
    STAY_STILL = 0,
    WANDER_RADIUS = 1,
    SCRIPTED_PATH = 2,
    REPEAT_SCRIPTED_PATH = 3
}

enum ENEMY_AI_MODE {
    CHASE_PLAYER = 0,
    RUN_AWAY = 1,
    IGNORE_PLAYER = 2,
    STOP_WHEN_NEARBY = 3,
    STAY_STILL = 4,
    WANDER_RADIUS = 5
}

enum ENEMY_DEFEAT_MODE {
    DISAPPEAR_PERMANENT = 0,
    RESPAWN_ON_REENTRY = 1,
    RESPAWN_TIMED = 2
}

enum EVENT_TRIGGER_MODE {
    AUTOMATIC = 0,
    PLAYER_INTERACT = 1,
    CONDITIONAL = 2
}

enum VAR_TYPE {
    BOOLEAN = 0,
    INTEGER = 1,
    DECIMAL = 2,
    STRING = 3
}

enum ITEM_CATEGORY {
    CONSUMABLE = 0,
    HEALING = 1,
    WEAPON = 2,
    ARMOR = 3,
    ACCESSORY = 4,
    KEY_ITEM = 5
}

/// @function starlight_engine_boot()
/// @description Master boot sequence called once by obj_engine_controller on Game Start.
function starlight_engine_boot() {
    randomize();
    
    global.engine = {
        initialized: true,
        version: STARLIGHT_VERSION_STRING,
        schema_version: STARLIGHT_SCHEMA_VERSION,
        projects_root: game_save_id + "Projects/",
        bundled_projects_root: working_directory + "Projects/",
        frame_counter: 0,
        delta_seconds: 1 / 60
    };
    
    // Initialize core subsystems in dependency order
    core_error_init();
    core_config_init();
    core_input_init();
    core_render_init();
    core_camera_init();
    core_assets_init();
    core_audio_init();
    core_scene_init();
    core_starfield_init(180);
    
    // Ensure writable Projects directory exists and provision Demo RPG if needed
    core_saveload_ensure_directories();
    
    // Initialize runtime, editor, and battle state containers
    global.project = undefined;
    global.project_path = "";
    global.project_dirty = false;
    global.playtest_active = false;
    global.playtest_snapshot = undefined;
    
    editor_init_state();
    runtime_init_state();
    battle_init_state();
    
    core_log_info("ST★RLIGHT ENGINE v" + STARLIGHT_VERSION_STRING + " initialized successfully.");
}

/// @function core_starfield_init(_star_count)
/// @description Creates the outer-space horizontal parallax starfield used across menus.
function core_starfield_init(_star_count) {
    var _stars = array_create(_star_count);
    for (var i = 0; i < _star_count; i++) {
        var _depth_tier = irandom_range(0, 2); // 0 = far, 1 = mid, 2 = near
        var _spd = 0.35 + (_depth_tier * 0.65) + random(0.45);
        var _size = (_depth_tier == 2) ? 3 : ((_depth_tier == 1) ? 2 : 1);
        var _tint = choose(
            make_color_rgb(240, 244, 255),
            make_color_rgb(190, 215, 255),
            make_color_rgb(255, 238, 195),
            make_color_rgb(210, 190, 255)
        );
        _stars[i] = {
            x: random(STARLIGHT_BASE_WIDTH),
            y: random(STARLIGHT_BASE_HEIGHT),
            speed: _spd,
            size: _size,
            alpha: 0.35 + (_depth_tier * 0.25) + random(0.15),
            twinkle_phase: random(pi * 2),
            twinkle_speed: 0.02 + random(0.04),
            color: _tint
        };
    }
    
    global.starfield = {
        stars: _stars,
        bg_color_top: make_color_rgb(5, 7, 18),
        bg_color_bottom: make_color_rgb(12, 16, 36)
    };
}

/// @function core_starfield_update()
/// @description Advances all stars horizontally and loops them seamlessly across the screen.
function core_starfield_update() {
    if (!variable_global_exists("starfield") || is_undefined(global.starfield)) return;
    var _stars = global.starfield.stars;
    var _count = array_length(_stars);
    for (var i = 0; i < _count; i++) {
        var _s = _stars[i];
        _s.x -= _s.speed;
        if (_s.x < -4) {
            _s.x += STARLIGHT_BASE_WIDTH + 8;
            _s.y = random(STARLIGHT_BASE_HEIGHT);
        }
        _s.twinkle_phase += _s.twinkle_speed;
    }
}
