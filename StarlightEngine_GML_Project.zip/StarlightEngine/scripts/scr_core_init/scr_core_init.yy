{
  "$GMScript": "v1",
  "%Name": "scr_core_init",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_core_init",
  "parent": {
    "name": "Core",
    "path": "folders/Engine/Core.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}