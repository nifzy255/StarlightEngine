/// @description ST★RLIGHT ENGINE - Input Management System
/// Provides debounced single-step keyboard navigation, resize-safe GUI mouse coordinates,
/// modal input isolation, classic RPG keybinds (Z, X, C, Enter, Esc, F4), and text/numeric field capture.

function core_input_init() {
    global.input = {
        // Normalized GUI coordinates (automatically adjusted for window resizing)
        mouse_gui_x: 0,
        mouse_gui_y: 0,
        // World-space coordinates (computed per active camera)
        mouse_world_x: 0,
        mouse_world_y: 0,
        
        // Raw frame states
        mb_left_pressed: false,
        mb_left_held: false,
        mb_left_released: false,
        mb_right_pressed: false,
        mb_right_held: false,
        mb_right_released: false,
        wheel_up: false,
        wheel_down: false,
        
        // Single-step debounced navigation & classic RPG controls
        nav_up: false,
        nav_down: false,
        nav_left: false,
        nav_right: false,
        nav_confirm: false,   // Z / Enter / Space / E
        nav_cancel: false,    // X / Escape / Backspace (Cancel / Close Menu)
        nav_menu: false,      // C / Escape (Open In-Game Menu)
        nav_delete: false,
        
        // Continuous movement axes (-1, 0, 1)
        axis_x: 0,
        axis_y: 0,
        
        // Editor & Engine specific shortcuts
        shortcut_undo: false,
        shortcut_redo: false,
        shortcut_save: false,
        shortcut_toggle_mode: false,
        shortcut_project_mgr: false,
        shortcut_fullscreen: false,
        
        // Frame consumption flags to prevent input leaking across screens/modals
        mouse_consumed: false,
        key_consumed: false,
        scene_transition_lock: 0,
        
        // Active inline text / numeric editing buffer
        text_input_active: false,
        text_input_id: "",
        text_input_buffer: "",
        text_input_original: "",
        text_input_max_len: 120,
        text_input_committed: false,
        text_input_cancelled: false,
        text_input_last_id: ""
    };
}

function core_input_update() {
    var _inp = global.input;
    
    // Always use GUI-mapped coordinates so window resizing never offsets hitboxes
    _inp.mouse_gui_x = device_mouse_x_to_gui(0);
    _inp.mouse_gui_y = device_mouse_y_to_gui(0);
    
    // Reset per-frame consumption and text-commit flags
    _inp.mouse_consumed = false;
    _inp.key_consumed = false;
    _inp.text_input_committed = false;
    _inp.text_input_cancelled = false;
    
    // F4 Fullscreen Toggle works globally across all scenes
    if (keyboard_check_pressed(vk_f4)) {
        global.config.fullscreen = !global.config.fullscreen;
        core_config_apply_display();
        core_config_save();
        core_log_toast("Display Mode: " + (global.config.fullscreen ? "Fullscreen (F4)" : "Windowed (F4)"));
        input_consume_all();
        return;
    }
    
    if (_inp.scene_transition_lock > 0) {
        _inp.scene_transition_lock--;
        _inp.mb_left_pressed = false;
        _inp.mb_left_held = false;
        _inp.mb_left_released = false;
        _inp.mb_right_pressed = false;
        _inp.mb_right_held = false;
        _inp.mb_right_released = false;
        _inp.wheel_up = false;
        _inp.wheel_down = false;
        _inp.nav_up = false;
        _inp.nav_down = false;
        _inp.nav_left = false;
        _inp.nav_right = false;
        _inp.nav_confirm = false;
        _inp.nav_cancel = false;
        _inp.nav_menu = false;
        _inp.nav_delete = false;
        _inp.axis_x = 0;
        _inp.axis_y = 0;
        _inp.shortcut_undo = false;
        _inp.shortcut_redo = false;
        _inp.shortcut_save = false;
        _inp.shortcut_toggle_mode = false;
        _inp.shortcut_project_mgr = false;
        _inp.shortcut_fullscreen = false;
        return;
    }
    
    _inp.mb_left_pressed = mouse_check_button_pressed(mb_left);
    _inp.mb_left_held = mouse_check_button(mb_left);
    _inp.mb_left_released = mouse_check_button_released(mb_left);
    _inp.mb_right_pressed = mouse_check_button_pressed(mb_right);
    _inp.mb_right_held = mouse_check_button(mb_right);
    _inp.mb_right_released = mouse_check_button_released(mb_right);
    _inp.wheel_up = mouse_wheel_up();
    _inp.wheel_down = mouse_wheel_down();
    
    // Handle active text / numeric box input first so typing doesn't fire WASD/Z/X/C shortcuts
    if (_inp.text_input_active) {
        var _typed = keyboard_string;
        if (string_length(_typed) > _inp.text_input_max_len) {
            _typed = string_copy(_typed, 1, _inp.text_input_max_len);
            keyboard_string = _typed;
        }
        _inp.text_input_buffer = _typed;
        
        if (keyboard_check_pressed(vk_escape)) {
            // Escape cancels editing and restores original value
            _inp.text_input_buffer = _inp.text_input_original;
            _inp.text_input_last_id = _inp.text_input_id;
            _inp.text_input_cancelled = true;
            _inp.text_input_active = false;
            _inp.text_input_id = "";
            _inp.key_consumed = true;
            _inp.scene_transition_lock = 2;
        } else if (keyboard_check_pressed(vk_enter)) {
            // Enter confirms editing
            _inp.text_input_last_id = _inp.text_input_id;
            _inp.text_input_committed = true;
            _inp.text_input_active = false;
            _inp.text_input_id = "";
            _inp.key_consumed = true;
            _inp.scene_transition_lock = 2;
        }
        
        var _f1_pressed = keyboard_check_pressed(vk_f1);
        if (_f1_pressed) {
            _inp.text_input_last_id = _inp.text_input_id;
            _inp.text_input_committed = true;
            _inp.text_input_active = false;
            _inp.text_input_id = "";
        }
        
        // Suppress movement/editor hotkeys while typing text
        _inp.nav_up = false;
        _inp.nav_down = false;
        _inp.nav_left = false;
        _inp.nav_right = false;
        _inp.nav_confirm = false;
        _inp.nav_cancel = false;
        _inp.nav_menu = false;
        _inp.nav_delete = false;
        _inp.axis_x = 0;
        _inp.axis_y = 0;
        _inp.shortcut_undo = false;
        _inp.shortcut_redo = false;
        _inp.shortcut_save = false;
        _inp.shortcut_toggle_mode = false;
        _inp.shortcut_project_mgr = _f1_pressed;
        _inp.shortcut_fullscreen = false;
        return;
    }
    
    var _ctrl = keyboard_check(vk_control);
    var _in_editor = (variable_global_exists("scene") && is_struct(global.scene) && global.scene.current == ENGINE_SCENE.EDITOR);
    
    // Single-step debounced navigation (strictly _pressed so one press = one entry move)
    _inp.nav_up = keyboard_check_pressed(vk_up) || (!_ctrl && keyboard_check_pressed(ord("W")));
    _inp.nav_down = keyboard_check_pressed(vk_down) || (!_ctrl && keyboard_check_pressed(ord("S")));
    _inp.nav_left = keyboard_check_pressed(vk_left) || (!_ctrl && keyboard_check_pressed(ord("A")));
    _inp.nav_right = keyboard_check_pressed(vk_right) || (!_ctrl && keyboard_check_pressed(ord("D")));
    
    // Classic GameMaker RPG Controls:
    // Z / Enter (plus Space / E): Interact / Confirm (in Editor, Z without Ctrl is Place/Erase toggle)
    _inp.nav_confirm = keyboard_check_pressed(vk_enter) ||
                       keyboard_check_pressed(vk_space) ||
                       (!_ctrl && keyboard_check_pressed(ord("E"))) ||
                       (!_in_editor && !_ctrl && keyboard_check_pressed(ord("Z")));
                       
    // X / Escape / Backspace: Cancel / Close Menu
    _inp.nav_cancel = (!_ctrl && keyboard_check_pressed(ord("X"))) ||
                      keyboard_check_pressed(vk_escape) ||
                      keyboard_check_pressed(vk_backspace);
                      
    // C / Escape: Open In-Game Menu
    _inp.nav_menu = (!_ctrl && keyboard_check_pressed(ord("C"))) ||
                    keyboard_check_pressed(vk_escape);
                    
    _inp.nav_delete = keyboard_check_pressed(vk_delete);
    
    // Continuous directional input for smooth camera/character movement
    var _right = (keyboard_check(vk_right) || (!_ctrl && keyboard_check(ord("D")))) ? 1 : 0;
    var _left = (keyboard_check(vk_left) || (!_ctrl && keyboard_check(ord("A")))) ? 1 : 0;
    var _down = (keyboard_check(vk_down) || (!_ctrl && keyboard_check(ord("S")))) ? 1 : 0;
    var _up = (keyboard_check(vk_up) || (!_ctrl && keyboard_check(ord("W")))) ? 1 : 0;
    _inp.axis_x = _right - _left;
    _inp.axis_y = _down - _up;
    
    // Editor shortcuts (preserved in Editor)
    _inp.shortcut_undo = _ctrl && keyboard_check_pressed(ord("Z"));
    _inp.shortcut_redo = _ctrl && keyboard_check_pressed(ord("Y"));
    _inp.shortcut_save = _ctrl && keyboard_check_pressed(ord("S"));
    _inp.shortcut_toggle_mode = _in_editor && (!_ctrl) && keyboard_check_pressed(ord("Z"));
    _inp.shortcut_project_mgr = keyboard_check_pressed(vk_f1);
    _inp.shortcut_fullscreen = false;
}

function input_mouse_in_rect(_x1, _y1, _x2, _y2) {
    var _mx = global.input.mouse_gui_x;
    var _my = global.input.mouse_gui_y;
    return (_mx >= _x1 && _mx <= _x2 && _my >= _y1 && _my <= _y2);
}

function input_click_in_rect(_x1, _y1, _x2, _y2) {
    if (global.input.mouse_consumed) return false;
    if (global.input.mb_left_pressed && input_mouse_in_rect(_x1, _y1, _x2, _y2)) {
        global.input.mouse_consumed = true;
        return true;
    }
    return false;
}

function input_right_click_in_rect(_x1, _y1, _x2, _y2) {
    if (global.input.mouse_consumed) return false;
    if (global.input.mb_right_pressed && input_mouse_in_rect(_x1, _y1, _x2, _y2)) {
        global.input.mouse_consumed = true;
        return true;
    }
    return false;
}

function input_consume_all() {
    global.input.mouse_consumed = true;
    global.input.key_consumed = true;
    global.input.mb_left_pressed = false;
    global.input.mb_right_pressed = false;
    global.input.wheel_up = false;
    global.input.wheel_down = false;
    global.input.nav_up = false;
    global.input.nav_down = false;
    global.input.nav_left = false;
    global.input.nav_right = false;
    global.input.nav_confirm = false;
    global.input.nav_cancel = false;
    global.input.nav_menu = false;
    global.input.nav_delete = false;
    global.input.shortcut_undo = false;
    global.input.shortcut_redo = false;
    global.input.shortcut_save = false;
    global.input.shortcut_toggle_mode = false;
    global.input.shortcut_project_mgr = false;
    global.input.shortcut_fullscreen = false;
    global.input.scene_transition_lock = 2;
}

function input_begin_text_edit(_id, _initial_text, _max_len) {
    global.input.text_input_active = true;
    global.input.text_input_id = _id;
    global.input.text_input_buffer = string(_initial_text);
    global.input.text_input_original = string(_initial_text);
    global.input.text_input_max_len = is_undefined(_max_len) ? 120 : _max_len;
    global.input.text_input_committed = false;
    global.input.text_input_cancelled = false;
    global.input.text_input_last_id = "";
    keyboard_string = global.input.text_input_buffer;
    global.input.mouse_consumed = true;
}

function input_end_text_edit() {
    if (global.input.text_input_active) {
        global.input.text_input_last_id = global.input.text_input_id;
        global.input.text_input_committed = true;
    }
    global.input.text_input_active = false;
    global.input.text_input_id = "";
}
