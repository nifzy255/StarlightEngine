/// @description ST★RLIGHT ENGINE - Hierarchical Dialogue Tree & Typewriter UI System
/// Supports recursive branching tabs ("starter", "yes/starter", "no/starter", "yes/no/starter", ...),
/// variable conditions, optional portraits, nameless Object boxes, and branch-triggered Event sequences.

function sys_dialogue_create_default_tree(_initial_text) {
    return [
        {
            id: "starter_0",
            branch_path: "starter",
            text: is_undefined(_initial_text) ? "Hello, traveler! The stars are bright tonight." : _initial_text,
            condition_var: "",
            condition_val: true,
            fallback_node_id: "",
            choices: [], // Each choice: { label: "YES", next_node_id: "", set_var: "", set_val: true, event_commands: [] }
            next_node_id: "END",
            event_commands: []
        }
    ];
}

/// @function sys_dialogue_normalize_tree(_tree)
/// @description Ensures all nodes in a dialogue tree have valid hierarchical branch_path tags ("starter", "yes/starter", etc.).
function sys_dialogue_normalize_tree(_tree) {
    if (!is_array(_tree) || array_length(_tree) == 0) {
        return sys_dialogue_create_default_tree("...");
    }
    
    // Check if any node is missing branch_path
    var _needs_migration = false;
    for (var i = 0; i < array_length(_tree); i++) {
        var _nd = _tree[i];
        if (!variable_struct_exists(_nd, "branch_path") || _nd.branch_path == "") {
            _needs_migration = true;
        }
        if (!variable_struct_exists(_nd, "event_commands") || !is_array(_nd.event_commands)) {
            _nd.event_commands = [];
        }
        if (!variable_struct_exists(_nd, "choices") || !is_array(_nd.choices)) {
            _nd.choices = [];
        }
        if (!variable_struct_exists(_nd, "condition_var")) _nd.condition_var = "";
        if (!variable_struct_exists(_nd, "condition_val")) _nd.condition_val = true;
        if (!variable_struct_exists(_nd, "fallback_node_id")) _nd.fallback_node_id = "";
        if (!variable_struct_exists(_nd, "next_node_id")) _nd.next_node_id = "";
    }
    
    if (!_needs_migration) return _tree;
    
    // Assign "starter" to root node and propagate hierarchical branch paths through YES/NO choices
    _tree[0].branch_path = "starter";
    for (var pass = 0; pass < array_length(_tree); pass++) {
        for (var j = 0; j < array_length(_tree); j++) {
            var _cur = _tree[j];
            var _bpath = (variable_struct_exists(_cur, "branch_path") && _cur.branch_path != "") ? _cur.branch_path : "starter";
            _cur.branch_path = _bpath;
            
            if (_cur.next_node_id != "" && _cur.next_node_id != "END") {
                var _ni = sys_dialogue_find_node_index(_tree, _cur.next_node_id);
                if (_ni >= 0 && (!variable_struct_exists(_tree[_ni], "branch_path") || _tree[_ni].branch_path == "")) {
                    _tree[_ni].branch_path = _bpath;
                }
            }
            
            if (is_array(_cur.choices) && array_length(_cur.choices) > 0) {
                for (var c = 0; c < array_length(_cur.choices); c++) {
                    var _ch = _cur.choices[c];
                    var _target_id = variable_struct_exists(_ch, "next_node_id") ? _ch.next_node_id : "";
                    if (_target_id != "" && _target_id != "END") {
                        var _ti = sys_dialogue_find_node_index(_tree, _target_id);
                        if (_ti >= 0 && (!variable_struct_exists(_tree[_ti], "branch_path") || _tree[_ti].branch_path == "")) {
                            var _prefix = (c == 0 || string_upper(_ch.label) == "YES") ? "yes/" : "no/";
                            _tree[_ti].branch_path = _prefix + _bpath;
                        }
                    }
                }
            }
        }
    }
    return _tree;
}

/// @function sys_dialogue_get_branch_list(_tree)
/// @description Returns the ordered list of unique branch tab names ("starter", "yes/starter", "no/starter", ...).
function sys_dialogue_get_branch_list(_tree) {
    sys_dialogue_normalize_tree(_tree);
    var _branches = ["starter"];
    var _seen = { starter: true };
    for (var i = 0; i < array_length(_tree); i++) {
        var _bp = _tree[i].branch_path;
        if (_bp != "" && !variable_struct_exists(_seen, _bp)) {
            variable_struct_set(_seen, _bp, true);
            array_push(_branches, _bp);
        }
    }
    return _branches;
}

/// @function sys_dialogue_get_branch_node_indices(_tree, _branch_path)
/// @description Returns an array of indices into _tree that belong to _branch_path.
function sys_dialogue_get_branch_node_indices(_tree, _branch_path) {
    var _indices = [];
    for (var i = 0; i < array_length(_tree); i++) {
        var _bp = variable_struct_exists(_tree[i], "branch_path") ? _tree[i].branch_path : "starter";
        if (_bp == _branch_path) {
            array_push(_indices, i);
        }
    }
    return _indices;
}

function sys_dialogue_init_state() {
    return {
        active: false,
        speaker_name: "", // Empty for Objects (signs, chests, books, doors)
        show_speaker_name: false,
        portrait_sprite_id: "",
        nodes: [],
        current_node_index: 0,
        displayed_text: "",
        full_text: "",
        char_index: 0,
        typewriter_speed: 0.85,
        choices: [],
        selected_choice_index: 0,
        waiting_for_choice: false
    };
}

function sys_dialogue_find_node_index(_nodes, _node_id) {
    if (_node_id == "" || !is_array(_nodes)) return -1;
    for (var i = 0; i < array_length(_nodes); i++) {
        if (variable_struct_exists(_nodes[i], "id") && _nodes[i].id == _node_id) {
            return i;
        }
    }
    return -1;
}

/// @function sys_dialogue_start_tree(_nodes, _speaker_name, _portrait_id, _is_object)
/// @description Starts a dialogue tree. If _is_object is true, speaker_name is hidden per specification.
function sys_dialogue_start_tree(_nodes, _speaker_name, _portrait_id, _is_object) {
    if (!is_array(_nodes) || array_length(_nodes) == 0) return false;
    sys_dialogue_normalize_tree(_nodes);
    var _dlg = global.runtime.dialogue;
    var _was_active = _dlg.active;
    _dlg.active = true;
    _dlg.show_speaker_name = !_is_object && (_speaker_name != "") && !is_undefined(_speaker_name);
    _dlg.speaker_name = _dlg.show_speaker_name ? string(_speaker_name) : "";
    _dlg.portrait_sprite_id = (!_is_object && !is_undefined(_portrait_id)) ? string(_portrait_id) : "";
    _dlg.nodes = _nodes;
    _dlg.selected_choice_index = 0;
    
    if (!_was_active) {
        core_audio_play_default_sound("dialogue_open");
    }
    
    // Start at the first node of the "starter" branch
    var _starter_indices = sys_dialogue_get_branch_node_indices(_nodes, "starter");
    var _first_idx = (array_length(_starter_indices) > 0) ? _starter_indices[0] : 0;
    sys_dialogue_enter_node(_first_idx);
    input_consume_all();
    return true;
}

/// @function sys_dialogue_start_simple(_text, _speaker_name, _choices_array)
/// @description Starts a single-node dialogue or choice prompt (used by Event Commands).
function sys_dialogue_start_simple(_text, _speaker_name, _choices_array) {
    var _node = {
        id: "starter_0",
        branch_path: "starter",
        text: string(_text),
        condition_var: "",
        condition_val: true,
        fallback_node_id: "",
        choices: is_array(_choices_array) ? _choices_array : [],
        next_node_id: "END",
        event_commands: []
    };
    var _is_obj = (_speaker_name == "" || is_undefined(_speaker_name));
    sys_dialogue_start_tree([_node], _speaker_name, "", _is_obj);
}

function sys_dialogue_enter_node(_idx) {
    var _dlg = global.runtime.dialogue;
    if (_idx < 0 || _idx >= array_length(_dlg.nodes)) {
        sys_dialogue_close();
        return;
    }
    
    var _node = _dlg.nodes[_idx];
    var _cur_branch = variable_struct_exists(_node, "branch_path") ? _node.branch_path : "starter";
    
    // Check variable condition on node if configured
    if (variable_struct_exists(_node, "condition_var") && _node.condition_var != "") {
        var _expected = variable_struct_exists(_node, "condition_val") ? _node.condition_val : true;
        if (!sys_variable_check(_node.condition_var, _expected)) {
            var _fb = variable_struct_exists(_node, "fallback_node_id") ? _node.fallback_node_id : "";
            var _fb_idx = sys_dialogue_find_node_index(_dlg.nodes, _fb);
            if (_fb_idx >= 0 && _fb_idx != _idx) {
                sys_dialogue_enter_node(_fb_idx);
                return;
            }
            // Otherwise advance to the next node within the same branch
            for (var k = _idx + 1; k < array_length(_dlg.nodes); k++) {
                var _kb = variable_struct_exists(_dlg.nodes[k], "branch_path") ? _dlg.nodes[k].branch_path : "starter";
                if (_kb == _cur_branch) {
                    sys_dialogue_enter_node(k);
                    return;
                }
            }
            sys_dialogue_close();
            return;
        }
    }
    
    _dlg.current_node_index = _idx;
    _dlg.full_text = variable_struct_exists(_node, "text") ? string(_node.text) : "";
    _dlg.displayed_text = "";
    _dlg.char_index = 0;
    _dlg.choices = (variable_struct_exists(_node, "choices") && is_array(_node.choices)) ? _node.choices : [];
    _dlg.selected_choice_index = 0;
    _dlg.waiting_for_choice = false;
    
    // Queue any on-enter event commands attached to this node
    if (variable_struct_exists(_node, "event_commands") && is_array(_node.event_commands) && array_length(_node.event_commands) > 0) {
        sys_event_enqueue_commands(_node.event_commands);
    }
}

function sys_dialogue_close() {
    var _dlg = global.runtime.dialogue;
    var _was_active = _dlg.active;
    _dlg.active = false;
    _dlg.nodes = [];
    _dlg.choices = [];
    if (_was_active) {
        var _frame = variable_global_exists("engine") && is_struct(global.engine) ? global.engine.frame_counter : 0;
        if (!variable_global_exists("audio") || !is_struct(global.audio) || global.audio.last_specific_ui_frame != _frame) {
            core_audio_play_default_sound("dialogue_close");
        }
    }
    input_consume_all();
}

function sys_dialogue_update() {
    var _dlg = global.runtime.dialogue;
    if (!_dlg.active) return;
    
    // Note: X (nav_cancel) and C/Esc (nav_menu) intentionally do NOT close or interrupt dialogue!
    var _total_len = string_length(_dlg.full_text);
    if (_dlg.char_index < _total_len) {
        var _prev_char_pos = floor(_dlg.char_index);
        _dlg.char_index = min(_total_len, _dlg.char_index + _dlg.typewriter_speed);
        var _new_char_pos = floor(_dlg.char_index);
        _dlg.displayed_text = string_copy(_dlg.full_text, 1, _new_char_pos);
        
        if (_new_char_pos > _prev_char_pos && _new_char_pos >= 1) {
            var _typed_ch = string_char_at(_dlg.full_text, _new_char_pos);
            if (_typed_ch != " " && _typed_ch != "\n") {
                core_audio_play_default_sound("dialogue_typing");
            }
        }
        
        // Pressing Z / Enter (nav_confirm) or left-click skips typewriter to full line
        if (global.input.nav_confirm || global.input.mb_left_pressed) {
            _dlg.char_index = _total_len;
            _dlg.displayed_text = _dlg.full_text;
            core_audio_play_default_sound("dialogue_advance");
            input_consume_all();
        }
        return;
    }
    
    var _num_choices = array_length(_dlg.choices);
    if (_num_choices > 0) {
        _dlg.waiting_for_choice = true;
        if (global.input.nav_up || global.input.nav_left) {
            _dlg.selected_choice_index = (_dlg.selected_choice_index + _num_choices - 1) mod _num_choices;
            core_audio_play_default_sound("choice_move");
        } else if (global.input.nav_down || global.input.nav_right) {
            _dlg.selected_choice_index = (_dlg.selected_choice_index + 1) mod _num_choices;
            core_audio_play_default_sound("choice_move");
        } else if (global.input.nav_confirm) {
            sys_dialogue_select_choice(_dlg.selected_choice_index);
        }
    } else {
        if (global.input.nav_confirm || global.input.mb_left_pressed) {
            var _node = _dlg.nodes[_dlg.current_node_index];
            var _cur_branch = variable_struct_exists(_node, "branch_path") ? _node.branch_path : "starter";
            var _next_id = variable_struct_exists(_node, "next_node_id") ? _node.next_node_id : "";
            
            if (_next_id == "END") {
                sys_dialogue_close();
            } else if (_next_id != "") {
                var _nidx = sys_dialogue_find_node_index(_dlg.nodes, _next_id);
                if (_nidx >= 0) {
                    core_audio_play_default_sound("dialogue_advance");
                    sys_dialogue_enter_node(_nidx);
                } else {
                    sys_dialogue_close();
                }
            } else {
                // Find the next node belonging to the SAME branch_path so branches never bleed into each other
                var _found_next_in_branch = -1;
                for (var k = _dlg.current_node_index + 1; k < array_length(_dlg.nodes); k++) {
                    var _kb = variable_struct_exists(_dlg.nodes[k], "branch_path") ? _dlg.nodes[k].branch_path : "starter";
                    if (_kb == _cur_branch) {
                        _found_next_in_branch = k;
                        break;
                    }
                }
                if (_found_next_in_branch >= 0) {
                    core_audio_play_default_sound("dialogue_advance");
                    sys_dialogue_enter_node(_found_next_in_branch);
                } else {
                    sys_dialogue_close();
                }
            }
            input_consume_all();
        }
    }
}

function sys_dialogue_select_choice(_cidx) {
    var _dlg = global.runtime.dialogue;
    if (_cidx < 0 || _cidx >= array_length(_dlg.choices)) return;
    var _choice = _dlg.choices[_cidx];
    var _cur_node = _dlg.nodes[_dlg.current_node_index];
    var _cur_branch = variable_struct_exists(_cur_node, "branch_path") ? _cur_node.branch_path : "starter";
    
    // Play dedicated Yes or No sound without overlapping generic Confirm/Cancel
    var _u_lbl = string_upper(string_trim(_choice.label));
    if (_u_lbl == "YES" || string_pos("YES", _u_lbl) == 1) {
        core_audio_play_default_sound("choice_yes");
    } else if (_u_lbl == "NO" || string_pos("NO", _u_lbl) == 1) {
        core_audio_play_default_sound("choice_no");
    } else {
        core_audio_play_default_sound("menu_confirm");
    }
    
    // Execute ONLY the event commands explicitly configured on this choice
    if (variable_struct_exists(_choice, "event_commands") && is_array(_choice.event_commands) && array_length(_choice.event_commands) > 0) {
        sys_event_enqueue_commands(_choice.event_commands);
    }
    if (variable_struct_exists(_choice, "set_var") && _choice.set_var != "") {
        var _sval = variable_struct_exists(_choice, "set_val") ? _choice.set_val : true;
        sys_variable_set(_choice.set_var, _sval);
    }
    
    // 1. Check explicit next_node_id on choice
    var _next_id = variable_struct_exists(_choice, "next_node_id") ? _choice.next_node_id : "";
    if (_next_id != "" && _next_id != "END") {
        var _nidx = sys_dialogue_find_node_index(_dlg.nodes, _next_id);
        if (_nidx >= 0) {
            sys_dialogue_enter_node(_nidx);
            input_consume_all();
            return;
        }
    }
    
    // 2. Check hierarchical child branch ("yes/" + _cur_branch or "no/" + _cur_branch)
    var _prefix = (_cidx == 0 || string_upper(_choice.label) == "YES") ? "yes/" : "no/";
    var _child_branch = _prefix + _cur_branch;
    var _child_indices = sys_dialogue_get_branch_node_indices(_dlg.nodes, _child_branch);
    if (array_length(_child_indices) > 0) {
        sys_dialogue_enter_node(_child_indices[0]);
        input_consume_all();
        return;
    }
    
    sys_dialogue_close();
}

function sys_dialogue_draw_gui() {
    var _dlg = global.runtime.dialogue;
    if (!_dlg.active) return;
    
    var _pal = global.palette;
    camera_runtime_sync_aspect_ratio();
    var _cam = global.camera.runtime;
    var _vx1 = _cam.viewport_x;
    var _vw = _cam.viewport_w;
    
    var _pad = (_vw < 1000) ? 24 : 140;
    var _bx1 = _vx1 + _pad;
    var _by1 = 480;
    var _bx2 = _vx1 + _vw - _pad;
    var _by2 = 696;
    
    // Speaker Name Tab (ONLY rendered for NPCs/Characters, never for stationary Objects)
    if (_dlg.show_speaker_name && _dlg.speaker_name != "") {
        var _nw = clamp(string_width(_dlg.speaker_name) + 40, 150, 360);
        render_window_frame(_bx1, _by1 - 40, _bx1 + _nw, _by1 + 2, "", _pal.accent_gold);
        draw_set_halign(fa_left);
        draw_set_valign(fa_middle);
        draw_set_color(_pal.accent_gold);
        draw_text(_bx1 + 16, _by1 - 20, render_fit_text(_dlg.speaker_name, _nw - 24));
    }
    
    render_window_frame(_bx1, _by1, _bx2, _by2, "", _pal.border_outer);
    
    var _text_x = _bx1 + 24;
    var _text_w = (_bx2 - _bx1) - 48;
    
    // Optional Portrait Sprite (Portrait sprites are NOT mandatory)
    if (_dlg.portrait_sprite_id != "") {
        var _px1 = _bx1 + 18;
        var _py1 = _by1 + 18;
        var _psize = 96;
        draw_set_color(make_color_rgb(10, 12, 24));
        draw_rectangle(_px1, _py1, _px1 + _psize, _py1 + _psize, false);
        core_assets_draw_entity_sprite(_dlg.portrait_sprite_id, "Idle", 0, _px1 + 8, _py1 + 8, _psize - 16, _psize - 16, DIR_FACING.DOWN, undefined);
        draw_set_color(_pal.border_inner);
        draw_rectangle(_px1, _py1, _px1 + _psize, _py1 + _psize, true);
        
        _text_x = _px1 + _psize + 20;
        _text_w = (_bx2 - _text_x) - 24;
    }
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(_pal.text_primary);
    draw_text_ext(_text_x, _by1 + 22, "* " + _dlg.displayed_text, 28, _text_w);
    
    // Render Choices if typewriter completed and choices exist
    var _num_choices = array_length(_dlg.choices);
    if (_dlg.waiting_for_choice && _num_choices > 0) {
        var _cy = _by2 - 56;
        var _cw = min(220, floor((_text_w - ((_num_choices - 1) * 14)) / _num_choices));
        for (var i = 0; i < _num_choices; i++) {
            var _cx1 = _text_x + i * (_cw + 14);
            var _cx2 = _cx1 + _cw;
            var _ch = _dlg.choices[i];
            if (input_mouse_in_rect(_cx1, _cy, _cx2, _cy + 40)) {
                if (_dlg.selected_choice_index != i) {
                    _dlg.selected_choice_index = i;
                    core_audio_play_default_sound("choice_move");
                }
            }
            if (render_ui_button(_cx1, _cy, _cx2, _cy + 40, _ch.label, (_dlg.selected_choice_index == i), true)) {
                sys_dialogue_select_choice(i);
                return;
            }
        }
    } else if (_dlg.char_index >= string_length(_dlg.full_text)) {
        // Blinking advance prompt indicator
        if ((global.engine.frame_counter div 20) mod 2 == 0) {
            draw_set_color(_pal.accent_gold);
            draw_text(_bx2 - 28, _by2 - 30, "▼");
        }
    }
}
