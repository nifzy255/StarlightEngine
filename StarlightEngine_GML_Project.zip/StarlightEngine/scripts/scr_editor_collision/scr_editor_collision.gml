/// @description ST★RLIGHT ENGINE - Collision Grid Editor
/// Manages painting/erasing blocking tiles and rendering the configurable editor overlay.

function editor_collision_get_cell(_map, _gx, _gy) {
    if (!is_struct(_map) || !variable_struct_exists(_map, "collision")) return false;
    if (_gx < 0 || _gy < 0 || _gx >= _map.width || _gy >= _map.height) return true;
    var _idx = (_gy * _map.width) + _gx;
    if (_idx < 0 || _idx >= array_length(_map.collision)) return false;
    return (_map.collision[_idx] > 0);
}

function editor_collision_set_cell(_map, _gx, _gy, _blocked_val) {
    if (!is_struct(_map) || !variable_struct_exists(_map, "collision")) return;
    if (_gx < 0 || _gy < 0 || _gx >= _map.width || _gy >= _map.height) return;
    var _idx = (_gy * _map.width) + _gx;
    if (_idx >= 0 && _idx < array_length(_map.collision)) {
        _map.collision[_idx] = (_blocked_val > 0) ? 1 : 0;
        global.project_dirty = true;
    }
}

function editor_collision_draw_overlay(_map, _vx1, _vy1, _vx2, _vy2, _cell_px) {
    var _col_arr = _map.collision;
    var _tsize = _map.tile_size;
    var _alpha = global.editor.collision_overlay_alpha;
    var _pal = global.palette;
    
    for (var gy = 0; gy < _map.height; gy++) {
        var _sy = camera_editor_world_to_screen_y(gy * _tsize);
        if (_sy + _cell_px < _vy1 || _sy > _vy2) continue;
        for (var gx = 0; gx < _map.width; gx++) {
            if (_col_arr[gy * _map.width + gx] > 0) {
                var _sx = camera_editor_world_to_screen_x(gx * _tsize);
                if (_sx + _cell_px < _vx1 || _sx > _vx2) continue;
                
                draw_set_alpha(_alpha);
                draw_set_color(_pal.accent_red);
                draw_rectangle(_sx + 1, _sy + 1, _sx + _cell_px - 1, _sy + _cell_px - 1, false);
                draw_set_alpha(min(1.0, _alpha + 0.25));
                draw_line(_sx + 2, _sy + 2, _sx + _cell_px - 2, _sy + _cell_px - 2);
                draw_line(_sx + _cell_px - 2, _sy + 2, _sx + 2, _sy + _cell_px - 2);
            }
        }
    }
    draw_set_alpha(1.0);
}
