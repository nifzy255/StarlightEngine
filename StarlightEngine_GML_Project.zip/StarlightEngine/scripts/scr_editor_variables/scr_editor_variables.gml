/// @description ST★RLIGHT ENGINE - Variable Manager
/// Allows creators to create, delete, rename, set default values, and document project variables.

function editor_variables_ensure_default() {
    if (is_undefined(global.project)) return;
    if (!is_array(global.project.variables) || array_length(global.project.variables) == 0) {
        global.project.variables = [
            sys_variable_create_definition("VAR_01", "VAR_01", VAR_TYPE.BOOLEAN, false, "Default boolean flag.")
        ];
    }
}

function editor_variables_draw_modal() {
    var _ed = global.editor;
    var _pal = global.palette;
    editor_variables_ensure_default();
    
    var _vars = global.project.variables;
    render_window_frame(140, 56, 1140, 664, "VARIABLE MANAGER — PERSISTENT PROJECT VARIABLES", _pal.accent_cyan);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(_pal.text_secondary);
    draw_text(168, 98, "Variables persist across maps, events, dialogue branches, NPCs, enemies, and save slots.");
    
    if (render_ui_button(168, 128, 396, 166, "+ Create Boolean Variable", false, true)) {
        var _n = array_length(_vars) + 1;
        var _vn = "VAR_" + (_n < 10 ? "0" : "") + string(_n);
        array_push(_vars, sys_variable_create_definition(_vn, _vn, VAR_TYPE.BOOLEAN, false, "Custom boolean condition flag."));
        global.project_dirty = true;
    }
    
    var _max_vis = min(6, array_length(_vars));
    for (var i = 0; i < _max_vis; i++) {
        var _v = _vars[i];
        var _vy1 = 182 + i * 70;
        var _vy2 = _vy1 + 62;
        
        draw_set_color(_pal.panel_alt);
        draw_rectangle(168, _vy1, 1112, _vy2, false);
        draw_set_color(_pal.border_inner);
        draw_rectangle(168, _vy1, 1112, _vy2, true);
        
        draw_set_color(_pal.accent_gold);
        draw_text(180, _vy1 + 6, "Name:");
        _v.name = render_ui_text_field("var_name_" + string(i), 238, _vy1 + 4, 460, _vy1 + 32, _v.name, 36);
        _v.id = _v.name;
        
        var _def_bool = bool(_v.default_value);
        if (render_ui_button(476, _vy1 + 4, 650, _vy1 + 32, "Default: " + (_def_bool ? "TRUE" : "FALSE"), _def_bool, true)) {
            _v.default_value = !_def_bool;
            global.project_dirty = true;
        }
        
        var _type_names = ["BOOLEAN", "INTEGER", "DECIMAL", "STRING"];
        var _tname = _type_names[clamp(_v.type, 0, 3)];
        if (render_ui_button(662, _vy1 + 4, 830, _vy1 + 32, "Type: " + _tname, false, true)) {
            _v.type = (_v.type + 1) mod 4;
            global.project_dirty = true;
        }
        
        if (render_ui_button(1020, _vy1 + 4, 1102, _vy1 + 32, "Delete", false, array_length(_vars) > 1)) {
            array_delete(_vars, i, 1);
            global.project_dirty = true;
            return;
        }
        
        draw_set_color(_pal.text_secondary);
        draw_text(180, _vy1 + 36, "Desc:");
        _v.description = render_ui_text_field("var_desc_" + string(i), 238, _vy1 + 34, 1102, _vy1 + 58, _v.description, 90);
    }
    
    if (render_ui_button(912, 608, 1112, 648, "Done (Esc)", true, true)) {
        input_end_text_edit();
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}
