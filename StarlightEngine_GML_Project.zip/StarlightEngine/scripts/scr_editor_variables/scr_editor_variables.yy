{
  "$GMScript": "v1",
  "%Name": "scr_editor_variables",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_editor_variables",
  "parent": {
    "name": "Editor",
    "path": "folders/Engine/Editor.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}