/// @description ST★RLIGHT ENGINE - NPC Editor & Hierarchical Dialogue Tree Builder
/// Configures NPC identity, custom IDs, editable numeric movement fields, and recursive branching dialogue trees ("starter", "yes/starter", "no/starter", ...).

function editor_npcs_place_at(_map, _gx, _gy) {
    if (!is_struct(_map)) return;
    if (editor_npcs_inspect_at(_map, _gx, _gy)) return;
    
    var _idx = array_length(_map.npcs) + 1;
    var _npc = {
        id: "npc_" + string(_idx) + "_" + string(_gx) + "_" + string(_gy),
        name: "Villager " + string(_idx),
        sprite_id: "spr_npc_default",
        portrait_sprite_id: "",
        sprite_scale: 1.0,
        grid_x: _gx,
        grid_y: _gy,
        facing: DIR_FACING.DOWN,
        move_mode: NPC_MOVE_MODE.STAY_STILL,
        move_speed: 1.2,
        wander_radius: 64,
        wait_frames: 60,
        path_points: [
            { grid_x: _gx, grid_y: _gy },
            { grid_x: min(_map.width - 1, _gx + 3), grid_y: _gy }
        ],
        condition_var: "",
        condition_val: true,
        dialogue_tree: sys_dialogue_create_default_tree("Hello! Welcome to our town.")
    };
    array_push(_map.npcs, _npc);
    global.project_dirty = true;
    core_log_toast("Placed " + _npc.name + " (Right-click to edit)");
}

function editor_npcs_remove_at(_map, _gx, _gy) {
    if (!is_struct(_map) || !is_array(_map.npcs)) return;
    for (var i = array_length(_map.npcs) - 1; i >= 0; i--) {
        if (_map.npcs[i].grid_x == _gx && _map.npcs[i].grid_y == _gy) {
            var _nname = _map.npcs[i].name;
            array_delete(_map.npcs, i, 1);
            global.project_dirty = true;
            core_log_toast("Removed " + _nname);
            return;
        }
    }
}

function editor_npcs_inspect_at(_map, _gx, _gy) {
    if (!is_struct(_map) || !is_array(_map.npcs)) return false;
    for (var i = 0; i < array_length(_map.npcs); i++) {
        var _n = _map.npcs[i];
        if (_n.grid_x == _gx && _n.grid_y == _gy) {
            global.editor.inspect_npc = _n;
            global.editor.dlg_active_branch = "starter";
            global.editor.dlg_tab_scroll = 0;
            global.editor.dlg_node_scroll = 0;
            global.editor.active_modal = EDITOR_MODAL.NPC_INSPECTOR;
            input_consume_all();
            return true;
        }
    }
    return false;
}

/// @function editor_dialogue_create_yes_no_branch(_tree, _branch_path)
/// @description Creates recursive child branches ("yes/" + _branch_path and "no/" + _branch_path) with NO hardcoded gold or items.
function editor_dialogue_create_yes_no_branch(_tree, _branch_path) {
    sys_dialogue_normalize_tree(_tree);
    var _b_indices = sys_dialogue_get_branch_node_indices(_tree, _branch_path);
    if (array_length(_b_indices) == 0) return;
    
    var _last_node = _tree[_b_indices[array_length(_b_indices) - 1]];
    var _yes_branch = "yes/" + _branch_path;
    var _no_branch = "no/" + _branch_path;
    
    // Ensure "yes/<branch>" exists
    var _yes_indices = sys_dialogue_get_branch_node_indices(_tree, _yes_branch);
    var _yes_first_id = "";
    if (array_length(_yes_indices) == 0) {
        _yes_first_id = _yes_branch + "_0";
        array_push(_tree, {
            id: _yes_first_id,
            branch_path: _yes_branch,
            text: "Branch [" + _yes_branch + "] dialogue line.",
            condition_var: "",
            condition_val: true,
            fallback_node_id: "",
            choices: [],
            next_node_id: "END",
            event_commands: []
        });
    } else {
        _yes_first_id = _tree[_yes_indices[0]].id;
    }
    
    // Ensure "no/<branch>" exists
    var _no_indices = sys_dialogue_get_branch_node_indices(_tree, _no_branch);
    var _no_first_id = "";
    if (array_length(_no_indices) == 0) {
        _no_first_id = _no_branch + "_0";
        array_push(_tree, {
            id: _no_first_id,
            branch_path: _no_branch,
            text: "Branch [" + _no_branch + "] dialogue line.",
            condition_var: "",
            condition_val: true,
            fallback_node_id: "",
            choices: [],
            next_node_id: "END",
            event_commands: []
        });
    } else {
        _no_first_id = _tree[_no_indices[0]].id;
    }
    
    // Configure clean YES/NO choices on the branch's terminal node (no automatic 25 gold!)
    _last_node.choices = [
        {
            label: "YES",
            next_node_id: _yes_first_id,
            set_var: "",
            set_val: true,
            event_commands: []
        },
        {
            label: "NO",
            next_node_id: _no_first_id,
            set_var: "",
            set_val: false,
            event_commands: []
        }
    ];
    
    global.project_dirty = true;
    core_log_toast("Created branches: '" + _yes_branch + "' and '" + _no_branch + "'");
}

/// @function editor_draw_hierarchical_dialogue_panel(_tree, _x1, _y1, _x2, _y2, _prefix)
/// @description Renders the scrollable, recursive tab-based Dialogue Tree Editor ("starter", "yes/starter", "no/starter", ...).
function editor_draw_hierarchical_dialogue_panel(_tree, _x1, _y1, _x2, _y2, _prefix) {
    var _ed = global.editor;
    var _pal = global.palette;
    sys_dialogue_normalize_tree(_tree);
    
    var _branches = sys_dialogue_get_branch_list(_tree);
    var _bcount = array_length(_branches);
    
    // Validate active branch selection
    var _found_active = false;
    for (var b = 0; b < _bcount; b++) {
        if (_branches[b] == _ed.dlg_active_branch) {
            _found_active = true;
            break;
        }
    }
    if (!_found_active) {
        _ed.dlg_active_branch = "starter";
        _ed.dlg_node_scroll = 0;
    }
    
    // 1. Top Horizontal Branch Tab Bar ("starter", "yes/starter", "no/starter", "yes/no/starter", ...)
    draw_set_color(_pal.accent_gold);
    draw_text(_x1, _y1, "DIALOGUE BRANCH TABS (" + string(_bcount) + " branches —Active: [" + _ed.dlg_active_branch + "]):");
    
    var _tab_y1 = _y1 + 24;
    var _tab_y2 = _tab_y1 + 34;
    var _vis_tabs = 3;
    _ed.dlg_tab_scroll = clamp(_ed.dlg_tab_scroll, 0, max(0, _bcount - _vis_tabs));
    
    if (render_ui_button(_x1, _tab_y1, _x1 + 34, _tab_y2, "<", false, _ed.dlg_tab_scroll > 0)) {
        _ed.dlg_tab_scroll--;
    }
    if (render_ui_button(_x2 - 34, _tab_y1, _x2, _tab_y2, ">", false, _ed.dlg_tab_scroll + _vis_tabs < _bcount)) {
        _ed.dlg_tab_scroll++;
    }
    
    var _tab_area_x1 = _x1 + 40;
    var _tab_area_w = (_x2 - _x1) - 80;
    var _tab_w = floor((_tab_area_w - ((_vis_tabs - 1) * 6)) / _vis_tabs);
    
    for (var t = 0; t < min(_vis_tabs, _bcount - _ed.dlg_tab_scroll); t++) {
        var _bidx = _ed.dlg_tab_scroll + t;
        var _bname = _branches[_bidx];
        var _tx1 = _tab_area_x1 + t * (_tab_w + 6);
        var _tx2 = _tx1 + _tab_w;
        if (render_ui_button(_tx1, _tab_y1, _tx2, _tab_y2, _bname, (_ed.dlg_active_branch == _bname), true)) {
            input_end_text_edit();
            _ed.dlg_active_branch = _bname;
            _ed.dlg_node_scroll = 0;
            return;
        }
    }
    render_horizontal_scrollbar(_tab_area_x1, _tab_area_x1 + _tab_area_w, _tab_y2 + 3, _bcount, _vis_tabs, _ed.dlg_tab_scroll);
    
    // 2. Scrollable Node List for Active Branch
    var _node_indices = sys_dialogue_get_branch_node_indices(_tree, _ed.dlg_active_branch);
    var _ncount = array_length(_node_indices);
    var _vis_nodes = 2;
    
    // Mouse-wheel vertical scrolling inside the dialogue panel
    if (input_mouse_in_rect(_x1, _tab_y2 + 12, _x2, _y2 - 52)) {
        if (global.input.wheel_up) _ed.dlg_node_scroll = max(0, _ed.dlg_node_scroll - 1);
        else if (global.input.wheel_down) _ed.dlg_node_scroll = min(max(0, _ncount - _vis_nodes), _ed.dlg_node_scroll + 1);
    }
    _ed.dlg_node_scroll = clamp(_ed.dlg_node_scroll, 0, max(0, _ncount - _vis_nodes));
    
    var _list_y1 = _tab_y2 + 14;
    var _card_h = 188;
    
    for (var slot = 0; slot < min(_vis_nodes, _ncount - _ed.dlg_node_scroll); slot++) {
        var _seq_idx = _ed.dlg_node_scroll + slot;
        var _tree_idx = _node_indices[_seq_idx];
        var _node = _tree[_tree_idx];
        var _cy1 = _list_y1 + slot * (_card_h + 8);
        var _cy2 = _cy1 + _card_h;
        var _cx2 = _x2 - 16;
        
        draw_set_color(_pal.panel_alt);
        draw_rectangle(_x1, _cy1, _cx2, _cy2, false);
        draw_set_color(_pal.border_inner);
        draw_rectangle(_x1, _cy1, _cx2, _cy2, true);
        
        // Row 1: Sequence Header, Condition Variable, & Delete Line Button
        draw_set_color(_pal.accent_cyan);
        draw_text(_x1 + 10, _cy1 + 8, "Line #" + string(_seq_idx + 1) + " [" + _node.id + "]  Cond Var:");
        _node.condition_var = render_ui_text_field(_prefix + "_cvar_" + string(_tree_idx), _x1 + 250, _cy1 + 4, _cx2 - 156, _cy1 + 34, _node.condition_var, 36);
        
        if (render_ui_button(_cx2 - 148, _cy1 + 4, _cx2 - 68, _cy1 + 34, _node.condition_val ? "=TRUE" : "=FALSE", _node.condition_val, true)) {
            _node.condition_val = !_node.condition_val;
            global.project_dirty = true;
        }
        if (render_ui_button(_cx2 - 62, _cy1 + 4, _cx2 - 6, _cy1 + 34, "Del", false, _ncount > 1)) {
            array_delete(_tree, _tree_idx, 1);
            global.project_dirty = true;
            return;
        }
        
        // Row 2: Dialogue Line Text
        draw_set_color(_pal.text_primary);
        _node.text = render_ui_text_field(_prefix + "_txt_" + string(_tree_idx), _x1 + 10, _cy1 + 40, _cx2 - 8, _cy1 + 74, _node.text, 160);
        
        // Row 3: Branch Event Trigger on this node (Cmd / Param 1 / Param 2)
        if (!variable_struct_exists(_node, "event_commands") || !is_array(_node.event_commands)) {
            _node.event_commands = [];
        }
        if (array_length(_node.event_commands) == 0) {
            draw_set_color(_pal.text_secondary);
            draw_text(_x1 + 10, _cy1 + 84, "Node Event: None");
            if (render_ui_button(_x1 + 180, _cy1 + 80, _x1 + 390, _cy1 + 112, "+ Add Event Command", false, true)) {
                array_push(_node.event_commands, sys_event_create_command("set_variable", "VAR_01", "TRUE"));
                global.project_dirty = true;
            }
        } else {
            var _evc = _node.event_commands[0];
            draw_set_color(_pal.accent_gold);
            draw_text(_x1 + 10, _cy1 + 84, "Cmd:");
            _evc.cmd = render_ui_text_field(_prefix + "_ecmd_" + string(_tree_idx), _x1 + 58, _cy1 + 80, _x1 + 228, _cy1 + 112, _evc.cmd, 36);
            draw_text(_x1 + 234, _cy1 + 84, "P1:");
            _evc.p1 = render_ui_text_field(_prefix + "_ep1_" + string(_tree_idx), _x1 + 266, _cy1 + 80, _x1 + 430, _cy1 + 112, _evc.p1, 60);
            draw_text(_x1 + 436, _cy1 + 84, "P2:");
            _evc.p2 = render_ui_text_field(_prefix + "_ep2_" + string(_tree_idx), _x1 + 468, _cy1 + 80, _cx2 - 58, _cy1 + 112, _evc.p2, 60);
            if (render_ui_button(_cx2 - 52, _cy1 + 80, _cx2 - 6, _cy1 + 112, "X", false, true)) {
                array_delete(_node.event_commands, 0, 1);
                global.project_dirty = true;
                return;
            }
        }
        
        // Row 4: YES/NO Branching Controls (creates "yes/<active>" and "no/<active>")
        var _has_choices = (is_array(_node.choices) && array_length(_node.choices) >= 2);
        if (_has_choices) {
            var _yes_b = "yes/" + _ed.dlg_active_branch;
            var _no_b = "no/" + _ed.dlg_active_branch;
            draw_set_color(_pal.accent_green);
            draw_text(_x1 + 10, _cy1 + 124, "YES -> [" + _yes_b + "]   |   NO -> [" + _no_b + "]");
            if (render_ui_button(_x1 + 10, _cy1 + 150, _x1 + 210, _cy1 + 182, "Edit YES Branch", false, true)) {
                input_end_text_edit();
                _ed.dlg_active_branch = _yes_b;
                _ed.dlg_node_scroll = 0;
                return;
            }
            if (render_ui_button(_x1 + 218, _cy1 + 150, _x1 + 418, _cy1 + 182, "Edit NO Branch", false, true)) {
                input_end_text_edit();
                _ed.dlg_active_branch = _no_b;
                _ed.dlg_node_scroll = 0;
                return;
            }
            if (render_ui_button(_x1 + 426, _cy1 + 150, _cx2 - 6, _cy1 + 182, "Remove YES/NO Split", false, true)) {
                _node.choices = [];
                global.project_dirty = true;
                return;
            }
        } else if (_seq_idx == _ncount - 1) {
            if (render_ui_button(_x1 + 10, _cy1 + 144, _x1 + 330, _cy1 + 180, "+ Create YES/NO Branch Here", false, true)) {
                editor_dialogue_create_yes_no_branch(_tree, _ed.dlg_active_branch);
                return;
            }
        }
    }
    
    render_scrollbar(_x2 - 10, _list_y1, _list_y1 + (_vis_nodes * (_card_h + 8)) - 8, _ncount, _vis_nodes, _ed.dlg_node_scroll);
    
    // 3. Bottom Branch Sequence Action Bar
    var _bot_y = _y2 - 44;
    if (render_ui_button(_x1, _bot_y, _x1 + 230, _bot_y + 38, "+ Add Line To Branch", false, true)) {
        var _new_node_id = _ed.dlg_active_branch + "_" + string(_ncount);
        // Clear "END" on previous last node in this branch so it flows to the newly added line
        if (_ncount > 0) {
            var _prev_last = _tree[_node_indices[_ncount - 1]];
            if (_prev_last.next_node_id == "END") _prev_last.next_node_id = _new_node_id;
        }
        array_push(_tree, {
            id: _new_node_id,
            branch_path: _ed.dlg_active_branch,
            text: "Continuation line in [" + _ed.dlg_active_branch + "].",
            condition_var: "",
            condition_val: true,
            fallback_node_id: "",
            choices: [],
            next_node_id: "END",
            event_commands: []
        });
        _ed.dlg_node_scroll = max(0, (_ncount + 1) - _vis_nodes);
        global.project_dirty = true;
    }
    if (render_ui_button(_x1 + 240, _bot_y, _x1 + 310, _bot_y + 38, "▲ Up", false, _ed.dlg_node_scroll > 0)) {
        _ed.dlg_node_scroll--;
    }
    if (render_ui_button(_x1 + 318, _bot_y, _x1 + 400, _bot_y + 38, "▼ Down", false, _ed.dlg_node_scroll + _vis_nodes < _ncount)) {
        _ed.dlg_node_scroll++;
    }
}

function editor_npcs_draw_inspector_modal(_map) {
    var _ed = global.editor;
    var _pal = global.palette;
    var _npc = _ed.inspect_npc;
    if (!is_struct(_npc)) {
        _ed.active_modal = EDITOR_MODAL.NONE;
        return;
    }
    
    render_window_frame(96, 36, 1184, 684, "NPC EDITOR & HIERARCHICAL DIALOGUE BUILDER — " + _npc.name, _pal.accent_gold);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    // Left Column: Identity, Live Sprite Preview, Custom PNG / Animation Manager, & Movement
    draw_set_color(_pal.accent_gold);
    draw_text(120, 82, "NPC ID:");
    _npc.id = render_ui_text_field("npc_id", 204, 78, 456, 110, _npc.id, 36);
    
    draw_text(120, 118, "NPC Name:");
    _npc.name = render_ui_text_field("npc_name", 120, 142, 456, 174, _npc.name, 40);
    
    if (!variable_struct_exists(_npc, "sprite_scale")) _npc.sprite_scale = 1.0;
    _npc.sprite_scale = sys_sprite_clamp_scale(_npc.sprite_scale);
    
    // Live NPC Scaled Sprite Preview Box (60x60)
    var _n_prev_fps = core_assets_get_anim_fps(_npc.sprite_id, "Walking", _npc.facing);
    var _n_prev_frame = global.engine.frame_counter * (_n_prev_fps / 60.0);
    core_assets_draw_scaled_preview_box(120, 180, 180, 240, _npc.sprite_id, "Walking", _n_prev_frame, _npc.facing, make_color_rgb(245, 168, 92), _npc.sprite_scale, _pal.accent_gold);
    
    draw_set_color(_pal.accent_gold);
    draw_text(188, 178, "Spr ID:");
    _npc.sprite_id = render_ui_text_field("npc_spr", 252, 174, 354, 206, _npc.sprite_id, 36);
    draw_text(360, 178, "Port:");
    _npc.portrait_sprite_id = render_ui_text_field("npc_port", 404, 174, 456, 206, _npc.portrait_sprite_id, 36);
    
    draw_set_color(_pal.accent_cyan);
    draw_text(188, 214, "Scale:");
    var _new_nsc = render_ui_number_field("npc_scale", 252, 210, 344, 242, _npc.sprite_scale, 0.1, 8.0, true);
    if (_new_nsc != _npc.sprite_scale) {
        _npc.sprite_scale = sys_sprite_clamp_scale(_new_nsc);
        global.project_dirty = true;
    }
    if (render_ui_button(352, 210, 456, 242, "1.0x Reset", (_npc.sprite_scale == 1.0), true)) {
        _npc.sprite_scale = 1.0;
        global.project_dirty = true;
    }
    
    if (render_ui_button(120, 248, 344, 282, "+ Import Custom NPC PNG...", false, true)) {
        input_end_text_edit();
        if (_npc.sprite_id == "" || _npc.sprite_id == "spr_npc_default") {
            _npc.sprite_id = "spr_custom_" + _npc.id;
        }
        editor_sprites_import_entity_png(_npc.sprite_id, _npc.name + " Sprite", "character", 1);
        return;
    }
    if (render_ui_button(352, 248, 456, 282, "Reset Def", false, true)) {
        input_end_text_edit();
        editor_sprites_clear_entity_custom_png(_npc.sprite_id);
        _npc.sprite_id = "spr_npc_default";
        global.project_dirty = true;
        core_log_toast("Reset NPC sprite to default.");
        return;
    }
    
    if (render_ui_button(120, 288, 456, 322, "Open Sprite & Animation Manager (4-Dir)...", false, true)) {
        input_end_text_edit();
        if (_npc.sprite_id == "" || _npc.sprite_id == "spr_npc_default") {
            _npc.sprite_id = "spr_custom_" + _npc.id;
        }
        editor_sprites_open_for_id(_npc.sprite_id);
        return;
    }
    
    draw_set_color(_pal.accent_cyan);
    draw_text(120, 332, "MOVEMENT CONFIGURATION:");
    var _mm_names = [
        "1. Stay Still",
        "2. Wander Within Radius",
        "3. Scripted Movement Path",
        "4. Repeatable Scripted Path"
    ];
    if (render_ui_button(120, 356, 456, 390, _mm_names[clamp(_npc.move_mode, 0, 3)], false, true)) {
        _npc.move_mode = (_npc.move_mode + 1) mod 4;
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.text_secondary);
    draw_text(120, 402, "Speed:");
    _npc.move_speed = render_ui_number_field("npc_spd", 190, 398, 282, 430, _npc.move_speed, 0.2, 8.0, true);
    draw_text(294, 402, "Radius:");
    _npc.wander_radius = render_ui_number_field("npc_rad", 368, 398, 456, 430, _npc.wander_radius, 8, 512, false);
    
    draw_text(120, 442, "Wait(f):");
    _npc.wait_frames = render_ui_number_field("npc_wait", 196, 438, 282, 470, _npc.wait_frames, 5, 600, false);
    
    var _dir_names = ["DOWN", "LEFT", "RIGHT", "UP"];
    if (render_ui_button(294, 438, 456, 470, "Face: " + _dir_names[clamp(_npc.facing, 0, 3)], false, true)) {
        _npc.facing = (_npc.facing + 1) mod 4;
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.accent_cyan);
    draw_text(120, 482, "APPEARANCE VARIABLE CONDITION:");
    draw_set_color(_pal.text_secondary);
    draw_text(120, 506, "Visible when Variable:");
    _npc.condition_var = render_ui_text_field("npc_cond_var", 120, 530, 336, 564, _npc.condition_var, 36);
    if (render_ui_button(344, 530, 456, 564, _npc.condition_val ? "= TRUE" : "= FALSE", _npc.condition_val, true)) {
        _npc.condition_val = !_npc.condition_val;
        global.project_dirty = true;
    }
    
    // Right Column: Scrollable Hierarchical Dialogue Tree Editor
    editor_draw_hierarchical_dialogue_panel(_npc.dialogue_tree, 480, 82, 1160, 616, "npc_dlg");
    
    if (render_ui_button(956, 628, 1160, 668, "Done (Esc)", true, true)) {
        input_end_text_edit();
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}
