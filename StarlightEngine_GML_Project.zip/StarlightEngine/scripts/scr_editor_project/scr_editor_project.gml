/// @description ST★RLIGHT ENGINE - Project Manager (F1) & Default UI / Gameplay Sounds Configuration
/// Central management modal for Project Info, Default UI & Gameplay Sounds (23 categories), PP/MP Toggle, Aspect Ratio, Playtest, Save, Export, and Exit.

function editor_project_start_playtest() {
    if (is_undefined(global.project)) return;
    input_end_text_edit();
    // Snapshot the current unsaved editor state in memory without overwriting the disk save
    global.playtest_snapshot = json_stringify(global.project);
    global.editor.active_modal = EDITOR_MODAL.NONE;
    runtime_start_project(true);
    scene_switch_to(ENGINE_SCENE.RUNTIME_PLAY);
    core_log_toast("Playtest started (Press F1 or C/Esc -> Return to Editor)");
}

function editor_project_draw_default_sounds_tab(_proj) {
    var _ed = global.editor;
    var _pal = global.palette;
    core_audio_normalize_project_sounds(_proj);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    // Top Header Note & Global SFX Volume Control
    draw_set_color(_pal.accent_cyan);
    draw_text(172, 128, "DEFAULT UI & GAMEPLAY SOUNDS (Automatic Project-Wide Sound Triggers):");
    
    var _sfx_pct = round(global.config.sfx_volume * 100);
    if (render_ui_button(836, 122, 1108, 156, "Global SFX Vol: " + string(_sfx_pct) + "%", false, true)) {
        global.config.sfx_volume = (global.config.sfx_volume >= 1.0) ? 0.0 : clamp(global.config.sfx_volume + 0.2, 0.0, 1.0);
        core_config_save();
    }
    
    // 5 Category Group Filter Tabs
    var _groups = ["Dialogue", "Menu Navigation", "Choices", "Gameplay", "Battle"];
    var _group_labels = ["Dialogue (4)", "Menu Nav (3)", "Choices (3)", "Gameplay (5)", "Battle (8)"];
    _ed.pm_sound_group_idx = clamp(_ed.pm_sound_group_idx, 0, 4);
    
    for (var g = 0; g < 5; g++) {
        var _gx1 = 172 + g * 188;
        var _gx2 = _gx1 + 180;
        if (render_ui_button(_gx1, 162, _gx2, 198, _group_labels[g], (_ed.pm_sound_group_idx == g), true)) {
            input_end_text_edit();
            _ed.pm_sound_group_idx = g;
            _ed.pm_sound_scroll = 0;
            return;
        }
    }
    
    // Filter the 23 catalog entries by selected group
    var _active_group = _groups[_ed.pm_sound_group_idx];
    var _cat = core_audio_get_default_sound_catalog();
    var _filtered = [];
    for (var c = 0; c < array_length(_cat); c++) {
        if (_cat[c].group == _active_group) {
            array_push(_filtered, _cat[c]);
        }
    }
    
    var _total_in_grp = array_length(_filtered);
    var _max_vis = 5;
    if (input_mouse_in_rect(172, 206, 1108, 594)) {
        if (global.input.wheel_up) _ed.pm_sound_scroll = max(0, _ed.pm_sound_scroll - 1);
        else if (global.input.wheel_down) _ed.pm_sound_scroll = min(max(0, _total_in_grp - _max_vis), _ed.pm_sound_scroll + 1);
    }
    _ed.pm_sound_scroll = clamp(_ed.pm_sound_scroll, 0, max(0, _total_in_grp - _max_vis));
    
    for (var slot = 0; slot < min(_max_vis, _total_in_grp - _ed.pm_sound_scroll); slot++) {
        var _idx = _ed.pm_sound_scroll + slot;
        var _item = _filtered[_idx];
        var _cfg = variable_struct_get(_proj.default_sounds, _item.key);
        var _ry1 = 208 + slot * 74;
        var _ry2 = _ry1 + 66;
        
        draw_set_color(_pal.panel_alt);
        draw_rectangle(172, _ry1, 1088, _ry2, false);
        draw_set_color(_cfg.enabled ? _pal.border_inner : _pal.text_muted);
        draw_rectangle(172, _ry1, 1088, _ry2, true);
        
        // Row Title & Assigned Sound Asset Name
        draw_set_color(_cfg.enabled ? _pal.accent_gold : _pal.text_muted);
        draw_text(184, _ry1 + 8, _item.label);
        
        var _has_custom = (_cfg.file_path != "");
        draw_set_color(_has_custom ? _pal.accent_cyan : _pal.text_secondary);
        var _src_lbl = _has_custom ? ("Custom OGG: " + _cfg.name) : "Fallback: Built-In 16-Bit Tone";
        draw_text(184, _ry1 + 36, render_fit_text(_src_lbl, 290));
        
        // 1. Enable / Disable Toggle Button
        if (render_ui_button(484, _ry1 + 14, 578, _ry1 + 52, _cfg.enabled ? "ON" : "OFF", _cfg.enabled, true)) {
            _cfg.enabled = !_cfg.enabled;
            global.project_dirty = true;
        }
        
        // 2. Individual Volume Numerical Field (0..100%)
        draw_set_color(_pal.text_secondary);
        draw_text(588, _ry1 + 22, "Vol%:");
        var _vol_pct = round(_cfg.volume * 100);
        var _new_vol_pct = render_ui_number_field("pm_snd_vol_" + _item.key, 642, _ry1 + 14, 718, _ry1 + 52, _vol_pct, 0, 100, false);
        if (_new_vol_pct != _vol_pct) {
            _cfg.volume = clamp(_new_vol_pct / 100.0, 0.0, 1.0);
            global.project_dirty = true;
        }
        
        // 3. Preview Sound Button
        if (render_ui_button(726, _ry1 + 14, 822, _ry1 + 52, "▶ Preview", false, true)) {
            input_end_text_edit();
            core_audio_preview_default_sound(_item.key);
        }
        
        // 4. Import / Replace Custom OGG Sound Button
        var _imp_lbl = _has_custom ? "Replace OGG" : "+ Import OGG";
        if (render_ui_button(830, _ry1 + 14, 984, _ry1 + 52, _imp_lbl, false, true)) {
            input_end_text_edit();
            editor_audio_import_default_category_ogg(_item.key);
            return;
        }
        
        // 5. Remove Custom Sound Button (Restores Built-In Fallback)
        if (render_ui_button(992, _ry1 + 14, 1078, _ry1 + 52, "Remove", false, _has_custom)) {
            input_end_text_edit();
            editor_audio_remove_default_category_ogg(_item.key);
            return;
        }
    }
    
    render_scrollbar(1096, 208, 570, _total_in_grp, _max_vis, _ed.pm_sound_scroll);
    
    // Scroll buttons for groups with >5 items (e.g. Battle) + Back to General Settings
    if (_total_in_grp > _max_vis) {
        if (render_ui_button(172, 586, 292, 622, "▲ Scroll Up", false, _ed.pm_sound_scroll > 0)) {
            _ed.pm_sound_scroll--;
        }
        if (render_ui_button(300, 586, 430, 622, "▼ Scroll Down", false, (_ed.pm_sound_scroll + _max_vis) < _total_in_grp)) {
            _ed.pm_sound_scroll++;
        }
    }
    
    draw_set_color(_pal.text_secondary);
    draw_text(172, 632, "Tip: Unassigned cues use built-in 16-bit sounds. Yes/No choices never double-play Confirm/Cancel.");
    
    if (render_ui_button(860, 616, 1108, 658, "Return to Editor (F1)", true, true)) {
        input_end_text_edit();
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}

function editor_project_draw_modal() {
    var _ed = global.editor;
    var _pal = global.palette;
    var _proj = global.project;
    if (!is_struct(_proj)) return;
    
    if (!variable_struct_exists(_proj, "enable_pp_system")) _proj.enable_pp_system = true;
    if (!variable_struct_exists(_proj, "aspect_ratio")) _proj.aspect_ratio = "16:9";
    core_audio_normalize_project_sounds(_proj);
    
    // Unsaved-changes confirmation dialog before leaving without saving
    if (_ed.active_modal == EDITOR_MODAL.UNSAVED_CONFIRM) {
        render_window_frame(280, 190, 1000, 530, "UNSAVED CHANGES WARNING", _pal.accent_red);
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        draw_set_color(_pal.text_primary);
        draw_text(312, 256, "You have unsaved changes in project \"" + _proj.name + "\".");
        draw_set_color(_pal.text_secondary);
        draw_text(312, 294, "Would you like to save your changes before returning to the Main Menu?");
        
        if (render_ui_button(312, 420, 520, 470, "Save & Exit", true, true)) {
            core_saveload_save_project();
            _ed.active_modal = EDITOR_MODAL.NONE;
            scene_switch_to(ENGINE_SCENE.MAIN_MENU);
            return;
        }
        if (render_ui_button(536, 420, 756, 470, "Discard & Exit", false, true)) {
            global.project_dirty = false;
            _ed.active_modal = EDITOR_MODAL.NONE;
            scene_switch_to(ENGINE_SCENE.MAIN_MENU);
            return;
        }
        if (render_ui_button(772, 420, 968, 470, "Cancel", false, true)) {
            _ed.active_modal = EDITOR_MODAL.PROJECT_MANAGER;
            return;
        }
        return;
    }
    
    render_window_frame(140, 36, 1140, 684, "PROJECT MANAGER (F1) — CENTRAL PROJECT & SOUND CONFIGURATION", _pal.accent_gold);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    // Top Tab Switcher: General Project Config vs. Default UI & Gameplay Sounds
    if (!variable_struct_exists(_ed, "pm_tab_idx")) _ed.pm_tab_idx = 0;
    if (render_ui_button(172, 76, 628, 112, "1. General Project Settings & Actions", (_ed.pm_tab_idx == 0), true)) {
        input_end_text_edit();
        _ed.pm_tab_idx = 0;
        return;
    }
    if (render_ui_button(644, 76, 1108, 112, "2. Default UI & Gameplay Sounds (23 Cues)", (_ed.pm_tab_idx == 1), true)) {
        input_end_text_edit();
        _ed.pm_tab_idx = 1;
        return;
    }
    
    if (_ed.pm_tab_idx == 1) {
        editor_project_draw_default_sounds_tab(_proj);
        return;
    }
    
    // Project Information Fields
    draw_set_color(_pal.accent_gold);
    draw_text(172, 120, "Project Name:");
    var _new_name = render_ui_text_field("pm_name", 172, 142, 620, 174, _proj.name, 48);
    if (_new_name != _proj.name) { _proj.name = _new_name; global.project_dirty = true; }
    
    draw_text(644, 120, "Author:");
    var _new_auth = render_ui_text_field("pm_author", 644, 142, 1108, 174, _proj.author, 40);
    if (_new_auth != _proj.author) { _proj.author = _new_auth; global.project_dirty = true; }
    
    draw_text(172, 182, "Description:");
    var _new_desc = render_ui_text_field("pm_desc", 172, 204, 1108, 236, _proj.description, 120);
    if (_new_desc != _proj.description) { _proj.description = _new_desc; global.project_dirty = true; }
    
    // Starting Map, Starting Character, & Editable Numeric Coordinates
    draw_set_color(_pal.accent_cyan);
    draw_text(172, 248, "STARTING MAP, CHARACTER & COORDINATES:");
    if (render_ui_button(172, 272, 620, 306, "Starting Map: " + _proj.starting_map_id, false, true)) {
        var _m_idx = 0;
        for (var i = 0; i < array_length(_proj.maps); i++) {
            if (_proj.maps[i].id == _proj.starting_map_id) _m_idx = i;
        }
        _m_idx = (_m_idx + 1) mod array_length(_proj.maps);
        _proj.starting_map_id = _proj.maps[_m_idx].id;
        global.project_dirty = true;
    }
    if (render_ui_button(644, 272, 1108, 306, "Starting Character: " + _proj.starting_char_id, false, true)) {
        var _c_idx = 0;
        for (var c = 0; c < array_length(_proj.characters); c++) {
            if (_proj.characters[c].id == _proj.starting_char_id) _c_idx = c;
        }
        _c_idx = (_c_idx + 1) mod array_length(_proj.characters);
        _proj.starting_char_id = _proj.characters[_c_idx].id;
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.text_secondary);
    draw_text(172, 320, "Start X:");
    _proj.starting_x = render_ui_number_field("pm_sx", 264, 314, 384, 348, _proj.starting_x, 0, 127, false);
    draw_text(404, 320, "Start Y:");
    _proj.starting_y = render_ui_number_field("pm_sy", 496, 314, 616, 348, _proj.starting_y, 0, 127, false);
    draw_text(636, 320, "Start Gold ($):");
    _proj.starting_gold = render_ui_number_field("pm_sgold", 804, 314, 960, 348, _proj.starting_gold, 0, 999999, false);
    
    // System & Display Options (Optional PP/MP System + Aspect Ratio 16:9 / 8:7)
    draw_set_color(_pal.accent_cyan);
    draw_text(172, 360, "SYSTEM & DISPLAY OPTIONS (PP/MP RESOURCE SYSTEM & ASPECT RATIO):");
    
    var _pp_lbl = "PP/MP Resource System: " + (_proj.enable_pp_system ? "ENABLED" : "DISABLED (No PP Costs)");
    if (render_ui_button(172, 384, 628, 422, _pp_lbl, _proj.enable_pp_system, true)) {
        _proj.enable_pp_system = !_proj.enable_pp_system;
        global.project_dirty = true;
        core_log_toast("PP/MP System: " + (_proj.enable_pp_system ? "ENABLED" : "DISABLED"));
    }
    
    var _ar_lbl = "Runtime Aspect Ratio: " + (_proj.aspect_ratio == "8:7" ? "8:7 Classic EarthBound" : "16:9 Standard Widescreen");
    if (render_ui_button(644, 384, 1108, 422, _ar_lbl, (_proj.aspect_ratio == "8:7"), true)) {
        _proj.aspect_ratio = (_proj.aspect_ratio == "8:7") ? "16:9" : "8:7";
        camera_runtime_sync_aspect_ratio();
        global.project_dirty = true;
        core_log_toast("Project Aspect Ratio set to " + _proj.aspect_ratio);
    }
    
    // Combat Formula Multipliers (Editable Numeric Fields)
    draw_set_color(_pal.accent_cyan);
    draw_text(172, 434, "COMBAT FORMULA CONFIGURATION (Editable Multipliers):");
    var _cc = _proj.combat_config;
    draw_set_color(_pal.text_secondary);
    draw_text(172, 464, "ATK Mult:");
    _cc.attack_multiplier = render_ui_number_field("pm_atkm", 282, 458, 420, 494, _cc.attack_multiplier, 0.1, 10.0, true);
    draw_text(444, 464, "DEF Mult:");
    _cc.defense_multiplier = render_ui_number_field("pm_defm", 554, 458, 692, 494, _cc.defense_multiplier, 0.0, 10.0, true);
    
    if (render_ui_button(716, 458, 1108, 494, "Allow Escape / Run: " + (_cc.allow_run ? "TRUE" : "FALSE"), _cc.allow_run, true)) {
        _cc.allow_run = !_cc.allow_run;
        global.project_dirty = true;
    }
    
    // Primary Project Manager Action Buttons
    draw_set_color(_pal.accent_gold);
    draw_text(172, 510, "PROJECT ACTIONS & SOUND EFFECTS:");
    
    if (render_ui_button(172, 536, 392, 584, "▶ Playtest", true, true)) {
        editor_project_start_playtest();
        return;
    }
    if (render_ui_button(408, 536, 628, 584, "Save Project", false, true)) {
        core_saveload_save_project();
    }
    if (render_ui_button(644, 536, 868, 584, "Export Project", false, true)) {
        core_saveload_export_project_dialog();
    }
    if (render_ui_button(884, 536, 1108, 584, "Save And Exit", false, true)) {
        core_saveload_save_project();
        _ed.active_modal = EDITOR_MODAL.NONE;
        scene_switch_to(ENGINE_SCENE.MAIN_MENU);
        return;
    }
    
    if (render_ui_button(172, 598, 468, 644, "Exit Without Saving...", false, true)) {
        if (global.project_dirty) {
            _ed.active_modal = EDITOR_MODAL.UNSAVED_CONFIRM;
        } else {
            _ed.active_modal = EDITOR_MODAL.NONE;
            scene_switch_to(ENGINE_SCENE.MAIN_MENU);
        }
        return;
    }
    if (render_ui_button(484, 598, 844, 644, "Default UI & Gameplay Sounds...", false, true)) {
        input_end_text_edit();
        _ed.pm_tab_idx = 1;
        return;
    }
    if (render_ui_button(860, 598, 1108, 644, "Return to Editor (F1)", false, true)) {
        input_end_text_edit();
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}
