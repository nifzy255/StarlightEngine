/// @description ST★RLIGHT ENGINE - Character & Directional Animation Schema System
/// Defines playable character schemas, directional sprite animation structures, runtime instances, and ability lookups.

function sys_sprite_clamp_scale(_val) {
    if (is_undefined(_val)) return 1.0;
    var _n = real(_val);
    if (_n <= 0.0) return 1.0;
    return clamp(_n, 0.1, 8.0);
}

function sys_sprite_create_default_clip(_frames_arr, _fps, _loop) {
    var _fcount = is_array(_frames_arr) ? max(1, array_length(_frames_arr)) : 1;
    var _ffiles = array_create(_fcount, "");
    return {
        frame_count: _fcount,
        fps: _fps,
        loop: _loop,
        file_path: "",
        frame_files: _ffiles,
        frames: _frames_arr
    };
}

function sys_sprite_create_default_state(_frames_arr, _fps, _loop, _directional) {
    var _fcount = is_array(_frames_arr) ? max(1, array_length(_frames_arr)) : 1;
    return {
        frame_count: _fcount,
        fps: _fps,
        loop: _loop,
        directional: _directional,
        file_path: "",
        frame_files: array_create(_fcount, ""),
        frames: _frames_arr,
        directions: {
            Down: sys_sprite_create_default_clip(json_parse(json_stringify(_frames_arr)), _fps, _loop),
            Up: sys_sprite_create_default_clip(json_parse(json_stringify(_frames_arr)), _fps, _loop),
            Left: sys_sprite_create_default_clip(json_parse(json_stringify(_frames_arr)), _fps, _loop),
            Right: sys_sprite_create_default_clip(json_parse(json_stringify(_frames_arr)), _fps, _loop)
        }
    };
}

function sys_sprite_create_default_animations() {
    return {
        Idle: sys_sprite_create_default_state([0], 4, true, true),
        Walking: sys_sprite_create_default_state([0, 1, 2, 3], 8, true, true),
        Running: sys_sprite_create_default_state([0, 1, 2, 3], 12, true, true),
        Attacking: sys_sprite_create_default_state([0, 1], 10, false, true),
        TakingDamage: sys_sprite_create_default_state([0], 6, false, false),
        Defeated: sys_sprite_create_default_state([0], 2, false, false)
    };
}

function sys_sprite_get_dir_name(_facing) {
    switch (_facing) {
        case DIR_FACING.UP: return "Up";
        case DIR_FACING.LEFT: return "Left";
        case DIR_FACING.RIGHT: return "Right";
        default: return "Down";
    }
}

function sys_sprite_normalize_clip(_clip, _default_frames, _default_fps, _default_loop) {
    if (!is_struct(_clip)) {
        return sys_sprite_create_default_clip(_default_frames, _default_fps, _default_loop);
    }
    if (!variable_struct_exists(_clip, "fps")) _clip.fps = _default_fps;
    if (!variable_struct_exists(_clip, "loop")) _clip.loop = _default_loop;
    if (!variable_struct_exists(_clip, "file_path")) _clip.file_path = "";
    if (!variable_struct_exists(_clip, "frames") || !is_array(_clip.frames) || array_length(_clip.frames) == 0) {
        _clip.frames = json_parse(json_stringify(_default_frames));
    }
    if (!variable_struct_exists(_clip, "frame_count") || _clip.frame_count < 1) {
        _clip.frame_count = max(1, array_length(_clip.frames));
    }
    _clip.frame_count = clamp(round(_clip.frame_count), 1, 64);
    
    // Synchronize frames array length with frame_count
    while (array_length(_clip.frames) < _clip.frame_count) {
        array_push(_clip.frames, array_length(_clip.frames));
    }
    if (array_length(_clip.frames) > _clip.frame_count) {
        array_resize(_clip.frames, _clip.frame_count);
    }
    
    // Synchronize frame_files array length with frame_count
    if (!variable_struct_exists(_clip, "frame_files") || !is_array(_clip.frame_files)) {
        _clip.frame_files = array_create(_clip.frame_count, "");
    } else {
        while (array_length(_clip.frame_files) < _clip.frame_count) {
            array_push(_clip.frame_files, "");
        }
        if (array_length(_clip.frame_files) > _clip.frame_count) {
            array_resize(_clip.frame_files, _clip.frame_count);
        }
    }
    return _clip;
}

/// @function sys_sprite_normalize_animations(_sp)
/// @description Ensures backward compatibility for existing sprites while adding per-animation & per-direction structures.
function sys_sprite_normalize_animations(_sp) {
    if (!is_struct(_sp)) return;
    if (!variable_struct_exists(_sp, "frame_count") || _sp.frame_count < 1) _sp.frame_count = 4;
    if (!variable_struct_exists(_sp, "file_path")) _sp.file_path = "";
    _sp.scale = sys_sprite_clamp_scale(variable_struct_exists(_sp, "scale") ? _sp.scale : 1.0);
    if (!variable_struct_exists(_sp, "animations") || !is_struct(_sp.animations)) {
        _sp.animations = sys_sprite_create_default_animations();
    }
    
    var _keys = ["Idle", "Walking", "Running", "Attacking", "TakingDamage", "Defeated"];
    var _def_frames = [[0], [0, 1, 2, 3], [0, 1, 2, 3], [0, 1], [0], [0]];
    var _def_fps = [4, 8, 12, 10, 6, 2];
    var _def_loop = [true, true, true, false, false, false];
    var _def_dir = [true, true, true, true, false, false];
    
    for (var i = 0; i < 6; i++) {
        var _k = _keys[i];
        if (!variable_struct_exists(_sp.animations, _k) || !is_struct(variable_struct_get(_sp.animations, _k))) {
            variable_struct_set(_sp.animations, _k, sys_sprite_create_default_state(_def_frames[i], _def_fps[i], _def_loop[i], _def_dir[i]));
        }
        var _st = variable_struct_get(_sp.animations, _k);
        sys_sprite_normalize_clip(_st, _def_frames[i], _def_fps[i], _def_loop[i]);
        if (!variable_struct_exists(_st, "directional")) _st.directional = _def_dir[i];
        
        if (!variable_struct_exists(_st, "directions") || !is_struct(_st.directions)) {
            _st.directions = {
                Down: sys_sprite_create_default_clip(json_parse(json_stringify(_st.frames)), _st.fps, _st.loop),
                Up: sys_sprite_create_default_clip(json_parse(json_stringify(_st.frames)), _st.fps, _st.loop),
                Left: sys_sprite_create_default_clip(json_parse(json_stringify(_st.frames)), _st.fps, _st.loop),
                Right: sys_sprite_create_default_clip(json_parse(json_stringify(_st.frames)), _st.fps, _st.loop)
            };
        } else {
            var _dnames = ["Down", "Up", "Left", "Right"];
            for (var d = 0; d < 4; d++) {
                var _dn = _dnames[d];
                var _dc = variable_struct_exists(_st.directions, _dn) ? variable_struct_get(_st.directions, _dn) : undefined;
                _dc = sys_sprite_normalize_clip(_dc, _st.frames, _st.fps, _st.loop);
                variable_struct_set(_st.directions, _dn, _dc);
            }
        }
    }
}

/// @function sys_sprite_clip_has_custom_assets(_clip)
/// @description Returns true if a clip has either a strip file_path or at least one per-frame PNG path.
function sys_sprite_clip_has_custom_assets(_clip) {
    if (!is_struct(_clip)) return false;
    if (variable_struct_exists(_clip, "file_path") && _clip.file_path != "") return true;
    if (variable_struct_exists(_clip, "frame_files") && is_array(_clip.frame_files)) {
        for (var i = 0; i < array_length(_clip.frame_files); i++) {
            if (_clip.frame_files[i] != "") return true;
        }
    }
    return false;
}

/// @function sys_sprite_get_clip(_sp, _anim_state, _dir_name)
/// @description Retrieves the editable clip struct for a specific animation state and direction ("Down", "Up", "Left", "Right").
function sys_sprite_get_clip(_sp, _anim_state, _dir_name) {
    if (!is_struct(_sp)) return undefined;
    sys_sprite_normalize_animations(_sp);
    var _skey = variable_struct_exists(_sp.animations, _anim_state) ? _anim_state : "Idle";
    var _st = variable_struct_get(_sp.animations, _skey);
    if (_st.directional && is_struct(_st.directions) && variable_struct_exists(_st.directions, _dir_name)) {
        return variable_struct_get(_st.directions, _dir_name);
    }
    return _st;
}

function sys_character_create_default(_id, _name) {
    return {
        id: _id,
        name: _name,
        description: "A brave young adventurer guided by starlight.",
        sprite_id: "spr_hero_default",
        battle_sprite_id: "spr_hero_default",
        portrait_sprite_id: "",
        sprite_scale: 1.0,
        starting_level: 1,
        starting_exp: 0,
        exp_base: 30,
        exp_curve_factor: 1.35,
        max_hp: 45,
        current_hp: 45,
        max_mp: 18,
        current_mp: 18,
        attack: 11,
        defense: 7,
        speed: 9,
        luck: 5,
        growth_hp: 8,
        growth_mp: 4,
        growth_attack: 3,
        growth_defense: 2,
        growth_speed: 2,
        equipment: {
            weapon: "",
            armor: "",
            accessory: ""
        },
        abilities: [
            {
                id: "abil_star_beam",
                name: "Star Beam α",
                description: "Fires a concentrated beam of cosmic starlight at one foe.",
                level_req: 1,
                mp_cost: 4,
                power: 22,
                is_healing: false,
                target_type: "single_enemy",
                status_effect: ""
            },
            {
                id: "abil_lifeup",
                name: "Lifeup α",
                description: "Restores a moderate amount of HP to a party member.",
                level_req: 2,
                mp_cost: 5,
                power: 35,
                is_healing: true,
                target_type: "single_ally",
                status_effect: ""
            }
        ]
    };
}

function sys_character_find_def(_char_id_or_name) {
    if (is_undefined(global.project) || !variable_struct_exists(global.project, "characters")) return undefined;
    var _chars = global.project.characters;
    for (var i = 0; i < array_length(_chars); i++) {
        if (_chars[i].id == _char_id_or_name || _chars[i].name == _char_id_or_name) {
            return _chars[i];
        }
    }
    return undefined;
}

/// @function sys_character_instantiate_runtime(_def)
/// @description Creates an independent mutable runtime character struct from a database character definition.
function sys_character_instantiate_runtime(_def) {
    if (!is_struct(_def)) {
        _def = sys_character_create_default("char_fallback", "Hero");
    }
    var _lvl = variable_struct_exists(_def, "starting_level") ? max(1, _def.starting_level) : 1;
    var _exp = variable_struct_exists(_def, "starting_exp") ? max(0, _def.starting_exp) : 0;
    
    var _inst = {
        id: _def.id,
        name: _def.name,
        description: variable_struct_exists(_def, "description") ? _def.description : "",
        sprite_id: variable_struct_exists(_def, "sprite_id") ? _def.sprite_id : "spr_hero_default",
        battle_sprite_id: variable_struct_exists(_def, "battle_sprite_id") ? _def.battle_sprite_id : "spr_hero_default",
        portrait_sprite_id: variable_struct_exists(_def, "portrait_sprite_id") ? _def.portrait_sprite_id : "",
        sprite_scale: sys_sprite_clamp_scale(variable_struct_exists(_def, "sprite_scale") ? _def.sprite_scale : 1.0),
        level: _lvl,
        exp: _exp,
        exp_base: variable_struct_exists(_def, "exp_base") ? max(10, _def.exp_base) : 30,
        exp_curve_factor: variable_struct_exists(_def, "exp_curve_factor") ? max(1.05, _def.exp_curve_factor) : 1.35,
        max_hp: variable_struct_exists(_def, "max_hp") ? max(1, _def.max_hp) : 40,
        current_hp: variable_struct_exists(_def, "current_hp") ? max(1, _def.current_hp) : 40,
        rolling_hp: variable_struct_exists(_def, "current_hp") ? max(1, _def.current_hp) : 40,
        max_mp: variable_struct_exists(_def, "max_mp") ? max(0, _def.max_mp) : 15,
        current_mp: variable_struct_exists(_def, "current_mp") ? max(0, _def.current_mp) : 15,
        attack: variable_struct_exists(_def, "attack") ? _def.attack : 10,
        defense: variable_struct_exists(_def, "defense") ? _def.defense : 6,
        speed: variable_struct_exists(_def, "speed") ? _def.speed : 8,
        luck: variable_struct_exists(_def, "luck") ? _def.luck : 5,
        growth_hp: variable_struct_exists(_def, "growth_hp") ? _def.growth_hp : 7,
        growth_mp: variable_struct_exists(_def, "growth_mp") ? _def.growth_mp : 3,
        growth_attack: variable_struct_exists(_def, "growth_attack") ? _def.growth_attack : 2,
        growth_defense: variable_struct_exists(_def, "growth_defense") ? _def.growth_defense : 2,
        growth_speed: variable_struct_exists(_def, "growth_speed") ? _def.growth_speed : 1,
        equipment: {
            weapon: (variable_struct_exists(_def, "equipment") && variable_struct_exists(_def.equipment, "weapon")) ? _def.equipment.weapon : "",
            armor: (variable_struct_exists(_def, "equipment") && variable_struct_exists(_def.equipment, "armor")) ? _def.equipment.armor : "",
            accessory: (variable_struct_exists(_def, "equipment") && variable_struct_exists(_def.equipment, "accessory")) ? _def.equipment.accessory : ""
        },
        abilities: variable_struct_exists(_def, "abilities") ? json_parse(json_stringify(_def.abilities)) : [],
        status_effect: ""
    };
    return _inst;
}

/// @function sys_character_get_unlocked_abilities(_char_inst)
/// @description Returns all abilities learned by this character at their current level/EXP.
function sys_character_get_unlocked_abilities(_char_inst) {
    var _unlocked = [];
    if (!is_struct(_char_inst) || !variable_struct_exists(_char_inst, "abilities")) return _unlocked;
    for (var i = 0; i < array_length(_char_inst.abilities); i++) {
        var _ab = _char_inst.abilities[i];
        var _req_lvl = variable_struct_exists(_ab, "level_req") ? _ab.level_req : 1;
        if (_char_inst.level >= _req_lvl) {
            array_push(_unlocked, _ab);
        }
    }
    return _unlocked;
}
