/// @description ST★RLIGHT ENGINE - Character & Runtime Statistics System
/// Computes effective combat stats (base + equipment bonuses) and tracks playtime & adventure telemetry.

function sys_stats_create_telemetry() {
    return {
        steps_taken: 0,
        battles_fought: 0,
        battles_won: 0,
        enemies_defeated: 0,
        total_gold_earned: 0,
        total_exp_earned: 0,
        items_used: 0
    };
}

function sys_stats_get_equipment_bonus(_char_inst, _stat_field) {
    if (!is_struct(_char_inst) || !variable_struct_exists(_char_inst, "equipment")) return 0;
    var _eq = _char_inst.equipment;
    var _slots = ["weapon", "armor", "accessory"];
    var _bonus = 0;
    for (var i = 0; i < 3; i++) {
        var _item_id = variable_struct_exists(_eq, _slots[i]) ? variable_struct_get(_eq, _slots[i]) : "";
        if (_item_id != "") {
            var _idef = sys_item_find_def(_item_id);
            if (is_struct(_idef) && variable_struct_exists(_idef, _stat_field)) {
                _bonus += variable_struct_get(_idef, _stat_field);
            }
        }
    }
    return _bonus;
}

function sys_stats_get_effective_attack(_char_inst) {
    if (!is_struct(_char_inst)) return 1;
    return max(1, _char_inst.attack + sys_stats_get_equipment_bonus(_char_inst, "bonus_attack"));
}

function sys_stats_get_effective_defense(_char_inst) {
    if (!is_struct(_char_inst)) return 0;
    return max(0, _char_inst.defense + sys_stats_get_equipment_bonus(_char_inst, "bonus_defense"));
}

function sys_stats_get_effective_speed(_char_inst) {
    if (!is_struct(_char_inst)) return 1;
    return max(1, _char_inst.speed + sys_stats_get_equipment_bonus(_char_inst, "bonus_speed"));
}

function sys_stats_format_playtime(_seconds) {
    var _total = max(0, floor(_seconds));
    var _hrs = _total div 3600;
    var _mins = (_total mod 3600) div 60;
    var _secs = _total mod 60;
    var _h_str = (_hrs < 10 ? "0" : "") + string(_hrs);
    var _m_str = (_mins < 10 ? "0" : "") + string(_mins);
    var _s_str = (_secs < 10 ? "0" : "") + string(_secs);
    return _h_str + ":" + _m_str + ":" + _s_str;
}
