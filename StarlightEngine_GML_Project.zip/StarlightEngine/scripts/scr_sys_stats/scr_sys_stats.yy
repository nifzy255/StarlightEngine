{
  "$GMScript": "v1",
  "%Name": "scr_sys_stats",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_sys_stats",
  "parent": {
    "name": "Systems",
    "path": "folders/Engine/Systems.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}