/// @description ST★RLIGHT ENGINE - Enemy Overworld AI, Respawn & Database System
/// Implements all 6 overworld AI behaviors, collision-aware movement, defeat persistence, and contact battle triggers.

function sys_enemy_create_default(_id, _name) {
    return {
        id: _id,
        name: _name,
        sprite_id: "spr_enemy_default",
        battle_sprite_id: "spr_enemy_default",
        overworld_scale: 1.0,
        battle_scale: 1.0,
        max_hp: 36,
        attack: 10,
        defense: 4,
        speed: 7,
        ai_behavior: ENEMY_AI_MODE.CHASE_PLAYER,
        detection_radius: 140,
        wander_radius: 96,
        move_speed: 1.5,
        defeat_mode: ENEMY_DEFEAT_MODE.RESPAWN_ON_REENTRY,
        respawn_seconds: 15,
        weakness: "star",
        resistance: "physical_none",
        status_immunity: "",
        reward_exp: 24,
        reward_gold: 18,
        reward_item_id: "",
        reward_event_id: "",
        battle_ai_style: "balanced",
        abilities: [
            {
                name: "Cosmic Tackle",
                power: 12,
                mp_cost: 0,
                status_effect: "",
                weight: 70
            },
            {
                name: "Stardust Flash",
                power: 16,
                mp_cost: 3,
                status_effect: "dazzle",
                weight: 30
            }
        ]
    };
}

function sys_enemy_find_def(_enemy_id_or_name) {
    if (is_undefined(global.project) || !variable_struct_exists(global.project, "enemies")) return undefined;
    var _list = global.project.enemies;
    for (var i = 0; i < array_length(_list); i++) {
        if (_list[i].id == _enemy_id_or_name || _list[i].name == _enemy_id_or_name) {
            return _list[i];
        }
    }
    return undefined;
}

/// @function sys_enemy_update_map_instance(_inst, _map_struct)
/// @description Updates a single overworld enemy instance according to its configured AI and collision rules.
function sys_enemy_update_map_instance(_inst, _map_struct) {
    if (!is_struct(_inst)) return;
    
    // Handle defeated state and timed respawn
    if (_inst.defeated) {
        if (_inst.defeat_mode == ENEMY_DEFEAT_MODE.RESPAWN_TIMED) {
            _inst.respawn_timer--;
            if (_inst.respawn_timer <= 0) {
                _inst.defeated = false;
                _inst.x = _inst.spawn_x;
                _inst.y = _inst.spawn_y;
            }
        }
        return;
    }
    
    // Check variable visibility condition if set
    if (variable_struct_exists(_inst, "condition_var") && _inst.condition_var != "") {
        var _exp_val = variable_struct_exists(_inst, "condition_val") ? _inst.condition_val : true;
        if (!sys_variable_check(_inst.condition_var, _exp_val)) {
            return;
        }
    }
    
    var _px = global.runtime.player_x;
    var _py = global.runtime.player_y;
    var _dist = point_distance(_inst.x, _inst.y, _px, _py);
    var _spd = variable_struct_exists(_inst, "move_speed") ? _inst.move_speed : 1.5;
    var _detect = variable_struct_exists(_inst, "detection_radius") ? _inst.detection_radius : 140;
    var _wander = variable_struct_exists(_inst, "wander_radius") ? _inst.wander_radius : 96;
    
    var _vx = 0;
    var _vy = 0;
    
    switch (_inst.ai_behavior) {
        case ENEMY_AI_MODE.STAY_STILL:
            _vx = 0;
            _vy = 0;
            break;
            
        case ENEMY_AI_MODE.CHASE_PLAYER:
            if (_dist <= _detect && _dist > 2) {
                var _dir = point_direction(_inst.x, _inst.y, _px, _py);
                _vx = lengthdir_x(_spd, _dir);
                _vy = lengthdir_y(_spd, _dir);
            }
            break;
            
        case ENEMY_AI_MODE.RUN_AWAY:
            if (_dist <= _detect && _dist > 1) {
                var _adir = point_direction(_px, _py, _inst.x, _inst.y);
                _vx = lengthdir_x(_spd, _adir);
                _vy = lengthdir_y(_spd, _adir);
            }
            break;
            
        case ENEMY_AI_MODE.IGNORE_PLAYER:
        case ENEMY_AI_MODE.WANDER_RADIUS:
            _inst.wander_timer--;
            if (_inst.wander_timer <= 0) {
                _inst.wander_timer = irandom_range(40, 100);
                if (irandom(2) == 0) {
                    _inst.wander_vx = 0;
                    _inst.wander_vy = 0;
                } else {
                    var _wdir = choose(0, 90, 180, 270);
                    _inst.wander_vx = lengthdir_x(_spd * 0.75, _wdir);
                    _inst.wander_vy = lengthdir_y(_spd * 0.75, _wdir);
                }
            }
            if (point_distance(_inst.spawn_x, _inst.spawn_y, _inst.x + _inst.wander_vx, _inst.y + _inst.wander_vy) <= _wander) {
                _vx = _inst.wander_vx;
                _vy = _inst.wander_vy;
            } else {
                var _back_dir = point_direction(_inst.x, _inst.y, _inst.spawn_x, _inst.spawn_y);
                _vx = lengthdir_x(_spd * 0.75, _back_dir);
                _vy = lengthdir_y(_spd * 0.75, _back_dir);
            }
            break;
            
        case ENEMY_AI_MODE.STOP_WHEN_NEARBY:
            if (_dist <= _detect) {
                _vx = 0;
                _vy = 0;
            } else {
                _inst.wander_timer--;
                if (_inst.wander_timer <= 0) {
                    _inst.wander_timer = irandom_range(45, 90);
                    var _sdir = choose(0, 90, 180, 270);
                    _inst.wander_vx = lengthdir_x(_spd * 0.65, _sdir);
                    _inst.wander_vy = lengthdir_y(_spd * 0.65, _sdir);
                }
                _vx = _inst.wander_vx;
                _vy = _inst.wander_vy;
            }
            break;
    }
    
    // Apply movement while respecting map collision and boundaries
    if (!variable_struct_exists(_inst, "facing")) _inst.facing = DIR_FACING.DOWN;
    var _prev_e_state = _inst.anim_state;
    if (_vx != 0 || _vy != 0) {
        if (abs(_vy) >= abs(_vx)) {
            _inst.facing = (_vy > 0) ? DIR_FACING.DOWN : DIR_FACING.UP;
        } else {
            _inst.facing = (_vx > 0) ? DIR_FACING.RIGHT : DIR_FACING.LEFT;
        }
        if (!runtime_check_tile_collision(_map_struct, _inst.x + _vx, _inst.y, 26, 26)) {
            _inst.x += _vx;
        }
        if (!runtime_check_tile_collision(_map_struct, _inst.x, _inst.y + _vy, 26, 26)) {
            _inst.y += _vy;
        }
        _inst.anim_state = "Walking";
    } else {
        _inst.anim_state = "Idle";
    }
    if (_inst.anim_state != _prev_e_state) {
        _inst.anim_frame = 0;
    }
    var _efps = core_assets_get_anim_fps(_inst.sprite_id, _inst.anim_state, _inst.facing);
    _inst.anim_frame += (_efps / 60.0);
    
    // Contact between player and enemy immediately initiates battle (with active-battle & grace guard)
    if (global.scene.current == ENGINE_SCENE.RUNTIME_PLAY &&
        !global.battle.active &&
        global.runtime.battle_grace_timer <= 0 &&
        point_distance(_inst.x + 16, _inst.y + 16, _px + 16, _py + 16) < 24) {
        sys_battle_initiate_by_enemy_id(_inst.enemy_id, _inst);
    }
}
