/// @description ST★RLIGHT ENGINE - Tile Editor, Paginated Tile Browser & Tileset Manager
/// Supports full tileset sheet import, singular PNG tile import with preview, individual tile deletion, and safe tileset deletion.

function editor_get_layer_name(_layer_idx) {
    switch (_layer_idx) {
        case 0: return "0: Background";
        case 1: return "1: Ground";
        case 2: return "2: Decorations";
        case 3: return "3: Foreground";
        default: return "Layer " + string(_layer_idx);
    }
}

function editor_tiles_get_cell(_map, _layer_idx, _gx, _gy) {
    if (!is_struct(_map) || !variable_struct_exists(_map, "layers")) return 0;
    if (_layer_idx < 0 || _layer_idx >= array_length(_map.layers)) return 0;
    if (_gx < 0 || _gy < 0 || _gx >= _map.width || _gy >= _map.height) return 0;
    var _data = _map.layers[_layer_idx].data;
    var _idx = (_gy * _map.width) + _gx;
    if (_idx < 0 || _idx >= array_length(_data)) return 0;
    return _data[_idx];
}

function editor_tiles_set_cell(_map, _layer_idx, _gx, _gy, _tile_val) {
    if (!is_struct(_map) || !variable_struct_exists(_map, "layers")) return;
    if (_layer_idx < 0 || _layer_idx >= array_length(_map.layers)) return;
    if (_gx < 0 || _gy < 0 || _gx >= _map.width || _gy >= _map.height) return;
    var _data = _map.layers[_layer_idx].data;
    var _idx = (_gy * _map.width) + _gx;
    if (_idx >= 0 && _idx < array_length(_data)) {
        _data[_idx] = max(0, _tile_val);
        global.project_dirty = true;
    }
}

function editor_tiles_replace_all(_map, _layer_idx, _from_tile, _to_tile) {
    if (!is_struct(_map)) return;
    editor_push_undo_snapshot();
    var _data = _map.layers[_layer_idx].data;
    var _replaced = 0;
    for (var i = 0; i < array_length(_data); i++) {
        if (_data[i] == _from_tile) {
            _data[i] = _to_tile;
            _replaced++;
        }
    }
    global.project_dirty = true;
    core_log_toast("Replaced " + string(_replaced) + " tiles on layer.");
}

/// @function editor_tiles_import_custom_png()
/// @description Uploads a PNG tileset sheet and creates a new tileset entry sliced into grid tiles.
function editor_tiles_import_custom_png() {
    var _src = get_open_filename("PNG Tileset Sheet (*.png)|*.png", "");
    if (_src == "" || !file_exists(_src)) return false;
    
    var _fname = filename_name(_src);
    var _rel = "tilesets/" + _fname;
    var _full_dest = _src;
    if (global.project_path != "") {
        directory_create(global.project_path + "tilesets/");
        _full_dest = global.project_path + _rel;
        file_copy(_src, _full_dest);
    }
    
    var _detected_count = 1;
    var _cell_size = 32;
    var _map = editor_get_active_map();
    if (is_struct(_map) && variable_struct_exists(_map, "tile_size")) {
        _cell_size = max(8, _map.tile_size);
    }
    var _probe_spr = sprite_add(_full_dest, 1, false, false, 0, 0);
    if (_probe_spr >= 0 && sprite_exists(_probe_spr)) {
        var _eff_cell = max(1, min(_cell_size, min(sprite_get_width(_probe_spr), sprite_get_height(_probe_spr))));
        var _cols = max(1, sprite_get_width(_probe_spr) div _eff_cell);
        var _rows = max(1, sprite_get_height(_probe_spr) div _eff_cell);
        _detected_count = max(1, _cols * _rows);
        _cell_size = _eff_cell;
        sprite_delete(_probe_spr);
    }
    
    var _new_id = "ts_custom_" + string(array_length(global.project.tilesets) + 1);
    var _new_ts = {
        id: _new_id,
        name: _fname,
        file_path: _rel,
        tile_size: _cell_size,
        tile_count: _detected_count,
        custom_tiles: [],
        tile_entries: []
    };
    core_assets_ensure_tileset_entries(_new_ts);
    array_push(global.project.tilesets, _new_ts);
    
    global.editor.selected_tileset_id = _new_id;
    global.editor.tile_page_offset = 0;
    global.editor.selected_tile_index = 1;
    if (is_struct(_map)) {
        _map.tileset_id = _new_id;
    }
    global.project_dirty = true;
    core_log_toast("Uploaded tileset: " + _fname + " (" + string(_detected_count) + " tiles)");
    return true;
}

/// @function editor_tiles_begin_import_singular_png()
/// @description Selects an individual PNG file and opens the live preview confirmation before adding it to the current tileset.
function editor_tiles_begin_import_singular_png() {
    var _src = get_open_filename("Single PNG Tile Image (*.png)|*.png", "");
    if (_src == "" || !file_exists(_src)) return false;
    
    var _fname = filename_name(_src);
    var _rel = "tilesets/single_" + string(current_time) + "_" + _fname;
    if (global.project_path != "") {
        directory_create(global.project_path + "tilesets/");
        file_copy(_src, global.project_path + _rel);
    } else {
        _rel = _src;
    }
    
    global.editor.tile_pending_png_rel = _rel;
    global.editor.tile_pending_png_name = _fname;
    global.editor.tile_confirm_mode = 1; // Preview & confirm singular tile import
    return true;
}

/// @function editor_tiles_confirm_singular_import()
/// @description Commits the previewed singular PNG tile into the active tileset without replacing existing tiles.
function editor_tiles_confirm_singular_import() {
    var _ed = global.editor;
    var _ts = core_assets_find_tileset(_ed.selected_tileset_id);
    if (!is_struct(_ts) || _ed.tile_pending_png_rel == "") {
        _ed.tile_confirm_mode = 0;
        return false;
    }
    
    var _entries = core_assets_ensure_tileset_entries(_ts);
    var _new_entry = {
        kind: "custom_png",
        name: _ed.tile_pending_png_name,
        file_path: _ed.tile_pending_png_rel
    };
    array_push(_entries, _new_entry);
    if (!variable_struct_exists(_ts, "custom_tiles") || !is_array(_ts.custom_tiles)) {
        _ts.custom_tiles = [];
    }
    array_push(_ts.custom_tiles, {
        name: _ed.tile_pending_png_name,
        file_path: _ed.tile_pending_png_rel
    });
    _ts.tile_count = array_length(_entries);
    
    _ed.selected_tile_index = _ts.tile_count;
    _ed.tile_page_offset = max(0, (_ed.selected_tile_index - 1) div 12);
    _ed.tile_pending_png_rel = "";
    _ed.tile_pending_png_name = "";
    _ed.tile_confirm_mode = 0;
    global.project_dirty = true;
    core_log_toast("Added tile #" + string(_ts.tile_count) + " to tileset '" + _ts.name + "'.");
    return true;
}

/// @function editor_tiles_execute_delete_selected_tile()
/// @description Deletes the currently selected tile from the active tileset and safely updates all map layer references.
function editor_tiles_execute_delete_selected_tile() {
    var _ed = global.editor;
    var _ts = core_assets_find_tileset(_ed.selected_tileset_id);
    if (!is_struct(_ts)) {
        _ed.tile_confirm_mode = 0;
        return false;
    }
    var _entries = core_assets_ensure_tileset_entries(_ts);
    if (array_length(_entries) <= 1) {
        core_log_toast("Cannot delete the last remaining tile in a tileset.");
        _ed.tile_confirm_mode = 0;
        return false;
    }
    
    var _del_idx = clamp(_ed.selected_tile_index, 1, array_length(_entries));
    var _del_name = core_assets_get_tile_label(_ts.id, _del_idx);
    
    // Remove from tile_entries
    array_delete(_entries, _del_idx - 1, 1);
    _ts.tile_count = array_length(_entries);
    
    // Rebuild custom_tiles array to stay in sync
    _ts.custom_tiles = [];
    for (var e = 0; e < array_length(_entries); e++) {
        if (_entries[e].kind == "custom_png") {
            array_push(_ts.custom_tiles, {
                name: _entries[e].name,
                file_path: _entries[e].file_path
            });
        }
    }
    
    // Safely update all map layer cells referencing this tileset
    if (is_struct(global.project) && is_array(global.project.maps)) {
        for (var m = 0; m < array_length(global.project.maps); m++) {
            var _mp = global.project.maps[m];
            if (is_struct(_mp) && _mp.tileset_id == _ts.id && is_array(_mp.layers)) {
                for (var l = 0; l < array_length(_mp.layers); l++) {
                    var _ldata = _mp.layers[l].data;
                    for (var c = 0; c < array_length(_ldata); c++) {
                        if (_ldata[c] == _del_idx) {
                            _ldata[c] = 0;
                        } else if (_ldata[c] > _del_idx) {
                            _ldata[c] -= 1;
                        }
                    }
                }
            }
        }
    }
    
    _ed.selected_tile_index = clamp(_ed.selected_tile_index, 1, _ts.tile_count);
    var _max_pg = max(1, ceil(_ts.tile_count / 12));
    _ed.tile_page_offset = clamp(_ed.tile_page_offset, 0, _max_pg - 1);
    _ed.tile_confirm_mode = 0;
    global.project_dirty = true;
    core_log_toast("Deleted " + _del_name + " and updated map references.");
    return true;
}

/// @function editor_tiles_get_maps_using_tileset(_tileset_id)
/// @description Returns an array of map names currently using the specified tileset ID.
function editor_tiles_get_maps_using_tileset(_tileset_id) {
    var _used = [];
    if (!is_struct(global.project) || !is_array(global.project.maps)) return _used;
    for (var i = 0; i < array_length(global.project.maps); i++) {
        var _m = global.project.maps[i];
        if (is_struct(_m) && variable_struct_exists(_m, "tileset_id") && _m.tileset_id == _tileset_id) {
            array_push(_used, _m.name + " [" + _m.id + "]");
        }
    }
    return _used;
}

/// @function editor_tiles_execute_delete_current_tileset()
/// @description Deletes the active tileset and safely reassigns any maps using it to a valid fallback tileset.
function editor_tiles_execute_delete_current_tileset() {
    var _ed = global.editor;
    if (!is_struct(global.project) || !is_array(global.project.tilesets)) {
        _ed.tile_confirm_mode = 0;
        return false;
    }
    
    var _tlist = global.project.tilesets;
    var _del_id = _ed.selected_tileset_id;
    var _del_name = _del_id;
    for (var i = array_length(_tlist) - 1; i >= 0; i--) {
        if (_tlist[i].id == _del_id) {
            _del_name = _tlist[i].name;
            array_delete(_tlist, i, 1);
            break;
        }
    }
    
    // Ensure project always has at least one valid tileset
    if (array_length(_tlist) == 0) {
        var _def_ts = {
            id: "ts_default_16bit",
            name: "Default 16-Bit Tileset",
            file_path: "",
            tile_size: 32,
            tile_count: 24,
            custom_tiles: [],
            tile_entries: []
        };
        core_assets_ensure_tileset_entries(_def_ts);
        array_push(_tlist, _def_ts);
    }
    
    var _fallback_ts = _tlist[0];
    var _fallback_max = core_assets_get_tileset_tile_count(_fallback_ts.id);
    
    // Safely update any maps that referenced the deleted tileset
    if (is_array(global.project.maps)) {
        for (var m = 0; m < array_length(global.project.maps); m++) {
            var _mp = global.project.maps[m];
            if (is_struct(_mp) && _mp.tileset_id == _del_id) {
                _mp.tileset_id = _fallback_ts.id;
                if (is_array(_mp.layers)) {
                    for (var l = 0; l < array_length(_mp.layers); l++) {
                        var _ldata = _mp.layers[l].data;
                        for (var c = 0; c < array_length(_ldata); c++) {
                            if (_ldata[c] > _fallback_max) {
                                _ldata[c] = _fallback_max;
                            }
                        }
                    }
                }
            }
        }
    }
    
    _ed.selected_tileset_id = _fallback_ts.id;
    _ed.selected_tile_index = 1;
    _ed.tile_page_offset = 0;
    _ed.tile_confirm_mode = 0;
    global.project_dirty = true;
    core_log_toast("Deleted tileset '" + _del_name + "'. Maps safely reassigned to '" + _fallback_ts.name + "'.");
    return true;
}

function editor_tiles_draw_selector_modal(_map) {
    var _ed = global.editor;
    var _pal = global.palette;
    
    render_window_frame(160, 40, 1120, 680, "TILE SELECTION MENU & TILESET MANAGER", _pal.accent_gold);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    var _ts = core_assets_find_tileset(_ed.selected_tileset_id);
    if (is_struct(_ts)) {
        _ed.selected_tileset_id = _ts.id;
    }
    var _total_tiles = max(1, core_assets_get_tileset_tile_count(_ed.selected_tileset_id));
    _ed.selected_tile_index = clamp(_ed.selected_tile_index, 1, _total_tiles);
    var _per_page = 12;
    var _total_pages = max(1, ceil(_total_tiles / _per_page));
    
    // Confirmation Dialog Overlays (1 = Singular Tile Preview, 2 = Delete Tile, 3 = Delete Tileset)
    if (_ed.tile_confirm_mode != 0) {
        editor_tiles_draw_confirmation_overlay(_ts, _total_tiles);
        return;
    }
    
    // Support Mouse-Wheel Scrolling inside the Tile Grid
    if (input_mouse_in_rect(180, 158, 1080, 444)) {
        if (global.input.wheel_up) {
            _ed.tile_page_offset = max(0, _ed.tile_page_offset - 1);
        } else if (global.input.wheel_down) {
            _ed.tile_page_offset = min(_total_pages - 1, _ed.tile_page_offset + 1);
        }
    }
    _ed.tile_page_offset = clamp(_ed.tile_page_offset, 0, _total_pages - 1);
    
    // Top Bar: Active Tileset Info, Switcher, & Non-Overlapping Pagination Controls
    var _ts_title = is_struct(_ts) ? (_ts.name + " [" + _ts.id + "]") : _ed.selected_tileset_id;
    draw_set_color(_pal.accent_cyan);
    draw_text(188, 84, "Active Tileset: " + render_fit_text(_ts_title, 480) + "  (" + string(_total_tiles) + " tiles)");
    
    if (render_ui_button(188, 114, 430, 150, "Switch Tileset (" + string(array_length(global.project.tilesets)) + ") >", false, array_length(global.project.tilesets) > 1)) {
        var _tlist = global.project.tilesets;
        var _cur_ti = 0;
        for (var ti = 0; ti < array_length(_tlist); ti++) {
            if (_tlist[ti].id == _ed.selected_tileset_id) _cur_ti = ti;
        }
        _cur_ti = (_cur_ti + 1) mod array_length(_tlist);
        _ed.selected_tileset_id = _tlist[_cur_ti].id;
        if (is_struct(_map)) _map.tileset_id = _ed.selected_tileset_id;
        _ed.tile_page_offset = 0;
        _ed.selected_tile_index = 1;
        global.project_dirty = true;
    }
    
    if (render_ui_button(620, 114, 770, 150, "< Prev Page", false, _ed.tile_page_offset > 0)) {
        _ed.tile_page_offset--;
    }
    draw_set_color(_pal.accent_gold);
    draw_text(786, 122, "Page " + string(_ed.tile_page_offset + 1) + " / " + string(_total_pages));
    if (render_ui_button(920, 114, 1070, 150, "Next Page >", false, _ed.tile_page_offset + 1 < _total_pages)) {
        _ed.tile_page_offset++;
    }
    
    // 4x3 Grid of Tiles for Current Page (y = 162 .. 432)
    var _start_tile = (_ed.tile_page_offset * _per_page) + 1;
    var _end_tile = min(_total_tiles, _start_tile + _per_page - 1);
    
    for (var t = _start_tile; t <= _end_tile; t++) {
        var _local = t - _start_tile;
        var _col = _local mod 4;
        var _row = _local div 4;
        var _tx1 = 188 + _col * 222;
        var _ty1 = 162 + _row * 90;
        var _tx2 = _tx1 + 210;
        var _ty2 = _ty1 + 78;
        
        var _is_sel = (_ed.selected_tile_index == t);
        var _hover = !global.input.mouse_consumed && input_mouse_in_rect(_tx1, _ty1, _tx2, _ty2);
        draw_set_color(_is_sel ? make_color_rgb(44, 56, 102) : (_hover ? make_color_rgb(30, 38, 70) : _pal.panel_alt));
        draw_rectangle(_tx1, _ty1, _tx2, _ty2, false);
        draw_set_color(_is_sel ? _pal.accent_gold : (_hover ? _pal.accent_cyan : _pal.border_inner));
        draw_rectangle(_tx1, _ty1, _tx2, _ty2, true);
        if (_is_sel) {
            draw_rectangle(_tx1 + 1, _ty1 + 1, _tx2 - 1, _ty2 - 1, true);
        }
        
        core_assets_draw_tile(_ed.selected_tileset_id, t, _tx1 + 10, _ty1 + 15, 48);
        var _tlabel = core_assets_get_tile_label(_ed.selected_tileset_id, t);
        draw_set_color(_is_sel ? _pal.accent_gold : _pal.text_primary);
        draw_text(_tx1 + 66, _ty1 + 26, render_fit_text(_tlabel, 136));
        
        if (input_click_in_rect(_tx1, _ty1, _tx2, _ty2)) {
            _ed.selected_tile_index = t;
            _ed.mouse_mode = MOUSE_EDIT_MODE.PLACE;
            core_audio_play_sfx_ui("ui_select");
        }
    }
    
    // Vertical scrollbar on right of tile grid
    render_scrollbar(1084, 162, 268, _total_pages, 1, _ed.tile_page_offset);
    
    // Section Below Tile Grid: Tileset Management & Layer Utilities (No Overlap with Pagination!)
    draw_set_color(_pal.accent_cyan);
    draw_text(188, 446, "TILESET MANAGEMENT (UPLOAD TILESET, IMPORT SINGULAR TILE, DELETE TILE / TILESET):");
    
    // Row 1: Upload Custom PNG Tileset | Import Singular Tile to This Tileset | Delete Selected Tile
    if (render_ui_button(188, 472, 464, 512, "Upload Custom PNG Tileset", false, true)) {
        editor_tiles_import_custom_png();
    }
    if (render_ui_button(476, 472, 824, 512, "Import Singular Tile to This Tileset", false, true)) {
        editor_tiles_begin_import_singular_png();
    }
    if (render_ui_button(836, 472, 1080, 512, "Delete Selected Tile", false, _total_tiles > 1)) {
        _ed.tile_confirm_mode = 2;
    }
    
    // Row 2: Delete Current Tileset | Fill Empty Cells With Selected | Clear Active Layer
    if (render_ui_button(188, 522, 464, 562, "Delete Current Tileset", false, true)) {
        _ed.tile_confirm_mode = 3;
    }
    if (render_ui_button(476, 522, 788, 562, "Fill Empty Cells With Selected", false, true)) {
        editor_tiles_replace_all(_map, _ed.active_layer, 0, _ed.selected_tile_index);
    }
    if (render_ui_button(800, 522, 1080, 562, "Clear Active Layer", false, true)) {
        editor_push_undo_snapshot();
        _map.layers[_ed.active_layer].data = array_create(_map.width * _map.height, 0);
        global.project_dirty = true;
        core_log_toast("Cleared active layer.");
    }
    
    // Bottom Summary & Close Button
    draw_set_color(_pal.text_secondary);
    draw_text(188, 582, "Selected: " + core_assets_get_tile_label(_ed.selected_tileset_id, _ed.selected_tile_index) + "  |  Drawing Layer: " + editor_get_layer_name(_ed.active_layer));
    draw_text(188, 614, "Tip: Scroll the Mouse Wheel over the tile grid or use < Prev / Next > to browse all tiles.");
    
    if (render_ui_button(880, 616, 1080, 658, "Done (Esc)", true, true)) {
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}

function editor_tiles_draw_confirmation_overlay(_ts, _total_tiles) {
    var _ed = global.editor;
    var _pal = global.palette;
    
    render_window_frame(260, 140, 1020, 560, "TILESET MANAGER CONFIRMATION", _pal.accent_gold);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    if (_ed.tile_confirm_mode == 1) {
        // 16.A: Preview Singular Imported Tile before confirming
        draw_set_color(_pal.accent_cyan);
        draw_text(292, 194, "PREVIEW SINGULAR TILE BEFORE ADDING TO TILESET:");
        draw_set_color(_pal.text_primary);
        draw_text(292, 226, "Target Tileset: " + (is_struct(_ts) ? _ts.name : _ed.selected_tileset_id));
        draw_text(292, 254, "File Name: " + _ed.tile_pending_png_name);
        draw_text(292, 282, "New Tile Slot: Tile #" + string(_total_tiles + 1) + " (Existing " + string(_total_tiles) + " tiles preserved)");
        
        // Draw 64x64 and 32x32 preview boxes
        draw_set_color(make_color_rgb(12, 16, 32));
        draw_rectangle(292, 320, 388, 416, false);
        draw_set_color(_pal.accent_gold);
        draw_rectangle(292, 320, 388, 416, true);
        
        var _pspr = core_assets_load_cached_png(_ed.tile_pending_png_rel, 1);
        if (_pspr >= 0 && sprite_exists(_pspr)) {
            var _pw = max(1, sprite_get_width(_pspr));
            var _ph = max(1, sprite_get_height(_pspr));
            draw_sprite_ext(_pspr, 0, 308, 336, 64 / _pw, 64 / _ph, 0, c_white, 1.0);
            draw_sprite_ext(_pspr, 0, 416, 352, 32 / _pw, 32 / _ph, 0, c_white, 1.0);
        }
        draw_set_color(_pal.text_secondary);
        draw_text(468, 356, "2x Preview (64x64) & 1x Grid Size (32x32)");
        
        if (render_ui_button(292, 476, 600, 526, "Confirm & Add Tile", true, true)) {
            editor_tiles_confirm_singular_import();
        }
        if (render_ui_button(624, 476, 860, 526, "Cancel", false, true)) {
            _ed.tile_pending_png_rel = "";
            _ed.tile_pending_png_name = "";
            _ed.tile_confirm_mode = 0;
        }
    } else if (_ed.tile_confirm_mode == 2) {
        // 16.B: Confirm Delete Individual Tile
        var _tlabel = core_assets_get_tile_label(_ed.selected_tileset_id, _ed.selected_tile_index);
        draw_set_color(_pal.accent_red);
        draw_text(292, 194, "DELETE SELECTED TILE FROM TILESET?");
        draw_set_color(_pal.text_primary);
        draw_text(292, 232, "Tile to Delete: " + _tlabel);
        draw_text(292, 262, "From Tileset: " + (is_struct(_ts) ? _ts.name : _ed.selected_tileset_id));
        
        core_assets_draw_tile(_ed.selected_tileset_id, _ed.selected_tile_index, 292, 302, 64);
        draw_set_color(_pal.text_secondary);
        draw_text(376, 314, "Remaining tiles will stay accessible and all map layer");
        draw_text(376, 342, "tile indices will be updated automatically.");
        
        if (render_ui_button(292, 476, 600, 526, "Confirm Delete Tile", false, true)) {
            editor_tiles_execute_delete_selected_tile();
        }
        if (render_ui_button(624, 476, 860, 526, "Cancel", true, true)) {
            _ed.tile_confirm_mode = 0;
        }
    } else if (_ed.tile_confirm_mode == 3) {
        // 16.C: Confirm Delete Entire Tileset with Map Usage Warning
        var _ts_label = is_struct(_ts) ? (_ts.name + " [" + _ts.id + "]") : _ed.selected_tileset_id;
        var _used_maps = editor_tiles_get_maps_using_tileset(_ed.selected_tileset_id);
        
        draw_set_color(_pal.accent_red);
        draw_text(292, 194, "DELETE ENTIRE TILESET?");
        draw_set_color(_pal.text_primary);
        draw_text(292, 230, "Tileset to Delete: " + _ts_label);
        
        if (array_length(_used_maps) > 0) {
            draw_set_color(_pal.accent_gold);
            draw_text(292, 270, "WARNING: This tileset is currently used by " + string(array_length(_used_maps)) + " map(s):");
            var _mlist_str = "";
            for (var u = 0; u < min(3, array_length(_used_maps)); u++) {
                _mlist_str += (u > 0 ? ", " : "") + _used_maps[u];
            }
            draw_set_color(_pal.text_primary);
            draw_text(292, 300, render_fit_text("• " + _mlist_str, 690));
            draw_set_color(_pal.text_secondary);
            draw_text(292, 336, "If you delete this tileset, those maps will be safely reassigned to");
            draw_text(292, 364, "the fallback tileset so no maps break or crash.");
        } else {
            draw_set_color(_pal.accent_green);
            draw_text(292, 280, "This tileset is not currently assigned to any maps.");
        }
        
        if (render_ui_button(292, 476, 616, 526, "Confirm Delete Tileset", false, true)) {
            editor_tiles_execute_delete_current_tileset();
        }
        if (render_ui_button(636, 476, 860, 526, "Cancel", true, true)) {
            _ed.tile_confirm_mode = 0;
        }
    }
}
