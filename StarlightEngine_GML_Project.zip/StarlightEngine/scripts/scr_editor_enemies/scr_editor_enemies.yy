{
  "$GMScript": "v1",
  "%Name": "scr_editor_enemies",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_editor_enemies",
  "parent": {
    "name": "Editor",
    "path": "folders/Engine/Editor.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}