/// @description ST★RLIGHT ENGINE - Enemy Editor & Enemy Database Manager
/// Configures enemy definitions, independent Overworld & Battle custom sprites, 6 AI behaviors, stats, and rewards.

function editor_enemies_ensure_default() {
    if (is_undefined(global.project)) return;
    if (!is_array(global.project.enemies) || array_length(global.project.enemies) == 0) {
        global.project.enemies = [
            sys_enemy_create_default("enemy_stardust_mite", "Stardust Mite")
        ];
    }
}

function editor_enemies_place_at(_map, _gx, _gy) {
    if (!is_struct(_map)) return;
    if (editor_enemies_inspect_at(_map, _gx, _gy)) return;
    
    editor_enemies_ensure_default();
    var _edef = global.project.enemies[clamp(global.editor.selected_enemy_def_idx, 0, array_length(global.project.enemies) - 1)];
    
    var _inst = {
        id: "map_en_" + string(array_length(_map.enemies) + 1) + "_" + string(_gx) + "_" + string(_gy),
        enemy_id: _edef.id,
        grid_x: _gx,
        grid_y: _gy,
        ai_override: -1,
        defeat_var: "",
        condition_var: "",
        condition_val: true
    };
    array_push(_map.enemies, _inst);
    global.project_dirty = true;
    core_log_toast("Placed Enemy: " + _edef.name);
}

function editor_enemies_remove_at(_map, _gx, _gy) {
    if (!is_struct(_map) || !is_array(_map.enemies)) return;
    for (var i = array_length(_map.enemies) - 1; i >= 0; i--) {
        if (_map.enemies[i].grid_x == _gx && _map.enemies[i].grid_y == _gy) {
            array_delete(_map.enemies, i, 1);
            global.project_dirty = true;
            core_log_toast("Removed map enemy.");
            return;
        }
    }
}

function editor_enemies_inspect_at(_map, _gx, _gy) {
    if (!is_struct(_map) || !is_array(_map.enemies)) return false;
    for (var i = 0; i < array_length(_map.enemies); i++) {
        var _e = _map.enemies[i];
        if (_e.grid_x == _gx && _e.grid_y == _gy) {
            global.editor.inspect_enemy_inst = _e;
            editor_enemies_ensure_default();
            for (var d = 0; d < array_length(global.project.enemies); d++) {
                if (global.project.enemies[d].id == _e.enemy_id) {
                    global.editor.selected_enemy_def_idx = d;
                    break;
                }
            }
            global.editor.active_modal = EDITOR_MODAL.ENEMY_INSPECTOR;
            input_consume_all();
            return true;
        }
    }
    return false;
}

function editor_enemies_draw_inspector_modal(_map) {
    var _ed = global.editor;
    var _pal = global.palette;
    editor_enemies_ensure_default();
    
    var _list = global.project.enemies;
    _ed.selected_enemy_def_idx = clamp(_ed.selected_enemy_def_idx, 0, array_length(_list) - 1);
    var _edef = _list[_ed.selected_enemy_def_idx];
    if (!variable_struct_exists(_edef, "sprite_id") || _edef.sprite_id == "") _edef.sprite_id = "spr_enemy_default";
    if (!variable_struct_exists(_edef, "battle_sprite_id") || _edef.battle_sprite_id == "") _edef.battle_sprite_id = "spr_enemy_default";
    if (!variable_struct_exists(_edef, "overworld_scale")) _edef.overworld_scale = 1.0;
    if (!variable_struct_exists(_edef, "battle_scale")) _edef.battle_scale = 1.0;
    _edef.overworld_scale = sys_sprite_clamp_scale(_edef.overworld_scale);
    _edef.battle_scale = sys_sprite_clamp_scale(_edef.battle_scale);
    
    render_window_frame(84, 32, 1196, 688, "ENEMY DATABASE & SPRITE / BATTLE CONFIGURATION — " + _edef.name + " [" + _edef.id + "]", _pal.accent_magenta);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    // Top Enemy Selector Bar
    if (render_ui_button(108, 74, 238, 110, "< Prev Enemy", false, array_length(_list) > 1)) {
        input_end_text_edit();
        _ed.selected_enemy_def_idx = (_ed.selected_enemy_def_idx + array_length(_list) - 1) mod array_length(_list);
        return;
    }
    if (render_ui_button(246, 74, 376, 110, "Next Enemy >", false, array_length(_list) > 1)) {
        input_end_text_edit();
        _ed.selected_enemy_def_idx = (_ed.selected_enemy_def_idx + 1) mod array_length(_list);
        return;
    }
    if (render_ui_button(386, 74, 586, 110, "+ Create Enemy Type", false, true)) {
        input_end_text_edit();
        var _nid = "enemy_0" + string(array_length(_list) + 1);
        array_push(_list, sys_enemy_create_default(_nid, "New Enemy " + string(array_length(_list) + 1)));
        _ed.selected_enemy_def_idx = array_length(_list) - 1;
        global.project_dirty = true;
        return;
    }
    if (render_ui_button(596, 74, 756, 110, "Delete Enemy", false, array_length(_list) > 1)) {
        input_end_text_edit();
        array_delete(_list, _ed.selected_enemy_def_idx, 1);
        _ed.selected_enemy_def_idx = 0;
        global.project_dirty = true;
        return;
    }
    
    // =========================================================================
    // LEFT COLUMN: Custom ID, Name, Independent Overworld & Battle Sprites, & AI
    // =========================================================================
    draw_set_color(_pal.accent_gold);
    draw_text(108, 120, "Custom Enemy ID:");
    render_ui_custom_id_field("en_custom_id", "enemy", _edef, 108, 144, 274, 176);
    
    draw_set_color(_pal.accent_gold);
    draw_text(284, 120, "Enemy Name:");
    _edef.name = render_ui_text_field("en_name", 284, 144, 464, 176, _edef.name, 40);
    
    // 1. Independent Overworld Enemy Sprite & Scale Panel
    draw_set_color(_pal.panel_alt);
    draw_rectangle(108, 186, 464, 286, false);
    draw_set_color(_pal.border_inner);
    draw_rectangle(108, 186, 464, 286, true);
    
    var _ow_fps = core_assets_get_anim_fps(_edef.sprite_id, "Walking", DIR_FACING.DOWN);
    var _ow_frame = global.engine.frame_counter * (_ow_fps / 60.0);
    core_assets_draw_scaled_preview_box(116, 194, 168, 246, _edef.sprite_id, "Walking", _ow_frame, DIR_FACING.DOWN, make_color_rgb(235, 76, 96), _edef.overworld_scale, _pal.accent_cyan);
    
    draw_set_color(_pal.accent_cyan);
    draw_text(176, 192, "1.OW Spr:");
    _edef.sprite_id = render_ui_text_field("en_spr", 256, 188, 456, 216, _edef.sprite_id, 36);
    
    draw_set_color(_pal.accent_gold);
    draw_text(176, 224, "OW Scale:");
    var _new_ow_sc = render_ui_number_field("en_ow_scale", 256, 218, 344, 248, _edef.overworld_scale, 0.1, 8.0, true);
    if (_new_ow_sc != _edef.overworld_scale) {
        _edef.overworld_scale = sys_sprite_clamp_scale(_new_ow_sc);
        global.project_dirty = true;
    }
    if (render_ui_button(352, 218, 456, 248, "1.0x Reset", (_edef.overworld_scale == 1.0), true)) {
        _edef.overworld_scale = 1.0;
        global.project_dirty = true;
    }
    
    if (render_ui_button(116, 252, 246, 280, "+ Import OW PNG", false, true)) {
        input_end_text_edit();
        if (_edef.sprite_id == "" || _edef.sprite_id == "spr_enemy_default" || _edef.sprite_id == _edef.battle_sprite_id) {
            _edef.sprite_id = "spr_ow_" + _edef.id;
        }
        editor_sprites_import_entity_png(_edef.sprite_id, _edef.name + " (Overworld)", "enemy", 1);
        return;
    }
    if (render_ui_button(252, 252, 384, 280, "OW Anim/4-Dir...", false, true)) {
        input_end_text_edit();
        if (_edef.sprite_id == "" || _edef.sprite_id == "spr_enemy_default" || _edef.sprite_id == _edef.battle_sprite_id) {
            _edef.sprite_id = "spr_ow_" + _edef.id;
        }
        editor_sprites_open_for_id(_edef.sprite_id);
        return;
    }
    if (render_ui_button(390, 252, 456, 280, "Reset", false, true)) {
        input_end_text_edit();
        if (_edef.sprite_id != _edef.battle_sprite_id) {
            editor_sprites_clear_entity_custom_png(_edef.sprite_id);
        }
        _edef.sprite_id = "spr_enemy_default";
        _edef.overworld_scale = 1.0;
        global.project_dirty = true;
        return;
    }
    
    // 2. Independent Battle Enemy Sprite & Scale Panel
    draw_set_color(_pal.panel_alt);
    draw_rectangle(108, 294, 464, 394, false);
    draw_set_color(_pal.border_inner);
    draw_rectangle(108, 294, 464, 394, true);
    
    var _btl_fps = core_assets_get_anim_fps(_edef.battle_sprite_id, "Idle", DIR_FACING.DOWN);
    var _btl_frame = global.engine.frame_counter * (_btl_fps / 60.0);
    core_assets_draw_scaled_preview_box(116, 302, 168, 354, _edef.battle_sprite_id, "Idle", _btl_frame, DIR_FACING.DOWN, make_color_rgb(235, 76, 96), _edef.battle_scale, _pal.accent_magenta);
    
    draw_set_color(_pal.accent_magenta);
    draw_text(176, 300, "2.Btl Spr:");
    _edef.battle_sprite_id = render_ui_text_field("en_bspr", 256, 296, 456, 324, _edef.battle_sprite_id, 36);
    
    draw_set_color(_pal.accent_gold);
    draw_text(176, 332, "Btl Scale:");
    var _new_btl_sc = render_ui_number_field("en_btl_scale", 256, 326, 344, 356, _edef.battle_scale, 0.1, 8.0, true);
    if (_new_btl_sc != _edef.battle_scale) {
        _edef.battle_scale = sys_sprite_clamp_scale(_new_btl_sc);
        global.project_dirty = true;
    }
    if (render_ui_button(352, 326, 456, 356, "1.0x Reset", (_edef.battle_scale == 1.0), true)) {
        _edef.battle_scale = 1.0;
        global.project_dirty = true;
    }
    
    if (render_ui_button(116, 360, 246, 388, "+ Import Btl PNG", false, true)) {
        input_end_text_edit();
        if (_edef.battle_sprite_id == "" || _edef.battle_sprite_id == "spr_enemy_default" || _edef.battle_sprite_id == _edef.sprite_id) {
            _edef.battle_sprite_id = "spr_btl_" + _edef.id;
        }
        editor_sprites_import_entity_png(_edef.battle_sprite_id, _edef.name + " (Battle)", "enemy", 1);
        return;
    }
    if (render_ui_button(252, 360, 384, 388, "Btl Frames/FPS...", false, true)) {
        input_end_text_edit();
        if (_edef.battle_sprite_id == "" || _edef.battle_sprite_id == "spr_enemy_default" || _edef.battle_sprite_id == _edef.sprite_id) {
            _edef.battle_sprite_id = "spr_btl_" + _edef.id;
        }
        editor_sprites_open_for_id(_edef.battle_sprite_id);
        return;
    }
    if (render_ui_button(390, 360, 456, 388, "Reset", false, true)) {
        input_end_text_edit();
        if (_edef.battle_sprite_id != _edef.sprite_id) {
            editor_sprites_clear_entity_custom_png(_edef.battle_sprite_id);
        }
        _edef.battle_sprite_id = "spr_enemy_default";
        _edef.battle_scale = 1.0;
        global.project_dirty = true;
        return;
    }
    
    // Overworld AI Behavior & Editable AI Numbers
    draw_set_color(_pal.accent_cyan);
    draw_text(108, 404, "OVERWORLD AI BEHAVIOR (6 Modes):");
    var _ai_names = [
        "1. Chase Player",
        "2. Run Away From Player",
        "3. Ignore Player",
        "4. Stop When Player Nearby",
        "5. Stay Still",
        "6. Wander Within Radius"
    ];
    if (render_ui_button(108, 428, 464, 462, _ai_names[clamp(_edef.ai_behavior, 0, 5)], false, true)) {
        _edef.ai_behavior = (_edef.ai_behavior + 1) mod 6;
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.text_secondary);
    draw_text(108, 474, "Detect Rad:");
    _edef.detection_radius = render_ui_number_field("en_num_det", 108, 498, 220, 530, _edef.detection_radius, 0, 1000, false);
    
    draw_set_color(_pal.text_secondary);
    draw_text(230, 474, "Speed:");
    _edef.move_speed = render_ui_number_field("en_num_spd_ai", 230, 498, 336, 530, _edef.move_speed, 0.1, 12.0, true);
    
    draw_set_color(_pal.text_secondary);
    draw_text(346, 474, "Wander Rad:");
    _edef.wander_radius = render_ui_number_field("en_num_wand", 346, 498, 464, 530, _edef.wander_radius, 0, 1000, false);
    
    draw_set_color(_pal.accent_cyan);
    draw_text(108, 544, "DEFEAT & RESPAWN BEHAVIOR:");
    var _def_names = [
        "Disappears Permanently",
        "Respawns On Map Re-Entry",
        "Respawns After " + string(_edef.respawn_seconds) + " Seconds"
    ];
    if (render_ui_button(108, 568, 464, 604, _def_names[clamp(_edef.defeat_mode, 0, 2)], false, true)) {
        _edef.defeat_mode = (_edef.defeat_mode + 1) mod 3;
        global.project_dirty = true;
    }
    
    // =========================================================================
    // RIGHT COLUMN: Editable Numeric Combat Statistics, Weaknesses, & Rewards
    // =========================================================================
    draw_set_color(_pal.accent_gold);
    draw_text(496, 120, "COMBAT STATISTICS (Click & Type Number):");
    
    draw_set_color(_pal.text_secondary);
    draw_text(496, 148, "Max HP:");
    _edef.max_hp = render_ui_number_field("en_num_hp", 496, 172, 646, 206, _edef.max_hp, 1, 99999, false);
    
    draw_set_color(_pal.text_secondary);
    draw_text(664, 148, "Attack:");
    _edef.attack = render_ui_number_field("en_num_atk", 664, 172, 814, 206, _edef.attack, 1, 9999, false);
    
    draw_set_color(_pal.text_secondary);
    draw_text(832, 148, "Defense:");
    _edef.defense = render_ui_number_field("en_num_def", 832, 172, 982, 206, _edef.defense, 0, 9999, false);
    
    draw_set_color(_pal.text_secondary);
    draw_text(1000, 148, "Speed:");
    _edef.speed = render_ui_number_field("en_num_spd", 1000, 172, 1164, 206, _edef.speed, 1, 9999, false);
    
    draw_set_color(_pal.accent_cyan);
    draw_text(496, 228, "WEAKNESS & RESISTANCE:");
    draw_set_color(_pal.text_primary);
    draw_text(496, 258, "Weakness:");
    _edef.weakness = render_ui_text_field("en_weak", 600, 252, 814, 286, _edef.weakness, 24);
    draw_text(832, 258, "Resistance:");
    _edef.resistance = render_ui_text_field("en_res", 948, 252, 1164, 286, _edef.resistance, 24);
    
    draw_set_color(_pal.accent_gold);
    draw_text(496, 308, "VICTORY REWARDS (Editable EXP, Gold, Item ID, & Event ID):");
    
    draw_set_color(_pal.text_secondary);
    draw_text(496, 336, "EXP Reward:");
    _edef.reward_exp = render_ui_number_field("en_num_rexp", 496, 360, 710, 396, _edef.reward_exp, 0, 99999, false);
    
    draw_set_color(_pal.text_secondary);
    draw_text(736, 336, "Gold Reward ($):");
    _edef.reward_gold = render_ui_number_field("en_num_rgld", 736, 360, 956, 396, _edef.reward_gold, 0, 99999, false);
    
    draw_set_color(_pal.text_primary);
    draw_text(496, 414, "Drop Item ID:");
    _edef.reward_item_id = render_ui_text_field("en_rew_item", 496, 438, 814, 474, _edef.reward_item_id, 40);
    draw_text(832, 414, "Post-Defeat Event ID:");
    _edef.reward_event_id = render_ui_text_field("en_rew_ev", 832, 438, 1164, 474, _edef.reward_event_id, 40);
    
    // Side-by-Side Battle Theater Preview Box on Right Column (Reflects Battle Scale)
    draw_set_color(_pal.accent_magenta);
    draw_text(496, 492, "BATTLE APPEARANCE PREVIEW (" + string(_edef.battle_scale) + "x Battle Scale):");
    core_assets_draw_scaled_preview_box(496, 518, 604, 626, _edef.battle_sprite_id, "Idle", _btl_frame, DIR_FACING.DOWN, make_color_rgb(235, 76, 96), _edef.battle_scale, _pal.accent_magenta);
    
    // If inspecting a specific map enemy instance, allow setting its Defeat Variable
    if (is_struct(_ed.inspect_enemy_inst)) {
        draw_set_color(_pal.accent_cyan);
        draw_text(624, 518, "Map Instance Defeat Variable:");
        _ed.inspect_enemy_inst.defeat_var = render_ui_text_field("en_inst_dvar", 624, 544, 936, 580, _ed.inspect_enemy_inst.defeat_var, 40);
    } else {
        draw_set_color(_pal.text_secondary);
        draw_text(624, 536, "Overworld Sprite and Battle Sprite are stored");
        draw_text(624, 562, "as separate assets so changing one never");
        draw_text(624, 588, "overwrites the other.");
    }
    
    if (render_ui_button(956, 628, 1164, 668, "Done (Esc)", true, true)) {
        input_end_text_edit();
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}
