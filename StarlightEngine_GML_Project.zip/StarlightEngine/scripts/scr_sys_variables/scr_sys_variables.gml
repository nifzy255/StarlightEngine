/// @description ST★RLIGHT ENGINE - Variable System
/// Manages persistent Boolean, Integer, Decimal, and String project variables during gameplay.

function sys_variable_create_definition(_id, _name, _type, _default_val, _description) {
    return {
        id: _id,
        name: _name,
        type: is_undefined(_type) ? VAR_TYPE.BOOLEAN : _type,
        default_value: is_undefined(_default_val) ? false : _default_val,
        description: is_undefined(_description) ? "" : _description
    };
}

function sys_variable_init_runtime() {
    global.runtime.variables = {};
    if (is_undefined(global.project) || !variable_struct_exists(global.project, "variables")) return;
    
    var _defs = global.project.variables;
    for (var i = 0; i < array_length(_defs); i++) {
        var _d = _defs[i];
        variable_struct_set(global.runtime.variables, _d.id, _d.default_value);
        if (_d.name != "" && _d.name != _d.id) {
            variable_struct_set(global.runtime.variables, _d.name, _d.default_value);
        }
    }
}

function sys_variable_resolve_def(_key) {
    if (is_undefined(global.project) || !variable_struct_exists(global.project, "variables")) return undefined;
    var _defs = global.project.variables;
    for (var i = 0; i < array_length(_defs); i++) {
        if (_defs[i].id == _key || _defs[i].name == _key) {
            return _defs[i];
        }
    }
    return undefined;
}

function sys_variable_get(_key) {
    if (_key == "" || is_undefined(_key)) return false;
    if (is_struct(global.runtime) && is_struct(global.runtime.variables)) {
        if (variable_struct_exists(global.runtime.variables, _key)) {
            return variable_struct_get(global.runtime.variables, _key);
        }
    }
    var _def = sys_variable_resolve_def(_key);
    if (is_struct(_def)) {
        return _def.default_value;
    }
    return false;
}

function sys_variable_set(_key, _value) {
    if (_key == "" || is_undefined(_key)) return;
    var _def = sys_variable_resolve_def(_key);
    var _coerced = _value;
    
    if (is_struct(_def)) {
        switch (_def.type) {
            case VAR_TYPE.BOOLEAN:
                if (is_string(_value)) {
                    _coerced = (string_upper(_value) == "TRUE" || _value == "1");
                } else {
                    _coerced = bool(_value);
                }
                break;
            case VAR_TYPE.INTEGER:
                _coerced = round(real(_value));
                break;
            case VAR_TYPE.DECIMAL:
                _coerced = real(_value);
                break;
            case VAR_TYPE.STRING:
                _coerced = string(_value);
                break;
        }
        variable_struct_set(global.runtime.variables, _def.id, _coerced);
        variable_struct_set(global.runtime.variables, _def.name, _coerced);
    } else {
        variable_struct_set(global.runtime.variables, _key, _coerced);
    }
}

function sys_variable_toggle(_key) {
    var _cur = sys_variable_get(_key);
    var _next = !bool(_cur);
    sys_variable_set(_key, _next);
    return _next;
}

function sys_variable_check(_key, _expected_value) {
    if (_key == "" || is_undefined(_key)) return true;
    var _actual = sys_variable_get(_key);
    var _target = is_undefined(_expected_value) ? true : _expected_value;
    
    if (is_bool(_actual) || is_bool(_target)) {
        var _b_act = is_string(_actual) ? (string_upper(_actual) == "TRUE" || _actual == "1") : bool(_actual);
        var _b_tgt = is_string(_target) ? (string_upper(_target) == "TRUE" || _target == "1") : bool(_target);
        return (_b_act == _b_tgt);
    }
    return (string(_actual) == string(_target));
}
