/// @description ST★RLIGHT ENGINE - Experience & Leveling System
/// Calculates per-character EXP curves, handles level-up stat increases, and unlocks level-gated abilities.

function sys_leveling_exp_for_next_level(_char_inst) {
    if (!is_struct(_char_inst)) return 100;
    var _lvl = max(1, _char_inst.level);
    var _base = variable_struct_exists(_char_inst, "exp_base") ? max(10, _char_inst.exp_base) : 30;
    var _curve = variable_struct_exists(_char_inst, "exp_curve_factor") ? max(1.05, _char_inst.exp_curve_factor) : 1.35;
    return round(_base * power(_lvl, _curve));
}

function sys_leveling_add_exp(_char_inst, _amount) {
    if (!is_struct(_char_inst) || _amount <= 0) return [];
    _char_inst.exp += round(_amount);
    
    var _messages = [];
    var _safety = 0;
    while (_char_inst.exp >= sys_leveling_exp_for_next_level(_char_inst) && _safety < 99) {
        _safety++;
        _char_inst.exp -= sys_leveling_exp_for_next_level(_char_inst);
        _char_inst.level += 1;
        
        var _hp_gain = max(1, _char_inst.growth_hp);
        var _mp_gain = max(0, _char_inst.growth_mp);
        var _atk_gain = max(0, _char_inst.growth_attack);
        var _def_gain = max(0, _char_inst.growth_defense);
        var _spd_gain = max(0, _char_inst.growth_speed);
        
        _char_inst.max_hp += _hp_gain;
        _char_inst.current_hp = _char_inst.max_hp;
        _char_inst.rolling_hp = _char_inst.max_hp;
        _char_inst.max_mp += _mp_gain;
        _char_inst.current_mp = _char_inst.max_mp;
        _char_inst.attack += _atk_gain;
        _char_inst.defense += _def_gain;
        _char_inst.speed += _spd_gain;
        
        var _msg = _char_inst.name + " reached Level " + string(_char_inst.level) + "! (HP +" + string(_hp_gain) + ", ATK +" + string(_atk_gain) + ")";
        array_push(_messages, _msg);
        
        // Check if any abilities unlocked at this exact level
        if (variable_struct_exists(_char_inst, "abilities") && is_array(_char_inst.abilities)) {
            for (var i = 0; i < array_length(_char_inst.abilities); i++) {
                var _ab = _char_inst.abilities[i];
                if (variable_struct_exists(_ab, "level_req") && _ab.level_req == _char_inst.level) {
                    array_push(_messages, _char_inst.name + " learned " + _ab.name + "!");
                }
            }
        }
    }
    if (array_length(_messages) > 0) {
        core_audio_play_default_sound("gameplay_level_up");
    }
    return _messages;
}

function sys_leveling_set_exp(_char_inst, _amount) {
    if (!is_struct(_char_inst)) return;
    _char_inst.exp = max(0, round(_amount));
}
