/// @description ST★RLIGHT ENGINE - Dynamic Asset, Tileset Manifest & Directional Sprite Management
/// Manages runtime PNG loading via sprite_add, per-tile & per-animation/direction assets, and 16-bit fallback rendering.

function core_assets_init() {
    global.assets = {
        sprite_cache: {},
        tileset_cache: {},
        missing_reported: {}
    };
}

function core_assets_clear_cache() {
    if (!variable_global_exists("assets") || !is_struct(global.assets)) return;
    
    var _skeys = variable_struct_get_names(global.assets.sprite_cache);
    for (var i = 0; i < array_length(_skeys); i++) {
        var _spr = variable_struct_get(global.assets.sprite_cache, _skeys[i]);
        if (_spr >= 0 && sprite_exists(_spr) && _spr != spr_pixel_fallback) {
            sprite_delete(_spr);
        }
    }
    
    var _tkeys = variable_struct_get_names(global.assets.tileset_cache);
    for (var j = 0; j < array_length(_tkeys); j++) {
        var _tspr = variable_struct_get(global.assets.tileset_cache, _tkeys[j]);
        if (_tspr >= 0 && sprite_exists(_tspr) && _tspr != spr_pixel_fallback) {
            sprite_delete(_tspr);
        }
    }
    
    global.assets.sprite_cache = {};
    global.assets.tileset_cache = {};
    global.assets.missing_reported = {};
}

function core_assets_find_sprite_def(_sprite_id) {
    if (is_undefined(global.project) || !variable_struct_exists(global.project, "sprites")) return undefined;
    var _list = global.project.sprites;
    for (var i = 0; i < array_length(_list); i++) {
        if (_list[i].id == _sprite_id || _list[i].name == _sprite_id) {
            sys_sprite_normalize_animations(_list[i]);
            return _list[i];
        }
    }
    return undefined;
}

/// @function core_assets_load_cached_png(_rel_path, _frames)
/// @description Loads and caches a PNG file from the project folder with the specified horizontal frame count.
function core_assets_load_cached_png(_rel_path, _frames) {
    if (is_undefined(_rel_path) || _rel_path == "") return -1;
    var _fcount = max(1, round(_frames));
    var _cache_key = _rel_path + "__f" + string(_fcount);
    if (variable_struct_exists(global.assets.sprite_cache, _cache_key)) {
        var _cached = variable_struct_get(global.assets.sprite_cache, _cache_key);
        if (_cached >= 0 && sprite_exists(_cached)) return _cached;
    }
    
    var _full = (global.project_path != "") ? (global.project_path + _rel_path) : _rel_path;
    if (!file_exists(_full)) _full = _rel_path;
    if (!file_exists(_full)) {
        if (!variable_struct_exists(global.assets.missing_reported, _rel_path)) {
            variable_struct_set(global.assets.missing_reported, _rel_path, true);
            core_log_warning("core_assets", "Missing PNG asset '" + _rel_path + "'. Using fallback.");
        }
        return -1;
    }
    
    var _spr = sprite_add(_full, _fcount, false, false, 0, 0);
    if (_spr >= 0 && sprite_exists(_spr)) {
        variable_struct_set(global.assets.sprite_cache, _cache_key, _spr);
        return _spr;
    }
    return -1;
}

function core_assets_get_gms_sprite(_sprite_id) {
    var _def = core_assets_find_sprite_def(_sprite_id);
    if (!is_struct(_def)) return -1;
    var _rel = variable_struct_exists(_def, "file_path") ? _def.file_path : "";
    if (_rel == "") return -1;
    var _frames = variable_struct_exists(_def, "frame_count") ? max(1, _def.frame_count) : 1;
    return core_assets_load_cached_png(_rel, _frames);
}

/// @function core_assets_resolve_render_clip(_def, _anim_state, _facing)
/// @description Resolves the animation clip and fallback asset source for a given state and facing direction.
function core_assets_resolve_render_clip(_def, _anim_state, _facing) {
    if (!is_struct(_def)) return undefined;
    sys_sprite_normalize_animations(_def);
    
    var _dir_name = sys_sprite_get_dir_name(_facing);
    var _skey = variable_struct_exists(_def.animations, _anim_state) ? _anim_state : "Idle";
    var _st = variable_struct_get(_def.animations, _skey);
    var _primary_clip = (_st.directional && is_struct(_st.directions) && variable_struct_exists(_st.directions, _dir_name))
        ? variable_struct_get(_st.directions, _dir_name)
        : _st;
    
    // If primary directional clip has its own custom PNGs, use it directly
    if (sys_sprite_clip_has_custom_assets(_primary_clip)) {
        return { metrics_clip: _primary_clip, asset_clip: _primary_clip };
    }
    // Fallback 1: Same animation state, "Down" direction or state-level clip
    if (is_struct(_st.directions) && variable_struct_exists(_st.directions, "Down") && sys_sprite_clip_has_custom_assets(_st.directions.Down)) {
        return { metrics_clip: _primary_clip, asset_clip: _st.directions.Down };
    }
    if (sys_sprite_clip_has_custom_assets(_st)) {
        return { metrics_clip: _primary_clip, asset_clip: _st };
    }
    // Fallback 2: "Idle" state for the same direction, or "Idle" Down
    var _idle = _def.animations.Idle;
    if (is_struct(_idle.directions) && variable_struct_exists(_idle.directions, _dir_name)) {
        var _idle_dir = variable_struct_get(_idle.directions, _dir_name);
        if (sys_sprite_clip_has_custom_assets(_idle_dir)) {
            return { metrics_clip: _primary_clip, asset_clip: _idle_dir };
        }
    }
    if (is_struct(_idle.directions) && variable_struct_exists(_idle.directions, "Down") && sys_sprite_clip_has_custom_assets(_idle.directions.Down)) {
        return { metrics_clip: _primary_clip, asset_clip: _idle.directions.Down };
    }
    return { metrics_clip: _primary_clip, asset_clip: _primary_clip };
}

function core_assets_get_anim_fps(_sprite_id, _anim_state, _facing) {
    var _def = core_assets_find_sprite_def(_sprite_id);
    if (!is_struct(_def)) {
        if (_anim_state == "Running") return 12;
        if (_anim_state == "Walking") return 8;
        return 4;
    }
    var _res = core_assets_resolve_render_clip(_def, _anim_state, _facing);
    if (is_struct(_res) && is_struct(_res.metrics_clip)) {
        return clamp(_res.metrics_clip.fps, 1, 60);
    }
    return 6;
}

function core_assets_get_anim_frame_count(_sprite_id, _anim_state, _facing) {
    var _def = core_assets_find_sprite_def(_sprite_id);
    if (!is_struct(_def)) return (_anim_state == "Idle") ? 1 : 4;
    var _res = core_assets_resolve_render_clip(_def, _anim_state, _facing);
    if (is_struct(_res) && is_struct(_res.metrics_clip)) {
        return max(1, _res.metrics_clip.frame_count);
    }
    return 4;
}

/// @function core_assets_get_sprite_scale(_sprite_id)
/// @description Returns the base scale configured on the sprite asset definition (defaults to 1.0).
function core_assets_get_sprite_scale(_sprite_id) {
    var _def = core_assets_find_sprite_def(_sprite_id);
    if (is_struct(_def) && variable_struct_exists(_def, "scale")) {
        return sys_sprite_clamp_scale(_def.scale);
    }
    return 1.0;
}

/// @function core_assets_get_sprite_dimensions(_sprite_id, _anim_state, _facing)
/// @description Returns the original imported pixel dimensions { orig_w, orig_h } of a sprite or 32x32 for procedural sprites.
function core_assets_get_sprite_dimensions(_sprite_id, _anim_state, _facing) {
    var _def = core_assets_find_sprite_def(_sprite_id);
    if (is_struct(_def)) {
        var _res = core_assets_resolve_render_clip(_def, _anim_state, _facing);
        if (is_struct(_res) && is_struct(_res.asset_clip)) {
            var _ac = _res.asset_clip;
            if (is_array(_ac.frame_files) && array_length(_ac.frame_files) > 0 && _ac.frame_files[0] != "") {
                var _fspr = core_assets_load_cached_png(_ac.frame_files[0], 1);
                if (_fspr >= 0 && sprite_exists(_fspr)) {
                    return { orig_w: max(1, sprite_get_width(_fspr)), orig_h: max(1, sprite_get_height(_fspr)) };
                }
            }
            if (variable_struct_exists(_ac, "file_path") && _ac.file_path != "") {
                var _sspr = core_assets_load_cached_png(_ac.file_path, max(1, _ac.frame_count));
                if (_sspr >= 0 && sprite_exists(_sspr)) {
                    return { orig_w: max(1, sprite_get_width(_sspr)), orig_h: max(1, sprite_get_height(_sspr)) };
                }
            }
        }
        var _gspr = core_assets_get_gms_sprite(_sprite_id);
        if (_gspr >= 0 && sprite_exists(_gspr)) {
            return { orig_w: max(1, sprite_get_width(_gspr)), orig_h: max(1, sprite_get_height(_gspr)) };
        }
    }
    return { orig_w: 32, orig_h: 32 };
}

/// @function core_assets_draw_entity_sprite_scaled(_sprite_id, _anim_state, _frame, _x, _y, _base_w, _base_h, _facing, _tint_override, _entity_scale, _anchor_center)
/// @description Draws an entity sprite with uniform scaling (combining entity scale and sprite asset scale) anchored cleanly.
function core_assets_draw_entity_sprite_scaled(_sprite_id, _anim_state, _frame, _x, _y, _base_w, _base_h, _facing, _tint_override, _entity_scale, _anchor_center) {
    var _asset_sc = core_assets_get_sprite_scale(_sprite_id);
    var _ent_sc = sys_sprite_clamp_scale(_entity_scale);
    var _tot_sc = clamp(_asset_sc * _ent_sc, 0.1, 8.0);
    var _dw = max(4, _base_w * _tot_sc);
    var _dh = max(4, _base_h * _tot_sc);
    var _dx = _x + (_base_w - _dw) * 0.5;
    var _dy = _anchor_center ? (_y + (_base_h - _dh) * 0.5) : (_y + (_base_h - _dh));
    core_assets_draw_entity_sprite(_sprite_id, _anim_state, _frame, _dx, _dy, _dw, _dh, _facing, _tint_override);
}

/// @function core_assets_draw_scaled_preview_box(_x1, _y1, _x2, _y2, _sprite_id, _anim_state, _frame, _facing, _tint_override, _entity_scale, _border_col)
/// @description Draws an editor preview box showing a 1.0x reference outline alongside the live scaled sprite.
function core_assets_draw_scaled_preview_box(_x1, _y1, _x2, _y2, _sprite_id, _anim_state, _frame, _facing, _tint_override, _entity_scale, _border_col) {
    draw_set_color(make_color_rgb(10, 14, 28));
    draw_rectangle(_x1, _y1, _x2, _y2, false);
    draw_set_color(_border_col);
    draw_rectangle(_x1, _y1, _x2, _y2, true);
    
    var _box_w = (_x2 - _x1) - 8;
    var _box_h = (_y2 - _y1) - 8;
    var _cx = mean(_x1, _x2);
    var _cy = mean(_y1, _y2);
    
    // 1.0x baseline reference box (50% of preview container so up to 2.0x fits without clipping)
    var _ref_w = max(16, round(_box_w * 0.52));
    var _ref_h = max(16, round(_box_h * 0.52));
    draw_set_color(make_color_rgb(44, 58, 96));
    draw_rectangle(_cx - (_ref_w * 0.5), _cy - (_ref_h * 0.5), _cx + (_ref_w * 0.5), _cy + (_ref_h * 0.5), true);
    
    var _asset_sc = core_assets_get_sprite_scale(_sprite_id);
    var _ent_sc = sys_sprite_clamp_scale(_entity_scale);
    var _tot_sc = clamp(_asset_sc * _ent_sc, 0.1, 8.0);
    
    var _draw_w = clamp(round(_ref_w * _tot_sc), 6, _box_w);
    var _draw_h = clamp(round(_ref_h * _tot_sc), 6, _box_h);
    var _dx = _cx - (_draw_w * 0.5);
    var _dy = _cy - (_draw_h * 0.5);
    core_assets_draw_entity_sprite(_sprite_id, _anim_state, _frame, _dx, _dy, _draw_w, _draw_h, _facing, _tint_override);
}

/// @function core_assets_draw_entity_sprite(_sprite_id, _anim_state, _frame, _x, _y, _w, _h, _facing, _tint_override)
/// @description Draws a character/NPC/enemy/object sprite honoring directional animations, per-frame PNGs, strip PNGs, and 4-way fallback.
function core_assets_draw_entity_sprite(_sprite_id, _anim_state, _frame, _x, _y, _w, _h, _facing, _tint_override) {
    var _def = core_assets_find_sprite_def(_sprite_id);
    var _fcount = 4;
    var _loop = true;
    var _asset_clip = undefined;
    
    if (is_struct(_def)) {
        var _res = core_assets_resolve_render_clip(_def, _anim_state, _facing);
        if (is_struct(_res)) {
            _fcount = max(1, _res.metrics_clip.frame_count);
            _loop = _res.metrics_clip.loop;
            _asset_clip = _res.asset_clip;
        }
    }
    
    var _raw_f = max(0, floor(_frame));
    var _f_idx = (_fcount <= 1) ? 0 : (_loop ? (_raw_f mod _fcount) : min(_fcount - 1, _raw_f));
    
    // 1. Check per-frame PNG file on resolved clip
    if (is_struct(_asset_clip) && is_array(_asset_clip.frame_files) && array_length(_asset_clip.frame_files) > 0) {
        var _ff_idx = clamp(_f_idx, 0, array_length(_asset_clip.frame_files) - 1);
        var _ff_path = _asset_clip.frame_files[_ff_idx];
        if (_ff_path != "") {
            var _fspr = core_assets_load_cached_png(_ff_path, 1);
            if (_fspr >= 0 && sprite_exists(_fspr)) {
                var _fsw = max(1, sprite_get_width(_fspr));
                var _fsh = max(1, sprite_get_height(_fspr));
                draw_sprite_ext(_fspr, 0, _x, _y, _w / _fsw, _h / _fsh, 0, c_white, 1.0);
                return;
            }
        }
    }
    
    // 2. Check animation/direction strip PNG file on resolved clip
    if (is_struct(_asset_clip) && variable_struct_exists(_asset_clip, "file_path") && _asset_clip.file_path != "") {
        var _strip_count = max(1, _asset_clip.frame_count);
        var _sspr = core_assets_load_cached_png(_asset_clip.file_path, _strip_count);
        if (_sspr >= 0 && sprite_exists(_sspr)) {
            var _ssw = max(1, sprite_get_width(_sspr));
            var _ssh = max(1, sprite_get_height(_sspr));
            var _sub = _f_idx mod max(1, sprite_get_number(_sspr));
            draw_sprite_ext(_sspr, _sub, _x, _y, _w / _ssw, _h / _ssh, 0, c_white, 1.0);
            return;
        }
    }
    
    // 3. Check top-level sprite sheet PNG fallback
    var _gms_spr = core_assets_get_gms_sprite(_sprite_id);
    if (_gms_spr >= 0 && sprite_exists(_gms_spr)) {
        var _sw = max(1, sprite_get_width(_gms_spr));
        var _sh = max(1, sprite_get_height(_gms_spr));
        var _subimg = _f_idx mod max(1, sprite_get_number(_gms_spr));
        draw_sprite_ext(_gms_spr, _subimg, _x, _y, _w / _sw, _h / _sh, 0, c_white, 1.0);
        return;
    }
    
    // 4. Procedural 16-bit EarthBound-style 4-directional pixel representation
    var _primary = is_undefined(_tint_override) ? make_color_rgb(92, 198, 245) : _tint_override;
    var _secondary = make_color_rgb(255, 214, 74);
    var _archetype = "character";
    
    if (is_struct(_def)) {
        if (variable_struct_exists(_def, "primary_color")) _primary = _def.primary_color;
        if (variable_struct_exists(_def, "secondary_color")) _secondary = _def.secondary_color;
        if (variable_struct_exists(_def, "archetype")) _archetype = _def.archetype;
    } else if (string_pos("enemy", _sprite_id) > 0) {
        _archetype = "enemy";
        _primary = make_color_rgb(235, 76, 96);
    } else if (string_pos("chest", _sprite_id) > 0) {
        _archetype = "chest";
        _primary = make_color_rgb(196, 128, 52);
    } else if (string_pos("sign", _sprite_id) > 0) {
        _archetype = "sign";
        _primary = make_color_rgb(168, 124, 74);
    }
    
    var _is_moving = (_anim_state == "Walking" || _anim_state == "Running");
    var _step_phase = (_fcount > 1) ? (_f_idx mod 2) : 0;
    var _bob = (_is_moving && _step_phase == 1) ? ((_anim_state == "Running") ? -3 : -2) : 0;
    if (_anim_state == "TakingDamage" && (_f_idx mod 2 == 0)) _bob = -2;
    
    var _x1 = _x + 2;
    var _y1 = _y + 2 + _bob;
    var _x2 = _x + _w - 2;
    var _y2 = _y + _h - 2 + _bob;
    
    if (_archetype == "chest") {
        draw_set_color(c_black);
        draw_rectangle(_x1 - 1, _y1 + 4, _x2 + 1, _y2 + 1, false);
        draw_set_color(_primary);
        draw_rectangle(_x1, _y1 + 5, _x2, _y2, false);
        draw_set_color(_secondary);
        draw_rectangle(_x1, _y1 + 11, _x2, _y1 + 14, false);
        draw_rectangle(mean(_x1, _x2) - 2, _y1 + 10, mean(_x1, _x2) + 2, _y1 + 16, false);
        return;
    }
    
    if (_archetype == "sign") {
        var _mx = mean(_x1, _x2);
        draw_set_color(make_color_rgb(110, 74, 40));
        draw_rectangle(_mx - 2, mean(_y1, _y2), _mx + 2, _y2, false);
        draw_set_color(_primary);
        draw_rectangle(_x1 + 2, _y1 + 2, _x2 - 2, mean(_y1, _y2) + 2, false);
        draw_set_color(c_black);
        draw_rectangle(_x1 + 2, _y1 + 2, _x2 - 2, mean(_y1, _y2) + 2, true);
        return;
    }
    
    if (_archetype == "enemy") {
        draw_set_color(c_black);
        draw_rectangle(_x1 - 1, _y1 - 1, _x2 + 1, _y2 + 1, false);
        draw_set_color(_primary);
        draw_rectangle(_x1 + 1, _y1 + 2, _x2 - 1, _y2 - 2, false);
        draw_set_color(_secondary);
        draw_rectangle(_x1 + 4, _y1 + 6, _x1 + 7, _y1 + 9, false);
        draw_rectangle(_x2 - 7, _y1 + 6, _x2 - 4, _y1 + 9, false);
        return;
    }
    
    // Shadow
    draw_set_alpha(0.35);
    draw_set_color(c_black);
    draw_ellipse(_x1 + 2, _y + _h - 6, _x2 - 2, _y + _h - 1, false);
    draw_set_alpha(1.0);
    
    if (_anim_state == "Defeated") {
        // Fallen pose
        draw_set_color(_primary);
        draw_rectangle(_x1 + 2, _y + _h - 12, _x2 - 2, _y + _h - 4, false);
        draw_set_color(_secondary);
        draw_rectangle(_x1 + 4, _y + _h - 14, _x1 + 12, _y + _h - 8, false);
        return;
    }
    
    // Head & directional cap
    var _head_h = floor((_y2 - _y1) * 0.45);
    var _dir_shift = (_facing == DIR_FACING.LEFT) ? -2 : ((_facing == DIR_FACING.RIGHT) ? 2 : 0);
    draw_set_color(make_color_rgb(255, 220, 185));
    draw_rectangle(_x1 + 4 + _dir_shift, _y1 + 4, _x2 - 4 + _dir_shift, _y1 + _head_h, false);
    
    // Cap visor shows facing direction (Up/Down/Left/Right)
    draw_set_color(_secondary);
    var _brim_l = (_facing == DIR_FACING.LEFT) ? (_x1 + 1) : (_x1 + 3);
    var _brim_r = (_facing == DIR_FACING.RIGHT) ? (_x2 - 1) : (_x2 - 3);
    draw_rectangle(_brim_l, _y1 + 1, _brim_r, _y1 + 6, false);
    if (_facing == DIR_FACING.UP) {
        // Back of cap covers upper head
        draw_rectangle(_x1 + 4, _y1 + 4, _x2 - 4, _y1 + _head_h - 2, false);
    }
    
    // Body / Striped shirt
    draw_set_color((_anim_state == "TakingDamage" && (_f_idx mod 2 == 0)) ? c_white : _primary);
    draw_rectangle(_x1 + 3, _y1 + _head_h + 1, _x2 - 3, _y2 - 5, false);
    draw_set_color(_secondary);
    var _stripe_y = round(mean(_y1 + _head_h + 1, _y2 - 5));
    draw_rectangle(_x1 + 3, _stripe_y - 1, _x2 - 3, _stripe_y + 1, false);
    
    // Directional Feet / Stride Animation across frames
    draw_set_color(make_color_rgb(50, 44, 68));
    var _stride = (_is_moving && _fcount > 1) ? (((_f_idx mod 2) == 0) ? -2 : 2) : 0;
    draw_rectangle(_x1 + 4, _y2 - 4 + _stride, mean(_x1, _x2) - 1, _y2, false);
    draw_rectangle(mean(_x1, _x2) + 1, _y2 - 4 - _stride, _x2 - 4, _y2, false);
    
    // Directional Eyes (Down, Left, Right)
    draw_set_color(c_black);
    if (_facing == DIR_FACING.DOWN) {
        draw_rectangle(_x1 + 6, _y1 + 8, _x1 + 7, _y1 + 10, false);
        draw_rectangle(_x2 - 7, _y1 + 8, _x2 - 6, _y1 + 10, false);
    } else if (_facing == DIR_FACING.LEFT) {
        draw_rectangle(_x1 + 4, _y1 + 8, _x1 + 6, _y1 + 10, false);
    } else if (_facing == DIR_FACING.RIGHT) {
        draw_rectangle(_x2 - 6, _y1 + 8, _x2 - 4, _y1 + 10, false);
    }
    
    // Attacking effect indicator
    if (_anim_state == "Attacking") {
        draw_set_color(_secondary);
        var _ax = mean(_x1, _x2) + (_dir_shift * 4);
        var _ay = mean(_y1, _y2) + ((_facing == DIR_FACING.DOWN) ? 8 : ((_facing == DIR_FACING.UP) ? -8 : 0));
        draw_circle(_ax, _ay, 3 + (_f_idx mod 3), false);
    }
}

// ============================================================================
// TILESET MANIFEST & SINGULAR TILE / SHEET TILE RENDERING
// ============================================================================

function core_assets_default_tile_names() {
    return [
        "Lush Grass", "Dirt Path", "Stone Pavement", "Deep Water",
        "Wood Planks", "Brick Wall", "Cavern Floor", "Cavern Rock Wall",
        "Starlight Crystal", "Flowers / Shrub", "Tree Canopy (FG)", "Warp Portal Pad",
        "Sand Dunes", "Snow Field", "Ice Floor", "Lava Magma",
        "Starlit Carpet", "Checkerboard", "Iron Grate", "Bookshelf Wall",
        "Roof Shingles", "Wooden Fence", "Ancient Ruins", "Neon Cyber Grid"
    ];
}

function core_assets_find_tileset(_tileset_id) {
    if (is_undefined(global.project) || !variable_struct_exists(global.project, "tilesets") || !is_array(global.project.tilesets)) {
        return undefined;
    }
    for (var i = 0; i < array_length(global.project.tilesets); i++) {
        if (global.project.tilesets[i].id == _tileset_id) {
            return global.project.tilesets[i];
        }
    }
    if (array_length(global.project.tilesets) > 0) {
        return global.project.tilesets[0];
    }
    return undefined;
}

/// @function core_assets_ensure_tileset_entries(_ts)
/// @description Ensures a tileset struct has an ordered `tile_entries` array supporting base tiles + singular imported PNG tiles + deletions.
function core_assets_ensure_tileset_entries(_ts) {
    if (!is_struct(_ts)) return [];
    if (variable_struct_exists(_ts, "tile_entries") && is_array(_ts.tile_entries) && array_length(_ts.tile_entries) > 0) {
        _ts.tile_count = array_length(_ts.tile_entries);
        return _ts.tile_entries;
    }
    
    var _entries = [];
    var _has_sheet = variable_struct_exists(_ts, "file_path") && _ts.file_path != "";
    if (_has_sheet) {
        var _cell = variable_struct_exists(_ts, "tile_size") ? max(8, _ts.tile_size) : 32;
        var _sheet_count = variable_struct_exists(_ts, "tile_count") ? max(1, _ts.tile_count) : 1;
        var _spr = core_assets_load_cached_png(_ts.file_path, 1);
        if (_spr >= 0 && sprite_exists(_spr)) {
            var _eff_cell = min(_cell, min(sprite_get_width(_spr), sprite_get_height(_spr)));
            _eff_cell = max(1, _eff_cell);
            var _cols = max(1, sprite_get_width(_spr) div _eff_cell);
            var _rows = max(1, sprite_get_height(_spr) div _eff_cell);
            _sheet_count = max(1, _cols * _rows);
        }
        for (var c = 0; c < _sheet_count; c++) {
            array_push(_entries, {
                kind: "sheet_cell",
                cell_index: c,
                name: "Sheet Tile #" + string(c + 1),
                file_path: ""
            });
        }
    } else {
        var _names = core_assets_default_tile_names();
        var _pcount = variable_struct_exists(_ts, "tile_count") ? max(1, _ts.tile_count) : 24;
        if (_pcount < 24 && _ts.id == "ts_default_16bit") _pcount = 24;
        for (var p = 1; p <= _pcount; p++) {
            var _nm = (p <= array_length(_names)) ? _names[p - 1] : ("Procedural #" + string(p));
            array_push(_entries, {
                kind: "procedural",
                proc_id: p,
                name: _nm,
                file_path: ""
            });
        }
    }
    
    // Merge any legacy custom_tiles array if present
    if (variable_struct_exists(_ts, "custom_tiles") && is_array(_ts.custom_tiles)) {
        for (var k = 0; k < array_length(_ts.custom_tiles); k++) {
            var _ct = _ts.custom_tiles[k];
            if (is_struct(_ct) && variable_struct_exists(_ct, "file_path") && _ct.file_path != "") {
                array_push(_entries, {
                    kind: "custom_png",
                    name: variable_struct_exists(_ct, "name") ? _ct.name : filename_name(_ct.file_path),
                    file_path: _ct.file_path
                });
            }
        }
    }
    
    _ts.tile_entries = _entries;
    _ts.tile_count = array_length(_entries);
    return _ts.tile_entries;
}

function core_assets_get_tileset_tile_count(_tileset_id) {
    var _ts = core_assets_find_tileset(_tileset_id);
    if (!is_struct(_ts)) return 24;
    var _entries = core_assets_ensure_tileset_entries(_ts);
    return max(1, array_length(_entries));
}

function core_assets_get_tile_label(_tileset_id, _tile_idx) {
    var _ts = core_assets_find_tileset(_tileset_id);
    if (!is_struct(_ts)) return "Tile #" + string(_tile_idx);
    var _entries = core_assets_ensure_tileset_entries(_ts);
    if (_tile_idx >= 1 && _tile_idx <= array_length(_entries)) {
        var _ent = _entries[_tile_idx - 1];
        if (variable_struct_exists(_ent, "name") && _ent.name != "") {
            return string(_tile_idx) + ": " + _ent.name;
        }
    }
    return "Tile #" + string(_tile_idx);
}

/// @function core_assets_draw_procedural_tile(_proc_id, _x, _y, _size)
/// @description Draws one of the 24 built-in 16-bit procedural tiles.
function core_assets_draw_procedural_tile(_proc_id, _x, _y, _size) {
    var _base_col = make_color_rgb(48, 128, 68);
    var _detail_col = make_color_rgb(64, 156, 84);
    switch (_proc_id) {
        case 1: _base_col = make_color_rgb(46, 132, 72); _detail_col = make_color_rgb(72, 168, 96); break;
        case 2: _base_col = make_color_rgb(164, 122, 78); _detail_col = make_color_rgb(188, 146, 98); break;
        case 3: _base_col = make_color_rgb(112, 118, 138); _detail_col = make_color_rgb(144, 152, 174); break;
        case 4: _base_col = make_color_rgb(36, 92, 176); _detail_col = make_color_rgb(76, 144, 224); break;
        case 5: _base_col = make_color_rgb(128, 84, 48); _detail_col = make_color_rgb(98, 62, 34); break;
        case 6: _base_col = make_color_rgb(148, 64, 64); _detail_col = make_color_rgb(186, 96, 88); break;
        case 7: _base_col = make_color_rgb(42, 38, 64); _detail_col = make_color_rgb(62, 56, 92); break;
        case 8: _base_col = make_color_rgb(26, 22, 44); _detail_col = make_color_rgb(52, 44, 78); break;
        case 9: _base_col = make_color_rgb(48, 42, 82); _detail_col = make_color_rgb(92, 225, 230); break;
        case 10: _base_col = make_color_rgb(38, 112, 60); _detail_col = make_color_rgb(255, 214, 74); break;
        case 11: _base_col = make_color_rgb(28, 92, 52); _detail_col = make_color_rgb(48, 132, 74); break;
        case 12: _base_col = make_color_rgb(78, 42, 128); _detail_col = make_color_rgb(235, 94, 168); break;
        case 13: _base_col = make_color_rgb(212, 178, 106); _detail_col = make_color_rgb(236, 206, 138); break;
        case 14: _base_col = make_color_rgb(218, 232, 248); _detail_col = make_color_rgb(180, 204, 236); break;
        case 15: _base_col = make_color_rgb(112, 188, 236); _detail_col = make_color_rgb(176, 228, 255); break;
        case 16: _base_col = make_color_rgb(198, 48, 32); _detail_col = make_color_rgb(255, 168, 42); break;
        case 17: _base_col = make_color_rgb(124, 28, 68); _detail_col = make_color_rgb(255, 214, 74); break;
        case 18: _base_col = make_color_rgb(220, 224, 236); _detail_col = make_color_rgb(42, 48, 72); break;
        case 19: _base_col = make_color_rgb(68, 76, 92); _detail_col = make_color_rgb(118, 128, 148); break;
        case 20: _base_col = make_color_rgb(96, 58, 34); _detail_col = make_color_rgb(214, 84, 92); break;
        case 21: _base_col = make_color_rgb(52, 84, 142); _detail_col = make_color_rgb(78, 114, 178); break;
        case 22: _base_col = make_color_rgb(154, 112, 64); _detail_col = make_color_rgb(204, 162, 104); break;
        case 23: _base_col = make_color_rgb(92, 104, 88); _detail_col = make_color_rgb(132, 148, 124); break;
        case 24: _base_col = make_color_rgb(18, 22, 48); _detail_col = make_color_rgb(92, 225, 230); break;
        default:
            _base_col = make_color_rgb(60 + ((_proc_id * 37) mod 140), 70 + ((_proc_id * 53) mod 130), 110);
            _detail_col = make_color_rgb(180, 190, 220);
            break;
    }
    draw_set_color(_base_col);
    draw_rectangle(_x, _y, _x + _size - 1, _y + _size - 1, false);
    draw_set_color(_detail_col);
    var _q = max(2, _size div 4);
    draw_rectangle(_x + _q, _y + _q, _x + _q * 2, _y + _q * 2, false);
    draw_rectangle(_x + _size - _q * 2, _y + _size - _q * 2, _x + _size - _q, _y + _size - _q, false);
}

/// @function core_assets_draw_tile(_tileset_id, _tile_idx, _x, _y, _size)
/// @description Draws a tile from a tileset (supporting singular imported PNG tiles, PNG sheet cells, and built-in procedural tiles).
function core_assets_draw_tile(_tileset_id, _tile_idx, _x, _y, _size) {
    if (_tile_idx <= 0) return;
    
    var _ts = core_assets_find_tileset(_tileset_id);
    if (is_struct(_ts)) {
        var _entries = core_assets_ensure_tileset_entries(_ts);
        if (_tile_idx >= 1 && _tile_idx <= array_length(_entries)) {
            var _ent = _entries[_tile_idx - 1];
            if (_ent.kind == "custom_png" && variable_struct_exists(_ent, "file_path") && _ent.file_path != "") {
                var _cspr = core_assets_load_cached_png(_ent.file_path, 1);
                if (_cspr >= 0 && sprite_exists(_cspr)) {
                    var _csw = max(1, sprite_get_width(_cspr));
                    var _csh = max(1, sprite_get_height(_cspr));
                    draw_sprite_ext(_cspr, 0, _x, _y, _size / _csw, _size / _csh, 0, c_white, 1.0);
                    return;
                }
            } else if (_ent.kind == "sheet_cell" && variable_struct_exists(_ts, "file_path") && _ts.file_path != "") {
                var _sspr = core_assets_load_cached_png(_ts.file_path, 1);
                if (_sspr >= 0 && sprite_exists(_sspr)) {
                    var _cell = variable_struct_exists(_ts, "tile_size") ? max(8, _ts.tile_size) : 32;
                    var _eff_cell = max(1, min(_cell, min(sprite_get_width(_sspr), sprite_get_height(_sspr))));
                    var _cols = max(1, sprite_get_width(_sspr) div _eff_cell);
                    var _cidx = variable_struct_exists(_ent, "cell_index") ? max(0, _ent.cell_index) : (_tile_idx - 1);
                    var _src_x = (_cidx mod _cols) * _eff_cell;
                    var _src_y = (_cidx div _cols) * _eff_cell;
                    var _scale = _size / _eff_cell;
                    draw_sprite_part_ext(_sspr, 0, _src_x, _src_y, _eff_cell, _eff_cell, _x, _y, _scale, _scale, c_white, 1.0);
                    return;
                }
            } else if (_ent.kind == "procedural") {
                var _pid = variable_struct_exists(_ent, "proc_id") ? _ent.proc_id : _tile_idx;
                core_assets_draw_procedural_tile(_pid, _x, _y, _size);
                return;
            }
        }
    }
    
    core_assets_draw_procedural_tile(_tile_idx, _x, _y, _size);
}
