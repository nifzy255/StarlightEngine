/// @description ST★RLIGHT ENGINE - Audio Management & Project-Wide Default UI/Gameplay Sound System
/// Handles dynamic OGG music streams, 23 configurable project-wide UI/Gameplay/Battle sound events,
/// synthesized 16-bit fallback tones, anti-spam/anti-overlap rules, and per-sound volume control.

function core_audio_get_default_sound_catalog() {
    return [
        // Group 0: Dialogue (4)
        { key: "dialogue_advance", group: "Dialogue", label: "Text Advance", default_vol: 0.80, freq1: 660, freq2: 880, dur_ms: 45 },
        { key: "dialogue_typing",  group: "Dialogue", label: "Text Typing",  default_vol: 0.45, freq1: 540, freq2: 580, dur_ms: 18 },
        { key: "dialogue_open",    group: "Dialogue", label: "Dialogue Open", default_vol: 0.75, freq1: 440, freq2: 660, dur_ms: 60 },
        { key: "dialogue_close",   group: "Dialogue", label: "Dialogue Close", default_vol: 0.70, freq1: 660, freq2: 440, dur_ms: 55 },
        
        // Group 1: Menu Navigation (3)
        { key: "menu_move",        group: "Menu Navigation", label: "Menu Move", default_vol: 0.70, freq1: 587, freq2: 620, dur_ms: 26 },
        { key: "menu_confirm",     group: "Menu Navigation", label: "Confirm",   default_vol: 0.85, freq1: 523, freq2: 784, dur_ms: 60 },
        { key: "menu_cancel",      group: "Menu Navigation", label: "Cancel",    default_vol: 0.80, freq1: 494, freq2: 330, dur_ms: 65 },
        
        // Group 2: Choices (3)
        { key: "choice_yes",       group: "Choices", label: "Yes",         default_vol: 0.90, freq1: 523, freq2: 1046, dur_ms: 90 },
        { key: "choice_no",        group: "Choices", label: "No",          default_vol: 0.85, freq1: 392, freq2: 262,  dur_ms: 85 },
        { key: "choice_move",      group: "Choices", label: "Choice Move", default_vol: 0.70, freq1: 698, freq2: 740,  dur_ms: 26 },
        
        // Group 3: Gameplay (5)
        { key: "gameplay_interact",    group: "Gameplay", label: "Interaction", default_vol: 0.80, freq1: 440, freq2: 659, dur_ms: 50 },
        { key: "gameplay_item_obtain", group: "Gameplay", label: "Item Obtain", default_vol: 0.95, freq1: 587, freq2: 1174, dur_ms: 160 },
        { key: "gameplay_level_up",    group: "Gameplay", label: "Level Up",    default_vol: 1.00, freq1: 523, freq2: 1318, dur_ms: 220 },
        { key: "gameplay_save",        group: "Gameplay", label: "Save",        default_vol: 0.90, freq1: 587, freq2: 880,  dur_ms: 130 },
        { key: "gameplay_load",        group: "Gameplay", label: "Load",        default_vol: 0.90, freq1: 494, freq2: 987,  dur_ms: 130 },
        
        // Group 4: Battle (8)
        { key: "battle_start",          group: "Battle", label: "Battle Start",   default_vol: 0.95, freq1: 220, freq2: 660,  dur_ms: 170 },
        { key: "battle_attack",         group: "Battle", label: "Attack",         default_vol: 0.85, freq1: 420, freq2: 180,  dur_ms: 75 },
        { key: "battle_damage",         group: "Battle", label: "Damage",         default_vol: 0.90, freq1: 210, freq2: 95,   dur_ms: 90 },
        { key: "battle_crit",           group: "Battle", label: "Critical Hit",   default_vol: 1.00, freq1: 880, freq2: 1760, dur_ms: 150 },
        { key: "battle_heal",           group: "Battle", label: "Healing",        default_vol: 0.90, freq1: 523, freq2: 987,  dur_ms: 150 },
        { key: "battle_enemy_defeated", group: "Battle", label: "Enemy Defeated", default_vol: 0.90, freq1: 440, freq2: 110,  dur_ms: 140 },
        { key: "battle_victory",        group: "Battle", label: "Victory",        default_vol: 1.00, freq1: 523, freq2: 1046, dur_ms: 220 },
        { key: "battle_defeat",         group: "Battle", label: "Defeat",         default_vol: 0.95, freq1: 330, freq2: 165,  dur_ms: 240 }
    ];
}

function core_audio_create_default_ui_sounds_struct() {
    var _cat = core_audio_get_default_sound_catalog();
    var _s = {};
    for (var i = 0; i < array_length(_cat); i++) {
        var _c = _cat[i];
        variable_struct_set(_s, _c.key, {
            enabled: true,
            volume: _c.default_vol,
            audio_id: "",
            file_path: "",
            name: "Built-In Default"
        });
    }
    return _s;
}

function core_audio_normalize_project_sounds(_proj) {
    if (!is_struct(_proj)) return;
    if (!variable_struct_exists(_proj, "default_sounds") || !is_struct(_proj.default_sounds)) {
        _proj.default_sounds = core_audio_create_default_ui_sounds_struct();
        return;
    }
    var _cat = core_audio_get_default_sound_catalog();
    for (var i = 0; i < array_length(_cat); i++) {
        var _c = _cat[i];
        if (!variable_struct_exists(_proj.default_sounds, _c.key) || !is_struct(variable_struct_get(_proj.default_sounds, _c.key))) {
            variable_struct_set(_proj.default_sounds, _c.key, {
                enabled: true,
                volume: _c.default_vol,
                audio_id: "",
                file_path: "",
                name: "Built-In Default"
            });
        } else {
            var _ent = variable_struct_get(_proj.default_sounds, _c.key);
            if (!variable_struct_exists(_ent, "enabled")) _ent.enabled = true;
            if (!variable_struct_exists(_ent, "volume")) _ent.volume = _c.default_vol;
            _ent.volume = clamp(real(_ent.volume), 0.0, 1.0);
            if (!variable_struct_exists(_ent, "audio_id")) _ent.audio_id = "";
            if (!variable_struct_exists(_ent, "file_path")) _ent.file_path = "";
            if (!variable_struct_exists(_ent, "name") || _ent.name == "") {
                _ent.name = (_ent.file_path != "") ? filename_name(_ent.file_path) : "Built-In Default";
            }
        }
    }
}

/// @function core_audio_generate_synth_tone(_freq1, _freq2, _dur_ms)
/// @description Generates a 16-bit retro chiptune sound buffer for built-in default fallback cues.
function core_audio_generate_synth_tone(_freq1, _freq2, _dur_ms) {
    try {
        var _rate = 22050;
        var _samples = max(64, round((_dur_ms / 1000.0) * _rate));
        var _byte_len = _samples * 2;
        var _buf = buffer_create(_byte_len, buffer_fixed, 2);
        var _phase = 0.0;
        for (var i = 0; i < _samples; i++) {
            var _t = i / _samples;
            var _freq = (_t < 0.5) ? _freq1 : _freq2;
            _phase += (_freq / _rate);
            if (_phase >= 1.0) _phase -= 1.0;
            // Warm 16-bit square/triangle hybrid wave with smooth envelope
            var _sq = (_phase < 0.5) ? 1.0 : -1.0;
            var _env = (1.0 - (_t * 0.75));
            if (i < 48) _env *= (i / 48.0);
            var _val = round(_sq * _env * 9000);
            buffer_write(_buf, buffer_s16, clamp(_val, -32000, 32000));
        }
        var _snd = audio_create_buffer_sound(_buf, buffer_s16, _rate, 0, _byte_len, audio_mono);
        array_push(global.audio.synth_buffers, _buf);
        return _snd;
    } catch (_err) {
        return -1;
    }
}

function core_audio_init() {
    global.audio = {
        current_music_id: "",
        current_music_stream: -1,
        current_music_instance: -1,
        music_paused: false,
        music_loop: true,
        music_entry_volume: 1.0,
        stream_cache: {},
        fallback_sounds: {},
        synth_buffers: [],
        last_frame_by_key: {},
        last_generic_ui_frame: -999,
        last_generic_ui_inst: -1,
        last_specific_ui_frame: -999
    };
    
    // Build synthesized 16-bit default fallback sounds for all 23 categories
    var _cat = core_audio_get_default_sound_catalog();
    for (var i = 0; i < array_length(_cat); i++) {
        var _c = _cat[i];
        var _snd = core_audio_generate_synth_tone(_c.freq1, _c.freq2, _c.dur_ms);
        variable_struct_set(global.audio.fallback_sounds, _c.key, _snd);
    }
}

function core_audio_cleanup_streams() {
    if (!variable_global_exists("audio") || !is_struct(global.audio)) return;
    core_audio_stop_music();
    var _keys = variable_struct_get_names(global.audio.stream_cache);
    for (var i = 0; i < array_length(_keys); i++) {
        var _stream = variable_struct_get(global.audio.stream_cache, _keys[i]);
        if (_stream >= 0) {
            try {
                audio_destroy_stream(_stream);
            } catch (_e) {
                // Ignore stream cleanup warning
            }
        }
    }
    global.audio.stream_cache = {};
}

function core_audio_find_entry(_audio_id) {
    if (is_undefined(global.project) || !variable_struct_exists(global.project, "audio")) return undefined;
    var _list = global.project.audio;
    for (var i = 0; i < array_length(_list); i++) {
        if (_list[i].id == _audio_id || _list[i].name == _audio_id) {
            return _list[i];
        }
    }
    return undefined;
}

function core_audio_get_or_load_stream(_entry) {
    if (!is_struct(_entry)) return -1;
    var _id = _entry.id;
    if (variable_struct_exists(global.audio.stream_cache, _id)) {
        return variable_struct_get(global.audio.stream_cache, _id);
    }
    
    var _rel = variable_struct_exists(_entry, "file_path") ? _entry.file_path : "";
    if (_rel == "") return -1;
    
    var _full_path = global.project_path + _rel;
    if (!file_exists(_full_path)) {
        _full_path = _rel;
    }
    if (!file_exists(_full_path)) {
        core_log_warning("core_audio", "Missing OGG audio file for '" + _entry.name + "': " + string(_rel));
        return -1;
    }
    
    try {
        var _stream = audio_create_stream(_full_path);
        if (_stream >= 0) {
            variable_struct_set(global.audio.stream_cache, _id, _stream);
            return _stream;
        }
    } catch (_err) {
        core_log_warning("core_audio", "Could not decode OGG stream '" + _entry.name + "': " + string(_err));
    }
    return -1;
}

function core_audio_get_or_load_rel_stream(_cache_id, _rel_path) {
    if (_rel_path == "" || is_undefined(_rel_path)) return -1;
    if (variable_struct_exists(global.audio.stream_cache, _cache_id)) {
        return variable_struct_get(global.audio.stream_cache, _cache_id);
    }
    var _full = (global.project_path != "") ? (global.project_path + _rel_path) : _rel_path;
    if (!file_exists(_full)) _full = _rel_path;
    if (!file_exists(_full)) return -1;
    try {
        var _stream = audio_create_stream(_full);
        if (_stream >= 0) {
            variable_struct_set(global.audio.stream_cache, _cache_id, _stream);
            return _stream;
        }
    } catch (_err) {
        return -1;
    }
    return -1;
}

function core_audio_start_music(_audio_id, _loop) {
    if (_audio_id == "" || is_undefined(_audio_id)) return false;
    var _should_loop = is_undefined(_loop) ? true : _loop;
    
    if (global.audio.current_music_id == _audio_id && global.audio.current_music_instance != -1) {
        if (global.audio.music_paused) {
            core_audio_resume_music();
        }
        return true;
    }
    
    core_audio_stop_music();
    
    var _entry = core_audio_find_entry(_audio_id);
    if (is_undefined(_entry)) {
        global.audio.current_music_id = _audio_id;
        global.audio.music_paused = false;
        global.audio.music_loop = _should_loop;
        return false;
    }
    
    global.audio.current_music_id = _entry.id;
    global.audio.music_loop = variable_struct_exists(_entry, "loop") ? (_should_loop && _entry.loop) : _should_loop;
    global.audio.music_entry_volume = variable_struct_exists(_entry, "volume") ? _entry.volume : 1.0;
    global.audio.music_paused = false;
    
    var _stream = core_audio_get_or_load_stream(_entry);
    if (_stream >= 0) {
        var _inst = audio_play_sound(_stream, 10, global.audio.music_loop);
        var _gain = clamp(global.config.music_volume * global.audio.music_entry_volume, 0.0, 1.0);
        audio_sound_gain(_inst, _gain, 250);
        global.audio.current_music_stream = _stream;
        global.audio.current_music_instance = _inst;
        return true;
    }
    return false;
}

function core_audio_pause_music() {
    if (global.audio.current_music_instance != -1 && audio_is_playing(global.audio.current_music_instance)) {
        audio_pause_sound(global.audio.current_music_instance);
    }
    global.audio.music_paused = true;
}

function core_audio_resume_music() {
    if (global.audio.current_music_instance != -1) {
        audio_resume_sound(global.audio.current_music_instance);
    }
    global.audio.music_paused = false;
}

function core_audio_stop_music() {
    if (global.audio.current_music_instance != -1) {
        if (audio_is_playing(global.audio.current_music_instance)) {
            audio_stop_sound(global.audio.current_music_instance);
        }
    }
    global.audio.current_music_instance = -1;
    global.audio.current_music_id = "";
    global.audio.music_paused = false;
}

function core_audio_play_sfx(_audio_id) {
    if (_audio_id == "" || is_undefined(_audio_id)) return false;
    if (global.config.sfx_volume <= 0.001) return false;
    var _entry = core_audio_find_entry(_audio_id);
    if (is_undefined(_entry)) return false;
    
    var _stream = core_audio_get_or_load_stream(_entry);
    if (_stream >= 0) {
        var _inst = audio_play_sound(_stream, 20, false);
        var _vol = variable_struct_exists(_entry, "volume") ? _entry.volume : 1.0;
        audio_sound_gain(_inst, clamp(global.config.sfx_volume * _vol, 0.0, 1.0), 0);
        return true;
    }
    return false;
}

/// @function core_audio_play_default_sound(_event_key)
/// @description Triggers a configured project-wide default sound effect with anti-spam, anti-overlap, volume & fallback support.
function core_audio_play_default_sound(_event_key) {
    if (!variable_global_exists("audio") || !is_struct(global.audio)) return false;
    if (global.config.sfx_volume <= 0.001) return false;
    
    var _frame = variable_global_exists("engine") && is_struct(global.engine) ? global.engine.frame_counter : 0;
    
    // 1. Anti-Spam Cooldown Check (prevents rapid menu navigation or typewriter sound spam)
    var _min_gap = 1;
    if (_event_key == "menu_move" || _event_key == "choice_move") _min_gap = 4;
    else if (_event_key == "dialogue_typing") _min_gap = 3;
    
    if (variable_struct_exists(global.audio.last_frame_by_key, _event_key)) {
        var _prev_f = variable_struct_get(global.audio.last_frame_by_key, _event_key);
        if ((_frame - _prev_f) < _min_gap) {
            return false;
        }
    }
    
    // 2. Anti-Overlap Rule: Do not play generic Confirm/Cancel simultaneously with Yes/No or specific actions
    var _is_generic_ui = (_event_key == "menu_confirm" || _event_key == "menu_cancel");
    var _is_specific_override = (_event_key == "choice_yes" || _event_key == "choice_no" ||
                                 _event_key == "gameplay_save" || _event_key == "gameplay_load" ||
                                 _event_key == "dialogue_open" || _event_key == "dialogue_advance" ||
                                 _event_key == "dialogue_close");
    
    if (_is_generic_ui && global.audio.last_specific_ui_frame == _frame) {
        // A specific sound (e.g. Yes / No / Save / Load) already fired this frame; skip generic Confirm/Cancel
        return false;
    }
    if (_is_specific_override && global.audio.last_generic_ui_frame == _frame) {
        // Override and cancel the generic Confirm/Cancel that was queued earlier on this exact same frame
        if (global.audio.last_generic_ui_inst != -1) {
            try {
                audio_stop_sound(global.audio.last_generic_ui_inst);
            } catch (_e_stop) {}
            global.audio.last_generic_ui_inst = -1;
        }
    }
    
    // 3. Look up project sound configuration for _event_key
    var _enabled = true;
    var _ind_vol = 0.85;
    var _rel_path = "";
    var _aud_id = "";
    
    if (!is_undefined(global.project) && is_struct(global.project)) {
        core_audio_normalize_project_sounds(global.project);
        if (variable_struct_exists(global.project.default_sounds, _event_key)) {
            var _cfg = variable_struct_get(global.project.default_sounds, _event_key);
            _enabled = variable_struct_exists(_cfg, "enabled") ? bool(_cfg.enabled) : true;
            _ind_vol = variable_struct_exists(_cfg, "volume") ? clamp(real(_cfg.volume), 0.0, 1.0) : 0.85;
            _rel_path = variable_struct_exists(_cfg, "file_path") ? string(_cfg.file_path) : "";
            _aud_id = variable_struct_exists(_cfg, "audio_id") ? string(_cfg.audio_id) : "";
        }
    }
    
    if (!_enabled || _ind_vol <= 0.001) return false;
    var _final_gain = clamp(global.config.sfx_volume * _ind_vol, 0.0, 1.0);
    if (_final_gain <= 0.001) return false;
    
    variable_struct_set(global.audio.last_frame_by_key, _event_key, _frame);
    
    // 4. Play Custom OGG if assigned, otherwise Built-In Default Fallback
    var _played_inst = -1;
    if (_rel_path != "") {
        var _stream = core_audio_get_or_load_rel_stream("def_sfx__" + _event_key + "__" + _rel_path, _rel_path);
        if (_stream >= 0) {
            _played_inst = audio_play_sound(_stream, 20, false);
            audio_sound_gain(_played_inst, _final_gain, 0);
        }
    } else if (_aud_id != "") {
        var _ent = core_audio_find_entry(_aud_id);
        if (is_struct(_ent)) {
            var _estr = core_audio_get_or_load_stream(_ent);
            if (_estr >= 0) {
                _played_inst = audio_play_sound(_estr, 20, false);
                audio_sound_gain(_played_inst, _final_gain, 0);
            }
        }
    }
    
    // 5. Fallback to built-in synthesized 16-bit sound if no custom OGG played
    if (_played_inst == -1 && variable_struct_exists(global.audio.fallback_sounds, _event_key)) {
        var _fb_snd = variable_struct_get(global.audio.fallback_sounds, _event_key);
        if (_fb_snd >= 0) {
            try {
                _played_inst = audio_play_sound(_fb_snd, 20, false);
                audio_sound_gain(_played_inst, _final_gain, 0);
            } catch (_e_fb) {
                _played_inst = -1;
            }
        }
    }
    
    if (_played_inst != -1) {
        if (_is_generic_ui) {
            global.audio.last_generic_ui_frame = _frame;
            global.audio.last_generic_ui_inst = _played_inst;
        } else if (_is_specific_override) {
            global.audio.last_specific_ui_frame = _frame;
        }
        return true;
    }
    return false;
}

/// @function core_audio_preview_default_sound(_event_key)
/// @description Previews a default sound category in the Project Manager regardless of cooldown.
function core_audio_preview_default_sound(_event_key) {
    if (!variable_global_exists("audio") || !is_struct(global.audio)) return false;
    if (variable_struct_exists(global.audio.last_frame_by_key, _event_key)) {
        variable_struct_remove(global.audio.last_frame_by_key, _event_key);
    }
    var _was_enabled = true;
    if (!is_undefined(global.project) && is_struct(global.project)) {
        core_audio_normalize_project_sounds(global.project);
        if (variable_struct_exists(global.project.default_sounds, _event_key)) {
            var _c = variable_struct_get(global.project.default_sounds, _event_key);
            _was_enabled = _c.enabled;
            _c.enabled = true;
            var _res = core_audio_play_default_sound(_event_key);
            _c.enabled = _was_enabled;
            return _res;
        }
    }
    return core_audio_play_default_sound(_event_key);
}

function core_audio_play_sfx_ui(_ui_cue) {
    if (_ui_cue == "ui_move") {
        core_audio_play_default_sound("menu_move");
    } else if (_ui_cue == "ui_select") {
        core_audio_play_default_sound("menu_confirm");
    } else if (_ui_cue == "ui_cancel") {
        core_audio_play_default_sound("menu_cancel");
    } else {
        core_audio_play_default_sound(_ui_cue);
    }
}

function core_audio_sync_volumes() {
    if (global.audio.current_music_instance != -1 && audio_is_playing(global.audio.current_music_instance)) {
        var _gain = clamp(global.config.music_volume * global.audio.music_entry_volume, 0.0, 1.0);
        audio_sound_gain(global.audio.current_music_instance, _gain, 100);
    }
}
