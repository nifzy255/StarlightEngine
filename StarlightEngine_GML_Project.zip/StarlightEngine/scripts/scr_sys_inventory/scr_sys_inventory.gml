/// @description ST★RLIGHT ENGINE - Item & Inventory System
/// Manages item definitions, stack quantities, equipment slots, and field/battle consumable effects.

function sys_item_create_default(_id, _name, _category) {
    return {
        id: _id,
        name: _name,
        description: "A useful item found in the world.",
        icon_id: "",
        category: is_undefined(_category) ? ITEM_CATEGORY.HEALING : _category,
        price: 20,
        max_stack: 99,
        usable_field: true,
        usable_battle: true,
        target_type: "single_ally",
        hp_restore: 30,
        mp_restore: 0,
        revive: false,
        status_cure: "",
        status_inflict: "",
        bonus_attack: 0,
        bonus_defense: 0,
        bonus_speed: 0,
        trigger_event_id: "",
        event_commands: []
    };
}

function sys_item_find_def(_item_id_or_name) {
    if (is_undefined(global.project) || !variable_struct_exists(global.project, "items")) return undefined;
    var _items = global.project.items;
    for (var i = 0; i < array_length(_items); i++) {
        if (_items[i].id == _item_id_or_name || _items[i].name == _item_id_or_name) {
            return _items[i];
        }
    }
    return undefined;
}

function sys_inventory_get_quantity(_item_id_or_name) {
    var _def = sys_item_find_def(_item_id_or_name);
    var _target_id = is_struct(_def) ? _def.id : _item_id_or_name;
    var _inv = global.runtime.inventory;
    var _total = 0;
    for (var i = 0; i < array_length(_inv); i++) {
        if (_inv[i].item_id == _target_id || _inv[i].name == _item_id_or_name) {
            _total += _inv[i].quantity;
        }
    }
    return _total;
}

function sys_inventory_add_item(_item_id_or_name, _qty) {
    var _amount = is_undefined(_qty) ? 1 : max(1, round(_qty));
    var _def = sys_item_find_def(_item_id_or_name);
    if (is_undefined(_def)) {
        core_log_warning("Inventory", "Item definition not found: " + string(_item_id_or_name));
        return false;
    }
    
    var _max_stack = variable_struct_exists(_def, "max_stack") ? max(1, _def.max_stack) : 99;
    var _inv = global.runtime.inventory;
    
    for (var i = 0; i < array_length(_inv); i++) {
        if (_inv[i].item_id == _def.id && _inv[i].quantity < _max_stack) {
            var _space = _max_stack - _inv[i].quantity;
            var _to_add = min(_amount, _space);
            _inv[i].quantity += _to_add;
            _amount -= _to_add;
            if (_amount <= 0) break;
        }
    }
    
    while (_amount > 0) {
        var _chunk = min(_amount, _max_stack);
        array_push(_inv, {
            item_id: _def.id,
            name: _def.name,
            quantity: _chunk
        });
        _amount -= _chunk;
    }
    
    if (variable_global_exists("scene") && is_struct(global.scene) &&
        (global.scene.current == ENGINE_SCENE.RUNTIME_PLAY || global.scene.current == ENGINE_SCENE.RUNTIME_BATTLE)) {
        core_audio_play_default_sound("gameplay_item_obtain");
    }
    core_log_toast("Obtained: " + _def.name);
    return true;
}

function sys_inventory_remove_item(_item_id_or_name, _qty) {
    var _amount = is_undefined(_qty) ? 1 : max(1, round(_qty));
    var _def = sys_item_find_def(_item_id_or_name);
    var _target_id = is_struct(_def) ? _def.id : _item_id_or_name;
    var _inv = global.runtime.inventory;
    
    for (var i = array_length(_inv) - 1; i >= 0; i--) {
        if (_inv[i].item_id == _target_id || _inv[i].name == _item_id_or_name) {
            var _take = min(_amount, _inv[i].quantity);
            _inv[i].quantity -= _take;
            _amount -= _take;
            if (_inv[i].quantity <= 0) {
                array_delete(_inv, i, 1);
            }
            if (_amount <= 0) return true;
        }
    }
    return (_amount == 0);
}

/// @function sys_inventory_use_item(_item_id_or_name, _target_char, _in_battle)
/// @description Executes item effects (Heal HP/MP, Revive, Equip, or Custom Event) and consumes stack if applicable.
function sys_inventory_use_item(_item_id_or_name, _target_char, _in_battle) {
    var _def = sys_item_find_def(_item_id_or_name);
    if (is_undefined(_def)) return { used: false, message: "Unknown item." };
    
    if (sys_inventory_get_quantity(_def.id) <= 0) {
        return { used: false, message: "No " + _def.name + " remaining." };
    }
    
    // Equipment items (Weapons, Armor, Accessories)
    if (_def.category == ITEM_CATEGORY.WEAPON || _def.category == ITEM_CATEGORY.ARMOR || _def.category == ITEM_CATEGORY.ACCESSORY) {
        if (_in_battle) {
            return { used: false, message: "Cannot change equipment during battle." };
        }
        if (!is_struct(_target_char)) return { used: false, message: "No character selected." };
        
        var _slot = "weapon";
        if (_def.category == ITEM_CATEGORY.ARMOR) _slot = "armor";
        if (_def.category == ITEM_CATEGORY.ACCESSORY) _slot = "accessory";
        
        var _prev_item = variable_struct_get(_target_char.equipment, _slot);
        if (_prev_item != "") {
            sys_inventory_add_item(_prev_item, 1);
        }
        variable_struct_set(_target_char.equipment, _slot, _def.id);
        sys_inventory_remove_item(_def.id, 1);
        return { used: true, message: _target_char.name + " equipped " + _def.name + "!" };
    }
    
    // Check usability flags
    if (_in_battle && ! _def.usable_battle) {
        return { used: false, message: _def.name + " cannot be used in battle." };
    }
    if (!_in_battle && !_def.usable_field) {
        return { used: false, message: _def.name + " cannot be used here." };
    }
    
    if (!is_struct(_target_char) && array_length(global.runtime.party) > 0) {
        _target_char = global.runtime.party[0];
    }
    if (!is_struct(_target_char)) return { used: false, message: "No valid target." };
    
    var _effect_notes = [];
    
    // Revive fallen character
    if (variable_struct_exists(_def, "revive") && _def.revive && _target_char.current_hp <= 0) {
        _target_char.current_hp = max(1, round(_target_char.max_hp * 0.5));
        _target_char.rolling_hp = _target_char.current_hp;
        array_push(_effect_notes, _target_char.name + " was revived!");
    }
    
    // Restore HP
    if (variable_struct_exists(_def, "hp_restore") && _def.hp_restore > 0 && _target_char.current_hp > 0) {
        var _old_hp = _target_char.current_hp;
        _target_char.current_hp = min(_target_char.max_hp, _target_char.current_hp + _def.hp_restore);
        _target_char.rolling_hp = _target_char.current_hp;
        var _gained_hp = _target_char.current_hp - _old_hp;
        if (_gained_hp > 0) {
            core_audio_play_default_sound("battle_heal");
        }
        array_push(_effect_notes, _target_char.name + " recovered " + string(_gained_hp) + " HP!");
    }
    
    // Restore MP (only when project PP/MP system is enabled)
    if (sys_project_pp_enabled() && variable_struct_exists(_def, "mp_restore") && _def.mp_restore > 0) {
        var _old_mp = _target_char.current_mp;
        _target_char.current_mp = min(_target_char.max_mp, _target_char.current_mp + _def.mp_restore);
        var _gained_mp = _target_char.current_mp - _old_mp;
        array_push(_effect_notes, _target_char.name + " recovered " + string(_gained_mp) + " PP/MP!");
    }
    
    // Cure status
    if (variable_struct_exists(_def, "status_cure") && _def.status_cure != "") {
        if (_target_char.status_effect == _def.status_cure || _def.status_cure == "all") {
            _target_char.status_effect = "";
            array_push(_effect_notes, _target_char.name + " was cured!");
        }
    }
    
    // Trigger custom map event if configured on the item
    if (variable_struct_exists(_def, "trigger_event_id") && _def.trigger_event_id != "") {
        sys_event_trigger_by_id(_def.trigger_event_id);
        array_push(_effect_notes, "Activated " + _def.name + ".");
    }
    
    // Execute multi-entry item event commands (cmd, p1, p2) if configured on the item
    if (variable_struct_exists(_def, "event_commands") && is_array(_def.event_commands) && array_length(_def.event_commands) > 0) {
        sys_event_enqueue_commands(_def.event_commands);
        for (var ec = 0; ec < array_length(_def.event_commands); ec++) {
            var _c_item = _def.event_commands[ec];
            if (is_struct(_c_item) && variable_struct_exists(_c_item, "cmd") && _c_item.cmd != "") {
                // Also allow direct map event ID in cmd if user typed an event ID
                sys_event_trigger_by_id(_c_item.cmd);
            }
        }
        array_push(_effect_notes, "Triggered " + _def.name + " event.");
    }
    
    // Consume stack if Consumable or Healing
    if (_def.category == ITEM_CATEGORY.CONSUMABLE || _def.category == ITEM_CATEGORY.HEALING) {
        sys_inventory_remove_item(_def.id, 1);
    }
    
    var _summary = array_length(_effect_notes) > 0 ? string_join_ext(" ", _effect_notes) : ("Used " + _def.name + ".");
    return { used: true, message: _summary };
}
