/// @description ST★RLIGHT ENGINE - Project & Game Save/Load System
/// Handles project directory creation, JSON persistence, .slproj import/export, and multi-slot game saves.

function core_saveload_write_text_file(_filepath, _text) {
    try {
        var _len = string_byte_length(_text);
        var _buf = buffer_create(max(1, _len), buffer_fixed, 1);
        if (_len > 0) {
            buffer_write(_buf, buffer_text, _text);
        }
        buffer_save(_buf, _filepath);
        buffer_delete(_buf);
        return true;
    } catch (_err) {
        core_log_error("core_saveload_write_text_file", "Failed writing '" + string(_filepath) + "': " + string(_err));
        return false;
    }
}

function core_saveload_read_text_file(_filepath) {
    if (!file_exists(_filepath)) return "";
    try {
        var _buf = buffer_load(_filepath);
        if (_buf < 0) return "";
        if (buffer_get_size(_buf) <= 0) {
            buffer_delete(_buf);
            return "";
        }
        var _str = buffer_read(_buf, buffer_text);
        buffer_delete(_buf);
        return _str;
    } catch (_err) {
        core_log_error("core_saveload_read_text_file", "Failed reading '" + string(_filepath) + "': " + string(_err));
        return "";
    }
}

function core_saveload_ensure_directories() {
    if (!directory_exists(global.engine.projects_root)) {
        directory_create(global.engine.projects_root);
    }
    
    // Provision bundled Demo RPG ('starfall_demo') into writable Projects folder if not yet copied
    var _demo_src = global.engine.bundled_projects_root + "starfall_demo/project.json";
    var _demo_dst_dir = global.engine.projects_root + "starfall_demo/";
    var _demo_dst_proj = _demo_dst_dir + "project.json";
    
    if (file_exists(_demo_src) && !file_exists(_demo_dst_proj)) {
        directory_create(_demo_dst_dir);
        directory_create(_demo_dst_dir + "maps/");
        directory_create(_demo_dst_dir + "tilesets/");
        directory_create(_demo_dst_dir + "sprites/");
        directory_create(_demo_dst_dir + "audio/");
        directory_create(_demo_dst_dir + "saves/");
        
        var _proj_txt = core_saveload_read_text_file(_demo_src);
        if (_proj_txt != "") {
            core_saveload_write_text_file(_demo_dst_proj, _proj_txt);
        }
        
        // Copy bundled demo map files
        var _m1 = global.engine.bundled_projects_root + "starfall_demo/maps/map_hometown.json";
        if (file_exists(_m1)) {
            core_saveload_write_text_file(_demo_dst_dir + "maps/map_hometown.json", core_saveload_read_text_file(_m1));
        }
        var _m2 = global.engine.bundled_projects_root + "starfall_demo/maps/map_star_cave.json";
        if (file_exists(_m2)) {
            core_saveload_write_text_file(_demo_dst_dir + "maps/map_star_cave.json", core_saveload_read_text_file(_m2));
        }
        var _s1 = global.engine.bundled_projects_root + "starfall_demo/saves/save_slot_1.json";
        if (file_exists(_s1)) {
            core_saveload_write_text_file(_demo_dst_dir + "saves/save_slot_1.json", core_saveload_read_text_file(_s1));
        }
    }
}

function core_saveload_sanitize_slug(_name) {
    var _lower = string_lower(_name);
    var _out = "";
    var _len = string_length(_lower);
    for (var i = 1; i <= _len; i++) {
        var _ch = string_char_at(_lower, i);
        var _code = ord(_ch);
        if ((_code >= ord("a") && _code <= ord("z")) || (_code >= ord("0") && _code <= ord("9"))) {
            _out += _ch;
        } else if (_ch == " " || _ch == "_" || _ch == "-") {
            _out += "_";
        }
    }
    if (_out == "") _out = "rpg_project";
    return _out;
}

function core_saveload_current_date_str() {
    var _y = string(current_year);
    var _m = (current_month < 10 ? "0" : "") + string(current_month);
    var _d = (current_day < 10 ? "0" : "") + string(current_day);
    var _hr = (current_hour < 10 ? "0" : "") + string(current_hour);
    var _mn = (current_minute < 10 ? "0" : "") + string(current_minute);
    return _y + "-" + _m + "-" + _d + " " + _hr + ":" + _mn;
}

/// @function core_saveload_create_new_project(_name, _author, _description)
/// @description Always creates a completely new, empty project with its own directory structure.
function core_saveload_create_new_project(_name, _author, _description) {
    var _base_slug = core_saveload_sanitize_slug(_name);
    var _slug = _base_slug;
    var _counter = 1;
    
    // Guarantee we NEVER overwrite or load an existing project folder
    while (directory_exists(global.engine.projects_root + _slug) ||
           file_exists(global.engine.projects_root + _slug + "/project.json")) {
        _counter++;
        _slug = _base_slug + "_" + string(_counter);
    }
    
    var _proj_dir = global.engine.projects_root + _slug + "/";
    directory_create(_proj_dir);
    directory_create(_proj_dir + "maps/");
    directory_create(_proj_dir + "tilesets/");
    directory_create(_proj_dir + "sprites/");
    directory_create(_proj_dir + "audio/");
    directory_create(_proj_dir + "saves/");
    
    var _starter_map = editor_map_create_empty_struct("map_01", "Starter Map", 24, 16, 32);
    var _starter_char = sys_character_create_default("char_01", "Hero");
    
    var _proj = {
        schema_version: STARLIGHT_SCHEMA_VERSION,
        engine_version: STARLIGHT_VERSION_STRING,
        id: _slug,
        name: _name,
        author: _author,
        description: _description,
        last_modified: core_saveload_current_date_str(),
        starting_map_id: "map_01",
        starting_char_id: "char_01",
        starting_x: 5,
        starting_y: 5,
        starting_gold: 50,
        defeat_behavior: "gameover_screen",
        enable_pp_system: true,
        aspect_ratio: "16:9",
        combat_config: {
            attack_multiplier: 1.0,
            defense_multiplier: 0.5,
            crit_chance: 0.08,
            crit_multiplier: 1.75,
            allow_run: true
        },
        maps: [_starter_map],
        tilesets: [
            {
                id: "ts_default_16bit",
                name: "Starlight 16-Bit Standard",
                file_path: "",
                tile_size: 32,
                tile_count: 24
            }
        ],
        sprites: [
            {
                id: "spr_hero_default",
                name: "Hero Standard Sprite",
                file_path: "",
                archetype: "character",
                primary_color: make_color_rgb(92, 198, 245),
                secondary_color: make_color_rgb(255, 214, 74),
                scale: 1.0,
                frame_count: 4,
                animations: sys_sprite_create_default_animations()
            }
        ],
        characters: [_starter_char],
        items: [],
        enemies: [],
        variables: [],
        quests: [],
        audio: [],
        default_sounds: core_audio_create_default_ui_sounds_struct()
    };
    
    core_assets_clear_cache();
    core_audio_cleanup_streams();
    
    global.project = _proj;
    global.project_path = _proj_dir;
    global.project_dirty = false;
    global.playtest_active = false;
    
    core_saveload_save_project();
    core_log_toast("Created new project: " + _name);
    return true;
}

/// @function core_saveload_save_project()
/// @description Saves the active project manifest and individual map JSON files to disk.
function core_saveload_save_project() {
    if (is_undefined(global.project) || global.project_path == "") {
        core_log_error("core_saveload_save_project", "No active project loaded to save.");
        return false;
    }
    
    global.project.last_modified = core_saveload_current_date_str();
    global.project.schema_version = STARLIGHT_SCHEMA_VERSION;
    
    if (!directory_exists(global.project_path)) {
        directory_create(global.project_path);
    }
    if (!directory_exists(global.project_path + "maps/")) {
        directory_create(global.project_path + "maps/");
    }
    
    // Save each map into maps/<map_id>.json as well as keeping the master manifest synchronized
    for (var i = 0; i < array_length(global.project.maps); i++) {
        var _m = global.project.maps[i];
        var _mjson = json_stringify(_m, true);
        core_saveload_write_text_file(global.project_path + "maps/" + _m.id + ".json", _mjson);
    }
    
    var _proj_json = json_stringify(global.project, true);
    var _ok = core_saveload_write_text_file(global.project_path + "project.json", _proj_json);
    if (_ok) {
        global.project_dirty = false;
        core_log_toast("Project saved: " + global.project.name);
    }
    return _ok;
}

/// @function core_saveload_validate_project_struct(_data)
/// @description Validates and normalizes a loaded or imported project struct.
function core_saveload_validate_project_struct(_data) {
    if (!is_struct(_data)) return false;
    if (!variable_struct_exists(_data, "name") || !variable_struct_exists(_data, "maps")) {
        return false;
    }
    if (!is_array(_data.maps) || array_length(_data.maps) == 0) {
        return false;
    }
    
    // Ensure all expected collections exist so partial/older files never crash
    if (!variable_struct_exists(_data, "author")) _data.author = "Unknown";
    if (!variable_struct_exists(_data, "description")) _data.description = "";
    if (!variable_struct_exists(_data, "last_modified")) _data.last_modified = core_saveload_current_date_str();
    if (!variable_struct_exists(_data, "starting_map_id")) _data.starting_map_id = _data.maps[0].id;
    if (!variable_struct_exists(_data, "starting_x")) _data.starting_x = 4;
    if (!variable_struct_exists(_data, "starting_y")) _data.starting_y = 4;
    if (!variable_struct_exists(_data, "starting_gold")) _data.starting_gold = 50;
    if (!variable_struct_exists(_data, "defeat_behavior")) _data.defeat_behavior = "gameover_screen";
    if (!variable_struct_exists(_data, "enable_pp_system")) _data.enable_pp_system = true;
    if (!variable_struct_exists(_data, "aspect_ratio")) _data.aspect_ratio = "16:9";
    if (!variable_struct_exists(_data, "tilesets") || !is_array(_data.tilesets) || array_length(_data.tilesets) == 0) {
        _data.tilesets = [{
            id: "ts_default_16bit",
            name: "Starlight 16-Bit Standard",
            file_path: "",
            tile_size: 32,
            tile_count: 24,
            custom_tiles: [],
            tile_entries: []
        }];
    }
    for (var ti = 0; ti < array_length(_data.tilesets); ti++) {
        core_assets_ensure_tileset_entries(_data.tilesets[ti]);
    }
    if (!variable_struct_exists(_data, "sprites") || !is_array(_data.sprites)) _data.sprites = [];
    var _dedup_sprites = [];
    var _seen_sp_ids = {};
    for (var si = 0; si < array_length(_data.sprites); si++) {
        var _sp_item = _data.sprites[si];
        if (is_struct(_sp_item) && variable_struct_exists(_sp_item, "id")) {
            sys_sprite_normalize_animations(_sp_item);
            if (!variable_struct_exists(_seen_sp_ids, _sp_item.id)) {
                variable_struct_set(_seen_sp_ids, _sp_item.id, true);
                array_push(_dedup_sprites, _sp_item);
            }
        }
    }
    _data.sprites = _dedup_sprites;
    if (!variable_struct_exists(_data, "characters") || !is_array(_data.characters)) {
        _data.characters = [sys_character_create_default("char_01", "Hero")];
    }
    for (var ci = 0; ci < array_length(_data.characters); ci++) {
        var _c_it = _data.characters[ci];
        if (is_struct(_c_it)) {
            _c_it.sprite_scale = sys_sprite_clamp_scale(variable_struct_exists(_c_it, "sprite_scale") ? _c_it.sprite_scale : 1.0);
        }
    }
    if (!variable_struct_exists(_data, "starting_char_id")) _data.starting_char_id = _data.characters[0].id;
    if (!variable_struct_exists(_data, "items") || !is_array(_data.items)) _data.items = [];
    if (!variable_struct_exists(_data, "enemies") || !is_array(_data.enemies)) _data.enemies = [];
    for (var ei = 0; ei < array_length(_data.enemies); ei++) {
        var _e_it = _data.enemies[ei];
        if (is_struct(_e_it)) {
            _e_it.overworld_scale = sys_sprite_clamp_scale(variable_struct_exists(_e_it, "overworld_scale") ? _e_it.overworld_scale : 1.0);
            _e_it.battle_scale = sys_sprite_clamp_scale(variable_struct_exists(_e_it, "battle_scale") ? _e_it.battle_scale : 1.0);
        }
    }
    for (var mi = 0; mi < array_length(_data.maps); mi++) {
        var _m_it = _data.maps[mi];
        if (!is_struct(_m_it)) continue;
        if (variable_struct_exists(_m_it, "objects") && is_array(_m_it.objects)) {
            for (var oi = 0; oi < array_length(_m_it.objects); oi++) {
                var _o_it = _m_it.objects[oi];
                if (is_struct(_o_it)) {
                    if (!variable_struct_exists(_o_it, "visible")) _o_it.visible = true;
                    _o_it.sprite_scale = sys_sprite_clamp_scale(variable_struct_exists(_o_it, "sprite_scale") ? _o_it.sprite_scale : 1.0);
                }
            }
        }
        if (variable_struct_exists(_m_it, "npcs") && is_array(_m_it.npcs)) {
            for (var ni = 0; ni < array_length(_m_it.npcs); ni++) {
                var _n_it = _m_it.npcs[ni];
                if (is_struct(_n_it)) {
                    _n_it.sprite_scale = sys_sprite_clamp_scale(variable_struct_exists(_n_it, "sprite_scale") ? _n_it.sprite_scale : 1.0);
                }
            }
        }
    }
    if (!variable_struct_exists(_data, "variables") || !is_array(_data.variables)) _data.variables = [];
    if (!variable_struct_exists(_data, "quests") || !is_array(_data.quests)) _data.quests = [];
    if (!variable_struct_exists(_data, "audio") || !is_array(_data.audio)) _data.audio = [];
    core_audio_normalize_project_sounds(_data);
    if (!variable_struct_exists(_data, "combat_config") || !is_struct(_data.combat_config)) {
        _data.combat_config = {
            attack_multiplier: 1.0,
            defense_multiplier: 0.5,
            crit_chance: 0.08,
            crit_multiplier: 1.75,
            allow_run: true
        };
    }
    return true;
}

/// @function core_saveload_load_project(_folder_path)
/// @description Loads a project from disk into global.project and validates all maps and databases.
function core_saveload_load_project(_folder_path) {
    var _dir = _folder_path;
    if (string_char_at(_dir, string_length(_dir)) != "/" && string_char_at(_dir, string_length(_dir)) != "\\") {
        _dir += "/";
    }
    var _manifest_path = _dir + "project.json";
    if (!file_exists(_manifest_path)) {
        core_log_error("core_saveload_load_project", "Project manifest not found: " + _manifest_path);
        return false;
    }
    
    var _raw = core_saveload_read_text_file(_manifest_path);
    if (_raw == "") {
        core_log_error("core_saveload_load_project", "Project file is empty or unreadable.");
        return false;
    }
    
    try {
        var _parsed = json_parse(_raw);
        
        // Also load external map files from maps/*.json if present
        if (is_struct(_parsed) && variable_struct_exists(_parsed, "maps") && is_array(_parsed.maps)) {
            for (var i = 0; i < array_length(_parsed.maps); i++) {
                var _mentry = _parsed.maps[i];
                if (is_struct(_mentry) && variable_struct_exists(_mentry, "id")) {
                    var _mfile = _dir + "maps/" + _mentry.id + ".json";
                    if (file_exists(_mfile)) {
                        var _mraw = core_saveload_read_text_file(_mfile);
                        if (_mraw != "") {
                            var _mparsed = json_parse(_mraw);
                            if (is_struct(_mparsed)) {
                                _parsed.maps[i] = _mparsed;
                            }
                        }
                    }
                }
            }
        }
        
        if (!core_saveload_validate_project_struct(_parsed)) {
            core_log_error("core_saveload_load_project", "Invalid or incompatible project structure.");
            return false;
        }
        
        core_assets_clear_cache();
        core_audio_cleanup_streams();
        
        global.project = _parsed;
        global.project_path = _dir;
        global.project_dirty = false;
        global.playtest_active = false;
        
        core_log_toast("Loaded project: " + _parsed.name);
        return true;
    } catch (_err) {
        core_log_error("core_saveload_load_project", "Corrupted project JSON: " + string(_err));
        return false;
    }
}

/// @function core_saveload_scan_projects()
/// @description Returns an array of project metadata structs found in Saved Projects.
function core_saveload_scan_projects() {
    core_saveload_ensure_directories();
    var _results = [];
    var _seen_ids = {};
    
    var _roots = [global.engine.projects_root, global.engine.bundled_projects_root];
    for (var r = 0; r < array_length(_roots); r++) {
        var _root = _roots[r];
        if (!directory_exists(_root)) continue;
        
        var _folder = file_find_first(_root + "*", fa_directory);
        while (_folder != "") {
            if (_folder != "." && _folder != "..") {
                var _fdir = _root + _folder + "/";
                var _pjson = _fdir + "project.json";
                if (file_exists(_pjson)) {
                    var _txt = core_saveload_read_text_file(_pjson);
                    if (_txt != "") {
                        try {
                            var _p = json_parse(_txt);
                            if (is_struct(_p) && variable_struct_exists(_p, "name")) {
                                var _pid = variable_struct_exists(_p, "id") ? _p.id : _folder;
                                if (!variable_struct_exists(_seen_ids, _pid)) {
                                    variable_struct_set(_seen_ids, _pid, true);
                                    array_push(_results, {
                                        id: _pid,
                                        name: _p.name,
                                        author: variable_struct_exists(_p, "author") ? _p.author : "Unknown",
                                        description: variable_struct_exists(_p, "description") ? _p.description : "",
                                        last_modified: variable_struct_exists(_p, "last_modified") ? _p.last_modified : "Unknown",
                                        folder_path: _fdir
                                    });
                                }
                            }
                        } catch (_e) {
                            // Skip malformed directory cleanly
                        }
                    }
                }
            }
            _folder = file_find_next();
        }
        file_find_close();
    }
    return _results;
}

/// @function core_saveload_delete_project(_folder_path)
/// @description Deletes a project's files after user confirmation.
function core_saveload_delete_project(_folder_path) {
    if (_folder_path == "" || !directory_exists(_folder_path)) return false;
    try {
        if (file_exists(_folder_path + "project.json")) {
            file_delete(_folder_path + "project.json");
        }
        directory_destroy(_folder_path);
        core_log_toast("Project deleted.");
        return true;
    } catch (_err) {
        core_log_error("core_saveload_delete_project", "Could not delete project folder: " + string(_err));
        return false;
    }
}

/// @function core_saveload_collect_embedded_assets(_proj_dir)
/// @description Base64-encodes custom files in sprites/, tilesets/, and audio/ so .slproj exports preserve all binary assets.
function core_saveload_collect_embedded_assets(_proj_dir) {
    var _assets = [];
    if (_proj_dir == "" || !directory_exists(_proj_dir)) return _assets;
    
    var _subdirs = ["sprites/", "tilesets/", "audio/"];
    for (var d = 0; d < array_length(_subdirs); d++) {
        var _sub = _subdirs[d];
        var _full_sub = _proj_dir + _sub;
        if (!directory_exists(_full_sub)) continue;
        
        var _fn = file_find_first(_full_sub + "*.*", 0);
        while (_fn != "") {
            var _fpath = _full_sub + _fn;
            if (file_exists(_fpath)) {
                try {
                    var _buf = buffer_load(_fpath);
                    if (_buf >= 0) {
                        var _sz = buffer_get_size(_buf);
                        if (_sz > 0) {
                            var _b64 = buffer_base64_encode(_buf, 0, _sz);
                            array_push(_assets, {
                                rel_path: _sub + _fn,
                                b64: _b64
                            });
                        }
                        buffer_delete(_buf);
                    }
                } catch (_err) {
                    // Skip unreadable asset gracefully
                }
            }
            _fn = file_find_next();
        }
        file_find_close();
    }
    return _assets;
}

/// @function core_saveload_export_project_dialog()
/// @description Exports the entire active project and its imported PNG/OGG assets into a portable .slproj file.
function core_saveload_export_project_dialog() {
    if (is_undefined(global.project)) return false;
    var _default_name = core_saveload_sanitize_slug(global.project.name) + ".slproj";
    var _target = get_save_filename("Starlight Engine Project (*.slproj)|*.slproj|JSON Project (*.json)|*.json", _default_name);
    if (_target == "") return false;
    
    var _bundle = {
        starlight_export_bundle: true,
        schema_version: STARLIGHT_SCHEMA_VERSION,
        exported_at: core_saveload_current_date_str(),
        project: global.project,
        embedded_assets: core_saveload_collect_embedded_assets(global.project_path)
    };
    
    var _json = json_stringify(_bundle, true);
    if (core_saveload_write_text_file(_target, _json)) {
        core_log_toast("Exported project & assets to: " + filename_name(_target));
        return true;
    }
    return false;
}

/// @function core_saveload_import_project_dialog()
/// @description Opens native Windows file explorer to select and validate a .slproj file.
function core_saveload_import_project_dialog() {
    var _src = get_open_filename("Starlight Engine Project (*.slproj;*.json)|*.slproj;*.json", "");
    if (_src == "" || !file_exists(_src)) return false;
    
    var _raw = core_saveload_read_text_file(_src);
    if (_raw == "") {
        core_log_error("Import Project", "Selected file is empty or unreadable.");
        return false;
    }
    
    try {
        var _parsed = json_parse(_raw);
        var _proj_data = _parsed;
        if (is_struct(_parsed) && variable_struct_exists(_parsed, "starlight_export_bundle") && variable_struct_exists(_parsed, "project")) {
            _proj_data = _parsed.project;
            if (variable_struct_exists(_parsed, "embedded_assets") && is_array(_parsed.embedded_assets)) {
                _proj_data.__embedded_assets = _parsed.embedded_assets;
            }
        }
        _proj_data.__import_source_dir = filename_path(_src);
        
        if (!core_saveload_validate_project_struct(_proj_data)) {
            core_log_error("Import Project", "Invalid or incompatible Starlight project file.");
            return false;
        }
        
        var _slug = variable_struct_exists(_proj_data, "id") ? core_saveload_sanitize_slug(_proj_data.id) : core_saveload_sanitize_slug(_proj_data.name);
        _proj_data.id = _slug;
        var _dest_dir = global.engine.projects_root + _slug + "/";
        
        // Never overwrite an existing project without confirmation
        if (file_exists(_dest_dir + "project.json")) {
            global.scene.import_pending_data = _proj_data;
            global.scene.import_pending_source = _src;
            global.scene.projects_submenu = PROJECTS_SUBMENU.IMPORT_CONFIRM;
            return true;
        }
        
        return core_saveload_finalize_import(_proj_data, true);
    } catch (_err) {
        core_log_error("Import Project", "Corrupted project file: " + string(_err));
        return false;
    }
}

function core_saveload_finalize_import(_proj_data, _allow_overwrite) {
    if (!is_struct(_proj_data)) return false;
    var _slug = core_saveload_sanitize_slug(_proj_data.id);
    if (!_allow_overwrite) {
        var _base = _slug;
        var _n = 2;
        while (file_exists(global.engine.projects_root + _slug + "/project.json")) {
            _slug = _base + "_" + string(_n);
            _n++;
        }
        _proj_data.id = _slug;
        _proj_data.name = _proj_data.name + " (" + string(_n - 1) + ")";
    }
    
    var _dest_dir = global.engine.projects_root + _slug + "/";
    directory_create(_dest_dir);
    directory_create(_dest_dir + "maps/");
    directory_create(_dest_dir + "tilesets/");
    directory_create(_dest_dir + "sprites/");
    directory_create(_dest_dir + "audio/");
    directory_create(_dest_dir + "saves/");
    
    // Restore embedded PNG / OGG assets from .slproj bundle if present
    if (variable_struct_exists(_proj_data, "__embedded_assets") && is_array(_proj_data.__embedded_assets)) {
        var _emb = _proj_data.__embedded_assets;
        for (var a = 0; a < array_length(_emb); a++) {
            var _ea = _emb[a];
            if (is_struct(_ea) && variable_struct_exists(_ea, "rel_path") && variable_struct_exists(_ea, "b64")) {
                try {
                    var _abuf = buffer_base64_decode(_ea.b64);
                    if (_abuf >= 0) {
                        buffer_save(_abuf, _dest_dir + _ea.rel_path);
                        buffer_delete(_abuf);
                    }
                } catch (_err_a) {
                    // Ignore malformed embedded asset
                }
            }
        }
        variable_struct_remove(_proj_data, "__embedded_assets");
    }
    
    // Also copy any adjacent sprites/, tilesets/, or audio/ files when importing a project.json from a folder
    if (variable_struct_exists(_proj_data, "__import_source_dir")) {
        var _sdir = _proj_data.__import_source_dir;
        variable_struct_remove(_proj_data, "__import_source_dir");
        if (_sdir != "" && _sdir != _dest_dir && directory_exists(_sdir)) {
            var _subs = ["sprites/", "tilesets/", "audio/"];
            for (var sd = 0; sd < 3; sd++) {
                var _sp = _sdir + _subs[sd];
                if (directory_exists(_sp)) {
                    var _f = file_find_first(_sp + "*.*", 0);
                    while (_f != "") {
                        if (!file_exists(_dest_dir + _subs[sd] + _f)) {
                            file_copy(_sp + _f, _dest_dir + _subs[sd] + _f);
                        }
                        _f = file_find_next();
                    }
                    file_find_close();
                }
            }
        }
    }
    
    for (var i = 0; i < array_length(_proj_data.maps); i++) {
        var _m = _proj_data.maps[i];
        core_saveload_write_text_file(_dest_dir + "maps/" + _m.id + ".json", json_stringify(_m, true));
    }
    
    _proj_data.last_modified = core_saveload_current_date_str();
    core_saveload_write_text_file(_dest_dir + "project.json", json_stringify(_proj_data, true));
    global.scene.saved_projects_list = core_saveload_scan_projects();
    global.scene.projects_submenu = PROJECTS_SUBMENU.SAVED_PROJECTS;
    core_log_toast("Imported project: " + _proj_data.name);
    return true;
}

// ============================================================================
// MULTI-SLOT GAME SAVE & LOAD SYSTEM (Runtime Persistence)
// ============================================================================

function core_game_get_saves_dir() {
    if (global.project_path != "") {
        var _dir = global.project_path + "saves/";
        if (!directory_exists(_dir)) directory_create(_dir);
        return _dir;
    }
    var _fallback = game_save_id + "saves/";
    if (!directory_exists(_fallback)) directory_create(_fallback);
    return _fallback;
}

function core_game_get_slot_filepath(_slot_index) {
    return core_game_get_saves_dir() + "save_slot_" + string(_slot_index) + ".json";
}

function core_game_get_save_slots(_max_slots) {
    var _slots = [];
    for (var s = 1; s <= _max_slots; s++) {
        var _fp = core_game_get_slot_filepath(s);
        var _entry = {
            slot: s,
            exists: false,
            corrupted: false,
            save_name: "Empty Slot " + string(s),
            party_names: "-",
            playtime_seconds: 0,
            map_name: "-",
            save_date: "-"
        };
        if (file_exists(_fp)) {
            var _raw = core_saveload_read_text_file(_fp);
            if (_raw != "") {
                try {
                    var _data = json_parse(_raw);
                    if (is_struct(_data) && variable_struct_exists(_data, "schema_version") && variable_struct_exists(_data, "current_map_id")) {
                        _entry.exists = true;
                        _entry.save_name = variable_struct_exists(_data, "save_name") ? _data.save_name : ("Adventure " + string(s));
                        _entry.party_names = variable_struct_exists(_data, "party_summary") ? _data.party_summary : "Party";
                        _entry.playtime_seconds = variable_struct_exists(_data, "playtime_seconds") ? _data.playtime_seconds : 0;
                        _entry.map_name = variable_struct_exists(_data, "current_map_name") ? _data.current_map_name : _data.current_map_id;
                        _entry.save_date = variable_struct_exists(_data, "save_date") ? _data.save_date : "";
                    } else {
                        _entry.corrupted = true;
                        _entry.save_name = "Incompatible Save";
                    }
                } catch (_err) {
                    _entry.corrupted = true;
                    _entry.save_name = "Corrupted Save File";
                }
            }
        }
        array_push(_slots, _entry);
    }
    return _slots;
}

/// @function core_game_save_slot(_slot_index, _custom_save_name)
/// @description Saves persistent runtime progress (never temporary battle state) to the chosen slot.
function core_game_save_slot(_slot_index, _custom_save_name) {
    if (global.scene.current == ENGINE_SCENE.RUNTIME_BATTLE) {
        core_log_warning("Save System", "Cannot save temporary battle state during active combat.");
        return false;
    }
    var _rt = global.runtime;
    var _party_names = [];
    for (var i = 0; i < array_length(_rt.party); i++) {
        var _m = _rt.party[i];
        array_push(_party_names, _m.name + " Lv." + string(_m.level));
    }
    var _summary = array_length(_party_names) > 0 ? string_join_ext(", ", _party_names) : "Hero";
    var _map_struct = editor_map_find_by_id(_rt.current_map_id);
    var _map_title = is_struct(_map_struct) ? _map_struct.name : _rt.current_map_id;
    
    var _save_payload = {
        schema_version: STARLIGHT_SCHEMA_VERSION,
        engine_version: STARLIGHT_VERSION_STRING,
        project_id: is_struct(global.project) ? global.project.id : "unknown",
        slot: _slot_index,
        save_name: (_custom_save_name != "" && !is_undefined(_custom_save_name)) ? _custom_save_name : (_map_title + " - Slot " + string(_slot_index)),
        save_date: core_saveload_current_date_str(),
        playtime_seconds: _rt.playtime_seconds,
        current_map_id: _rt.current_map_id,
        current_map_name: _map_title,
        player_x: _rt.player_x,
        player_y: _rt.player_y,
        player_facing: _rt.player_facing,
        gold: _rt.gold,
        party_summary: _summary,
        party: _rt.party,
        inventory: _rt.inventory,
        variables: _rt.variables,
        quests: _rt.quests,
        defeated_enemies: _rt.defeated_enemies,
        completed_events: _rt.completed_events,
        stats_telemetry: _rt.stats_telemetry
    };
    
    var _fp = core_game_get_slot_filepath(_slot_index);
    var _ok = core_saveload_write_text_file(_fp, json_stringify(_save_payload, true));
    if (_ok) {
        core_audio_play_default_sound("gameplay_save");
        core_log_toast("Saved game to Slot " + string(_slot_index));
    }
    return _ok;
}

/// @function core_game_load_slot(_slot_index)
/// @description Loads persistent game progress from a save slot with corruption and version checks.
function core_game_load_slot(_slot_index) {
    var _fp = core_game_get_slot_filepath(_slot_index);
    if (!file_exists(_fp)) {
        core_log_warning("Load Game", "Save Slot " + string(_slot_index) + " does not exist.");
        return false;
    }
    var _raw = core_saveload_read_text_file(_fp);
    if (_raw == "") {
        core_log_error("Load Game", "Save Slot " + string(_slot_index) + " is empty.");
        return false;
    }
    
    try {
        var _data = json_parse(_raw);
        if (!is_struct(_data) || !variable_struct_exists(_data, "current_map_id")) {
            core_log_error("Load Game", "Save Slot " + string(_slot_index) + " is invalid or incompatible.");
            return false;
        }
        
        var _rt = global.runtime;
        _rt.playtime_seconds = variable_struct_exists(_data, "playtime_seconds") ? _data.playtime_seconds : 0;
        _rt.gold = variable_struct_exists(_data, "gold") ? _data.gold : 0;
        if (variable_struct_exists(_data, "party") && is_array(_data.party)) _rt.party = _data.party;
        if (variable_struct_exists(_data, "inventory") && is_array(_data.inventory)) _rt.inventory = _data.inventory;
        if (variable_struct_exists(_data, "variables") && is_struct(_data.variables)) _rt.variables = _data.variables;
        if (variable_struct_exists(_data, "quests") && is_struct(_data.quests)) _rt.quests = _data.quests;
        if (variable_struct_exists(_data, "defeated_enemies") && is_struct(_data.defeated_enemies)) _rt.defeated_enemies = _data.defeated_enemies;
        if (variable_struct_exists(_data, "completed_events") && is_struct(_data.completed_events)) _rt.completed_events = _data.completed_events;
        if (variable_struct_exists(_data, "stats_telemetry") && is_struct(_data.stats_telemetry)) _rt.stats_telemetry = _data.stats_telemetry;
        
        var _dest_map = _data.current_map_id;
        var _px = variable_struct_exists(_data, "player_x") ? _data.player_x : 160;
        var _py = variable_struct_exists(_data, "player_y") ? _data.player_y : 160;
        var _pfacing = variable_struct_exists(_data, "player_facing") ? _data.player_facing : DIR_FACING.DOWN;
        
        sys_transition_load_map(_dest_map, _px, _py, _pfacing, false);
        _rt.pause_menu_open = false;
        core_audio_play_default_sound("gameplay_load");
        core_log_toast("Loaded Save Slot " + string(_slot_index));
        return true;
    } catch (_err) {
        core_log_error("Load Game", "Corrupted save slot " + string(_slot_index) + ": " + string(_err));
        return false;
    }
}

/// @function sys_project_pp_enabled()
/// @description Returns true if the active project has the PP/MP resource system enabled.
function sys_project_pp_enabled() {
    if (is_undefined(global.project) || !is_struct(global.project)) return true;
    if (!variable_struct_exists(global.project, "enable_pp_system")) return true;
    return bool(global.project.enable_pp_system);
}

/// @function editor_validate_custom_id(_raw_id)
/// @description Validates that a custom ID contains only letters, digits, underscores, or hyphens.
function editor_validate_custom_id(_raw_id) {
    var _s = string_trim(string(_raw_id));
    if (_s == "") return { valid: false, id: "", reason: "ID cannot be empty." };
    var _len = string_length(_s);
    for (var i = 1; i <= _len; i++) {
        var _c = string_char_at(_s, i);
        var _code = ord(_c);
        var _ok = ((_code >= ord("a") && _code <= ord("z")) ||
                   (_code >= ord("A") && _code <= ord("Z")) ||
                   (_code >= ord("0") && _code <= ord("9")) ||
                   _c == "_" || _c == "-");
        if (!_ok) {
            return { valid: false, id: _s, reason: "Invalid character '" + _c + "' (use a-z, 0-9, _, -)." };
        }
    }
    return { valid: true, id: _s, reason: "" };
}

function editor_update_cmd_array_refs(_cmds, _category, _old_id, _new_id) {
    if (!is_array(_cmds)) return;
    for (var i = 0; i < array_length(_cmds); i++) {
        var _c = _cmds[i];
        if (!is_struct(_c) || !variable_struct_exists(_c, "cmd")) continue;
        if (_category == "character") {
            if ((_c.cmd == "add_party_member" || _c.cmd == "remove_party_member" || _c.cmd == "change_char_name") && _c.p1 == _old_id) _c.p1 = _new_id;
            if ((_c.cmd == "add_exp" || _c.cmd == "set_exp") && _c.p2 == _old_id) _c.p2 = _new_id;
        } else if (_category == "item") {
            if ((_c.cmd == "add_item" || _c.cmd == "remove_item" || _c.cmd == "check_item_quantity") && _c.p1 == _old_id) _c.p1 = _new_id;
        } else if (_category == "enemy") {
            if (_c.cmd == "start_battle" && _c.p1 == _old_id) _c.p1 = _new_id;
        } else if (_category == "audio") {
            if ((_c.cmd == "start_music" || _c.cmd == "play_sfx") && _c.p1 == _old_id) _c.p1 = _new_id;
        } else if (_category == "map") {
            if (_c.cmd == "teleport_map" && _c.p1 == _old_id) _c.p1 = _new_id;
        }
    }
}

function editor_update_dialogue_tree_refs(_tree, _category, _old_id, _new_id) {
    if (!is_array(_tree)) return;
    for (var n = 0; n < array_length(_tree); n++) {
        var _node = _tree[n];
        if (!is_struct(_node)) continue;
        if (variable_struct_exists(_node, "event_commands")) {
            editor_update_cmd_array_refs(_node.event_commands, _category, _old_id, _new_id);
        }
        if (variable_struct_exists(_node, "choices") && is_array(_node.choices)) {
            for (var ch = 0; ch < array_length(_node.choices); ch++) {
                var _choice = _node.choices[ch];
                if (is_struct(_choice) && variable_struct_exists(_choice, "event_commands")) {
                    editor_update_cmd_array_refs(_choice.event_commands, _category, _old_id, _new_id);
                }
            }
        }
    }
}

/// @function editor_rename_resource_id(_category, _target_struct, _new_id_raw)
/// @description Validates a custom ID, checks duplicates, and updates all references across the project.
function editor_rename_resource_id(_category, _target_struct, _new_id_raw) {
    if (!is_struct(_target_struct) || is_undefined(global.project)) return _target_struct.id;
    var _old_id = _target_struct.id;
    var _chk = editor_validate_custom_id(_new_id_raw);
    if (!_chk.valid) {
        core_log_warning("Custom ID", _chk.reason + " Kept '" + _old_id + "'.");
        return _old_id;
    }
    var _new_id = _chk.id;
    if (_new_id == _old_id) return _old_id;
    
    // Check duplicates within category collection
    var _collection = [];
    if (_category == "character") _collection = global.project.characters;
    else if (_category == "item") _collection = global.project.items;
    else if (_category == "enemy") _collection = global.project.enemies;
    else if (_category == "sprite") _collection = global.project.sprites;
    else if (_category == "audio") _collection = global.project.audio;
    else if (_category == "map") _collection = global.project.maps;
    else if (_category == "tileset") _collection = global.project.tilesets;
    else if (_category == "event") {
        var _amap = editor_get_active_map();
        if (is_struct(_amap)) _collection = _amap.events;
    }
    
    for (var i = 0; i < array_length(_collection); i++) {
        if (_collection[i] != _target_struct && _collection[i].id == _new_id) {
            core_log_warning("Custom ID", "Duplicate ID '" + _new_id + "' already exists! Kept '" + _old_id + "'.");
            return _old_id;
        }
    }
    
    // Apply new ID and cascade across all references in global.project
    _target_struct.id = _new_id;
    var _proj = global.project;
    
    if (_category == "character") {
        if (_proj.starting_char_id == _old_id) _proj.starting_char_id = _new_id;
    } else if (_category == "map") {
        if (_proj.starting_map_id == _old_id) _proj.starting_map_id = _new_id;
        if (global.project_path != "" && file_exists(global.project_path + "maps/" + _old_id + ".json")) {
            file_delete(global.project_path + "maps/" + _old_id + ".json");
        }
    } else if (_category == "item") {
        for (var e = 0; e < array_length(_proj.enemies); e++) {
            if (_proj.enemies[e].reward_item_id == _old_id) _proj.enemies[e].reward_item_id = _new_id;
        }
    } else if (_category == "event") {
        for (var it = 0; it < array_length(_proj.items); it++) {
            if (_proj.items[it].trigger_event_id == _old_id) _proj.items[it].trigger_event_id = _new_id;
        }
        for (var en = 0; en < array_length(_proj.enemies); en++) {
            if (_proj.enemies[en].reward_event_id == _old_id) _proj.enemies[en].reward_event_id = _new_id;
        }
    } else if (_category == "sprite") {
        for (var c = 0; c < array_length(_proj.characters); c++) {
            if (_proj.characters[c].sprite_id == _old_id) _proj.characters[c].sprite_id = _new_id;
            if (_proj.characters[c].portrait_sprite_id == _old_id) _proj.characters[c].portrait_sprite_id = _new_id;
        }
        for (var ed = 0; ed < array_length(_proj.enemies); ed++) {
            if (_proj.enemies[ed].sprite_id == _old_id) _proj.enemies[ed].sprite_id = _new_id;
            if (_proj.enemies[ed].battle_sprite_id == _old_id) _proj.enemies[ed].battle_sprite_id = _new_id;
        }
        for (var m = 0; m < array_length(_proj.maps); m++) {
            var _mp = _proj.maps[m];
            for (var np = 0; np < array_length(_mp.npcs); np++) {
                if (_mp.npcs[np].sprite_id == _old_id) _mp.npcs[np].sprite_id = _new_id;
                if (_mp.npcs[np].portrait_sprite_id == _old_id) _mp.npcs[np].portrait_sprite_id = _new_id;
            }
            for (var ob = 0; ob < array_length(_mp.objects); ob++) {
                if (_mp.objects[ob].sprite_id == _old_id) _mp.objects[ob].sprite_id = _new_id;
            }
        }
    } else if (_category == "tileset") {
        if (global.editor.selected_tileset_id == _old_id) global.editor.selected_tileset_id = _new_id;
        for (var mt = 0; mt < array_length(_proj.maps); mt++) {
            if (_proj.maps[mt].tileset_id == _old_id) _proj.maps[mt].tileset_id = _new_id;
        }
    }
    
    // Update references inside all Maps (events, NPCs, objects, enemies, BGM)
    for (var mi = 0; mi < array_length(_proj.maps); mi++) {
        var _map = _proj.maps[mi];
        if (_category == "audio" && _map.bgm_id == _old_id) _map.bgm_id = _new_id;
        if (_category == "enemy") {
            for (var mei = 0; mei < array_length(_map.enemies); mei++) {
                if (_map.enemies[mei].enemy_id == _old_id) _map.enemies[mei].enemy_id = _new_id;
            }
        }
        for (var evi = 0; evi < array_length(_map.events); evi++) {
            editor_update_cmd_array_refs(_map.events[evi].commands, _category, _old_id, _new_id);
        }
        for (var npi = 0; npi < array_length(_map.npcs); npi++) {
            editor_update_dialogue_tree_refs(_map.npcs[npi].dialogue_tree, _category, _old_id, _new_id);
        }
        for (var obi = 0; obi < array_length(_map.objects); obi++) {
            editor_update_dialogue_tree_refs(_map.objects[obi].dialogue_tree, _category, _old_id, _new_id);
        }
    }
    
    // Update references inside Item on-use event_commands
    for (var ii = 0; ii < array_length(_proj.items); ii++) {
        if (variable_struct_exists(_proj.items[ii], "event_commands")) {
            editor_update_cmd_array_refs(_proj.items[ii].event_commands, _category, _old_id, _new_id);
        }
    }
    
    global.project_dirty = true;
    core_log_toast("Renamed ID '" + _old_id + "' -> '" + _new_id + "' (references updated)");
    return _new_id;
}

/// @function render_ui_custom_id_field(_field_id, _category, _target_struct, _x1, _y1, _x2, _y2)
/// @description Renders an editable custom ID text box that validates and cascades references upon confirmation.
function render_ui_custom_id_field(_field_id, _category, _target_struct, _x1, _y1, _x2, _y2) {
    if (!is_struct(_target_struct)) return "";
    var _pal = global.palette;
    draw_set_font(fnt_starlight_ui);
    var _is_editing = (global.input.text_input_active && global.input.text_input_id == _field_id);
    var _hover = !global.input.mouse_consumed && input_mouse_in_rect(_x1, _y1, _x2, _y2);
    var _just_committed = (global.input.text_input_committed && global.input.text_input_last_id == _field_id);
    
    if (input_click_in_rect(_x1, _y1, _x2, _y2)) {
        input_begin_text_edit(_field_id, _target_struct.id, 40);
        _is_editing = true;
    } else if (_is_editing && global.input.mb_left_pressed && !input_mouse_in_rect(_x1, _y1, _x2, _y2)) {
        input_end_text_edit();
        _is_editing = false;
        _just_committed = true;
    }
    
    if (_just_committed) {
        editor_rename_resource_id(_category, _target_struct, global.input.text_input_buffer);
        global.input.text_input_last_id = "";
    }
    
    var _disp = _is_editing ? global.input.text_input_buffer : _target_struct.id;
    var _valid = true;
    if (_is_editing) {
        var _chk = editor_validate_custom_id(_disp);
        _valid = _chk.valid;
    }
    
    draw_set_color(_is_editing ? (_valid ? make_color_rgb(28, 34, 64) : make_color_rgb(58, 18, 28)) : make_color_rgb(10, 12, 22));
    draw_rectangle(_x1, _y1, _x2, _y2, false);
    draw_set_color(_is_editing ? (_valid ? _pal.accent_cyan : _pal.accent_red) : (_hover ? _pal.accent_gold : _pal.border_inner));
    draw_rectangle(_x1, _y1, _x2, _y2, true);
    
    var _fit = render_fit_text(_disp, (_x2 - _x1) - 18);
    if (_is_editing && ((global.engine.frame_counter div 20) mod 2 == 0)) _fit += "_";
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_middle);
    draw_set_color(_valid ? _pal.accent_cyan : _pal.accent_red);
    draw_text(_x1 + 8, mean(_y1, _y2), _fit);
    return _target_struct.id;
}

