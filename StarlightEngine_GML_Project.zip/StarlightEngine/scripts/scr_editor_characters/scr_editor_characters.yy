{
  "$GMScript": "v1",
  "%Name": "scr_editor_characters",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_editor_characters",
  "parent": {
    "name": "Editor",
    "path": "folders/Engine/Editor.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}