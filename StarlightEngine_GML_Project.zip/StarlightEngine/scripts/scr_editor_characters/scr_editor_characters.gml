/// @description ST★RLIGHT ENGINE - Character Manager
/// Configures playable characters, custom IDs, sprites, portraits, editable numeric base stats, EXP curves, growth rates, and abilities.

function editor_characters_draw_modal() {
    var _ed = global.editor;
    var _pal = global.palette;
    var _pp_enabled = sys_project_pp_enabled();
    
    if (!is_array(global.project.characters) || array_length(global.project.characters) == 0) {
        global.project.characters = [sys_character_create_default("char_01", "Hero")];
    }
    var _chars = global.project.characters;
    _ed.selected_char_idx = clamp(_ed.selected_char_idx, 0, array_length(_chars) - 1);
    var _ch = _chars[_ed.selected_char_idx];
    
    render_window_frame(96, 36, 1184, 684, "CHARACTER MANAGER — " + _ch.name + " [" + _ch.id + "]", _pal.accent_gold);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    if (render_ui_button(120, 78, 250, 114, "< Prev Hero", false, array_length(_chars) > 1)) {
        input_end_text_edit();
        _ed.selected_char_idx = (_ed.selected_char_idx + array_length(_chars) - 1) mod array_length(_chars);
        return;
    }
    if (render_ui_button(258, 78, 388, 114, "Next Hero >", false, array_length(_chars) > 1)) {
        input_end_text_edit();
        _ed.selected_char_idx = (_ed.selected_char_idx + 1) mod array_length(_chars);
        return;
    }
    if (render_ui_button(398, 78, 598, 114, "+ Create Character", false, true)) {
        input_end_text_edit();
        var _nid = "char_0" + string(array_length(_chars) + 1);
        array_push(_chars, sys_character_create_default(_nid, "Party Member " + string(array_length(_chars) + 1)));
        _ed.selected_char_idx = array_length(_chars) - 1;
        global.project_dirty = true;
        return;
    }
    if (render_ui_button(610, 78, 868, 114, "Open Sprite Manager...", false, true)) {
        input_end_text_edit();
        editor_sprites_open_for_id(_ch.sprite_id);
        return;
    }
    
    // Left Column: Custom ID, Name, Description, Sprites, & Editable Base Statistics
    draw_set_color(_pal.accent_gold);
    draw_text(120, 128, "Custom Character ID:");
    render_ui_custom_id_field("ch_custom_id", "character", _ch, 120, 152, 460, 186);
    
    draw_set_color(_pal.accent_gold);
    draw_text(120, 196, "Character Name:");
    _ch.name = render_ui_text_field("ch_name", 120, 220, 460, 254, _ch.name, 36);
    
    if (!variable_struct_exists(_ch, "sprite_scale")) _ch.sprite_scale = 1.0;
    _ch.sprite_scale = sys_sprite_clamp_scale(_ch.sprite_scale);
    
    draw_text(120, 260, "Description:");
    _ch.description = render_ui_text_field("ch_desc", 120, 282, 460, 314, _ch.description, 90);
    
    // Live Scaled Preview Box + Overworld Sprite ID, Portrait ID, & Character Sprite Scale
    var _ch_fps = core_assets_get_anim_fps(_ch.sprite_id, "Walking", DIR_FACING.DOWN);
    var _ch_frame = global.engine.frame_counter * (_ch_fps / 60.0);
    core_assets_draw_scaled_preview_box(120, 322, 180, 382, _ch.sprite_id, "Walking", _ch_frame, DIR_FACING.DOWN, make_color_rgb(92, 198, 245), _ch.sprite_scale, _pal.accent_gold);
    
    draw_set_color(_pal.accent_gold);
    draw_text(188, 320, "Sprite ID:");
    _ch.sprite_id = render_ui_text_field("ch_spr", 188, 342, 320, 374, _ch.sprite_id, 36);
    draw_text(328, 320, "Portrait ID:");
    _ch.portrait_sprite_id = render_ui_text_field("ch_port", 328, 342, 460, 374, _ch.portrait_sprite_id, 36);
    
    draw_set_color(_pal.accent_cyan);
    draw_text(120, 390, "Char Scale:");
    var _new_ch_sc = render_ui_number_field("ch_scale", 226, 384, 316, 416, _ch.sprite_scale, 0.1, 8.0, true);
    if (_new_ch_sc != _ch.sprite_scale) {
        _ch.sprite_scale = sys_sprite_clamp_scale(_new_ch_sc);
        global.project_dirty = true;
    }
    if (render_ui_button(324, 384, 388, 416, "1.0x", (_ch.sprite_scale == 1.0), true)) {
        _ch.sprite_scale = 1.0;
        global.project_dirty = true;
    }
    if (render_ui_button(394, 384, 460, 416, "2.0x", (_ch.sprite_scale == 2.0), true)) {
        _ch.sprite_scale = 2.0;
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.accent_cyan);
    draw_text(120, 424, "BASE STATISTICS (Click & Type Number):");
    
    draw_set_color(_pal.text_secondary);
    draw_text(120, 448, "Base HP:");
    var _new_hp = render_ui_number_field("ch_num_hp", 120, 470, 284, 502, _ch.max_hp, 1, 9999, false);
    if (_new_hp != _ch.max_hp) { _ch.max_hp = _new_hp; _ch.current_hp = _new_hp; }
    
    if (_pp_enabled) {
        draw_set_color(_pal.text_secondary);
        draw_text(294, 448, "Base PP/MP:");
        var _new_mp = render_ui_number_field("ch_num_mp", 294, 470, 460, 502, _ch.max_mp, 0, 9999, false);
        if (_new_mp != _ch.max_mp) { _ch.max_mp = _new_mp; _ch.current_mp = _new_mp; }
    } else {
        draw_set_color(_pal.text_muted);
        draw_text(294, 474, "(PP/MP Disabled)");
    }
    
    draw_set_color(_pal.text_secondary);
    draw_text(120, 512, "Attack:");
    _ch.attack = render_ui_number_field("ch_num_atk", 120, 534, 226, 566, _ch.attack, 1, 999, false);
    
    draw_set_color(_pal.text_secondary);
    draw_text(236, 512, "Defense:");
    _ch.defense = render_ui_number_field("ch_num_def", 236, 534, 342, 566, _ch.defense, 0, 999, false);
    
    draw_set_color(_pal.text_secondary);
    draw_text(352, 512, "Speed:");
    _ch.speed = render_ui_number_field("ch_num_spd", 352, 534, 460, 566, _ch.speed, 1, 999, false);
    
    // Right Column: Editable Numeric Leveling Curve & Abilities
    draw_set_color(_pal.accent_gold);
    draw_text(496, 128, "LEVELING & EXP PROGRESSION CURVE (Editable Numbers):");
    
    draw_set_color(_pal.text_secondary);
    draw_text(496, 156, "Base EXP:");
    _ch.exp_base = render_ui_number_field("ch_num_expb", 496, 180, 680, 214, _ch.exp_base, 5, 9999, false);
    
    draw_set_color(_pal.text_secondary);
    draw_text(704, 156, "Curve Factor (1.0..3.0):");
    _ch.exp_curve_factor = render_ui_number_field("ch_num_expc", 704, 180, 916, 214, _ch.exp_curve_factor, 1.0, 3.0, true);
    
    draw_set_color(_pal.text_secondary);
    draw_text(940, 156, "HP Growth:");
    _ch.growth_hp = render_ui_number_field("ch_num_ghp", 940, 180, 1156, 214, _ch.growth_hp, 0, 999, false);
    
    draw_set_color(_pal.text_secondary);
    if (_pp_enabled) {
        draw_text(496, 226, "PP Growth:");
        _ch.growth_mp = render_ui_number_field("ch_num_gmp", 600, 222, 696, 254, _ch.growth_mp, 0, 999, false);
    }
    draw_text(712, 226, "ATK+/Lv:");
    _ch.growth_attack = render_ui_number_field("ch_num_gatk", 796, 222, 876, 254, _ch.growth_attack, 0, 99, false);
    draw_text(892, 226, "DEF+/Lv:");
    _ch.growth_defense = render_ui_number_field("ch_num_gdef", 976, 222, 1156, 254, _ch.growth_defense, 0, 99, false);
    
    draw_set_color(_pal.accent_cyan);
    draw_text(496, 274, "CHARACTER ABILITIES (" + string(array_length(_ch.abilities)) + "):");
    for (var a = 0; a < min(3, array_length(_ch.abilities)); a++) {
        var _ab = _ch.abilities[a];
        var _ay1 = 302 + a * 88;
        draw_set_color(_pal.panel_alt);
        draw_rectangle(496, _ay1, 1156, _ay1 + 80, false);
        draw_set_color(_pal.border_inner);
        draw_rectangle(496, _ay1, 1156, _ay1 + 80, true);
        
        _ab.name = render_ui_text_field("ch_ab_name_" + string(a), 506, _ay1 + 6, 710, _ay1 + 38, _ab.name, 32);
        
        draw_set_color(_pal.text_secondary);
        draw_text(720, _ay1 + 12, "Lv:");
        _ab.level_req = render_ui_number_field("ch_ab_lv_" + string(a), 754, _ay1 + 6, 822, _ay1 + 38, _ab.level_req, 1, 99, false);
        
        if (_pp_enabled) {
            draw_set_color(_pal.text_secondary);
            draw_text(832, _ay1 + 12, "PP:");
            _ab.mp_cost = render_ui_number_field("ch_ab_mp_" + string(a), 868, _ay1 + 6, 940, _ay1 + 38, _ab.mp_cost, 0, 999, false);
        }
        
        draw_set_color(_pal.text_secondary);
        draw_text(950, _ay1 + 12, "Pow:");
        _ab.power = render_ui_number_field("ch_ab_pw_" + string(a), 998, _ay1 + 6, 1084, _ay1 + 38, _ab.power, 0, 9999, false);
        
        if (render_ui_button(1092, _ay1 + 6, 1148, _ay1 + 38, "Del", false, array_length(_ch.abilities) > 1)) {
            array_delete(_ch.abilities, a, 1);
            global.project_dirty = true;
            return;
        }
        
        _ab.description = render_ui_text_field("ch_ab_desc_" + string(a), 506, _ay1 + 44, 1148, _ay1 + 74, _ab.description, 80);
    }
    
    if (render_ui_button(496, 574, 740, 614, "+ Add New Ability", false, true)) {
        array_push(_ch.abilities, {
            id: "abil_custom_" + string(array_length(_ch.abilities) + 1),
            name: "Star Burst",
            description: "Unleashes radiant starlight energy.",
            level_req: array_length(_ch.abilities) + 1,
            mp_cost: 6,
            power: 28,
            is_healing: false,
            target_type: "single_enemy",
            status_effect: ""
        });
        global.project_dirty = true;
    }
    
    if (render_ui_button(956, 624, 1156, 664, "Done (Esc)", true, true)) {
        input_end_text_edit();
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}
