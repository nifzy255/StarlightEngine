{
  "$GMScript": "v1",
  "%Name": "scr_core_config",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_core_config",
  "parent": {
    "name": "Core",
    "path": "folders/Engine/Core.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}