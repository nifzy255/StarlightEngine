/// @description ST★RLIGHT ENGINE - Global Engine Configuration & Display Scaling
/// Manages user settings (volume, window scale, fullscreen, grid defaults, controls) and persistence.

function core_config_init() {
    global.config = {
        music_volume: 0.80,
        sfx_volume: 0.85,
        window_scale: 1,
        fullscreen: false,
        vsync: true,
        show_fps: false,
        text_speed: 1.0,
        default_grid_size: 32,
        ui_scale: 1.0,
        gui_width: STARLIGHT_BASE_WIDTH,
        gui_height: STARLIGHT_BASE_HEIGHT,
        key_up: ord("W"),
        key_down: ord("S"),
        key_left: ord("A"),
        key_right: ord("D"),
        key_interact: ord("E"),
        key_cancel: vk_shift,
        key_menu: vk_escape
    };
    
    core_config_load();
    core_config_apply_display();
}

function core_config_get_path() {
    return game_save_id + "engine_settings.json";
}

function core_config_save() {
    try {
        var _json = json_stringify(global.config, true);
        var _buf = buffer_create(string_byte_length(_json) + 1, buffer_fixed, 1);
        buffer_write(_buf, buffer_text, _json);
        buffer_save(_buf, core_config_get_path());
        buffer_delete(_buf);
        return true;
    } catch (_err) {
        core_log_error("core_config_save", "Failed to save engine settings: " + string(_err));
        return false;
    }
}

function core_config_load() {
    var _path = core_config_get_path();
    if (!file_exists(_path)) return false;
    try {
        var _buf = buffer_load(_path);
        if (_buf < 0) return false;
        var _json = buffer_read(_buf, buffer_text);
        buffer_delete(_buf);
        var _loaded = json_parse(_json);
        if (is_struct(_loaded)) {
            var _keys = variable_struct_get_names(_loaded);
            for (var i = 0; i < array_length(_keys); i++) {
                var _k = _keys[i];
                if (variable_struct_exists(global.config, _k)) {
                    variable_struct_set(global.config, _k, variable_struct_get(_loaded, _k));
                }
            }
            return true;
        }
    } catch (_err) {
        core_log_error("core_config_load", "Corrupted settings file, reverting to defaults: " + string(_err));
    }
    return false;
}

function core_config_apply_display() {
    display_set_gui_size(STARLIGHT_BASE_WIDTH, STARLIGHT_BASE_HEIGHT);
    window_set_fullscreen(global.config.fullscreen);
    if (!global.config.fullscreen) {
        var _scale = clamp(global.config.window_scale, 1, 2);
        var _w = round(STARLIGHT_BASE_WIDTH * (_scale == 1 ? 1.0 : 1.25));
        var _h = round(STARLIGHT_BASE_HEIGHT * (_scale == 1 ? 1.0 : 1.25));
        if (window_get_width() != _w || window_get_height() != _h) {
            window_set_size(_w, _h);
        }
    }
}
