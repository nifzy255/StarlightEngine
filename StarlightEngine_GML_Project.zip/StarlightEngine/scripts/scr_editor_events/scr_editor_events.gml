/// @description ST★RLIGHT ENGINE - Visual Event Editor
/// Places/erases map event triggers and provides a visual command list editor for all 34 Event Commands.

function editor_events_place_at(_map, _gx, _gy) {
    if (!is_struct(_map)) return;
    // If an event already exists at (_gx, _gy), open it for inspection
    if (editor_events_inspect_at(_map, _gx, _gy)) return;
    
    var _new_id = "ev_" + string(array_length(_map.events) + 1) + "_" + string(_gx) + "_" + string(_gy);
    var _ev = {
        id: _new_id,
        name: "Event " + string(array_length(_map.events) + 1),
        grid_x: _gx,
        grid_y: _gy,
        grid_w: 1,
        grid_h: 1,
        trigger_mode: EVENT_TRIGGER_MODE.AUTOMATIC,
        one_time: false,
        condition_var: "",
        condition_val: true,
        commands: [
            sys_event_create_command("display_dialogue", "An event was triggered!", "")
        ]
    };
    array_push(_map.events, _ev);
    global.project_dirty = true;
    core_log_toast("Placed " + _ev.name + " (Right-click to edit commands)");
}

function editor_events_remove_at(_map, _gx, _gy) {
    if (!is_struct(_map) || !is_array(_map.events)) return;
    for (var i = array_length(_map.events) - 1; i >= 0; i--) {
        var _ev = _map.events[i];
        if (_gx >= _ev.grid_x && _gx < (_ev.grid_x + max(1, _ev.grid_w)) &&
            _gy >= _ev.grid_y && _gy < (_ev.grid_y + max(1, _ev.grid_h))) {
            var _ename = _ev.name;
            array_delete(_map.events, i, 1);
            global.project_dirty = true;
            core_log_toast("Removed " + _ename);
            return;
        }
    }
}

function editor_events_inspect_at(_map, _gx, _gy) {
    if (!is_struct(_map) || !is_array(_map.events)) return false;
    for (var i = 0; i < array_length(_map.events); i++) {
        var _ev = _map.events[i];
        if (_gx >= _ev.grid_x && _gx < (_ev.grid_x + max(1, _ev.grid_w)) &&
            _gy >= _ev.grid_y && _gy < (_ev.grid_y + max(1, _ev.grid_h))) {
            global.editor.inspect_event = _ev;
            global.editor.active_modal = EDITOR_MODAL.EVENT_INSPECTOR;
            input_consume_all();
            return true;
        }
    }
    return false;
}

function editor_events_draw_inspector_modal(_map) {
    var _ed = global.editor;
    var _pal = global.palette;
    var _ev = _ed.inspect_event;
    if (!is_struct(_ev)) {
        _ed.active_modal = EDITOR_MODAL.NONE;
        return;
    }
    
    render_window_frame(120, 48, 1160, 672, "VISUAL EVENT EDITOR — " + _ev.name, _pal.accent_cyan);
    
    // Left Column: Event Properties, Custom Event ID, & Trigger Conditions
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(_pal.accent_gold);
    draw_text(144, 88, "Custom Event ID:");
    render_ui_custom_id_field("ev_custom_id", "event", _ev, 144, 110, 440, 142);
    
    draw_set_color(_pal.accent_gold);
    draw_text(144, 150, "Event Name:");
    _ev.name = render_ui_text_field("ev_name", 144, 172, 440, 204, _ev.name, 40);
    
    draw_set_color(_pal.text_secondary);
    draw_text(144, 214, "Zone W:");
    _ev.grid_w = render_ui_number_field("ev_gw", 224, 210, 286, 240, _ev.grid_w, 1, 32, false);
    draw_text(298, 214, "Zone H:");
    _ev.grid_h = render_ui_number_field("ev_gh", 374, 210, 440, 240, _ev.grid_h, 1, 32, false);
    
    var _tmode_names = ["Automatic (Step On)", "Player Interaction (E)", "Conditional Trigger"];
    var _tmode_lbl = "Trigger: " + _tmode_names[clamp(_ev.trigger_mode, 0, 2)];
    if (render_ui_button(144, 238, 440, 274, _tmode_lbl, false, true)) {
        _ev.trigger_mode = (_ev.trigger_mode + 1) mod 3;
        global.project_dirty = true;
    }
    
    var _rep_lbl = _ev.one_time ? "Activation: One-Time Only" : "Activation: Repeatable";
    if (render_ui_button(144, 282, 440, 318, _rep_lbl, _ev.one_time, true)) {
        _ev.one_time = !_ev.one_time;
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.accent_gold);
    draw_text(144, 332, "Required Variable (Optional):");
    _ev.condition_var = render_ui_text_field("ev_cond_var", 144, 356, 440, 390, _ev.condition_var, 36);
    
    // Command Catalog Adder
    var _catalog = sys_event_get_command_catalog();
    var _cat_count = array_length(_catalog);
    _ed.selected_cmd_catalog_idx = clamp(_ed.selected_cmd_catalog_idx, 0, _cat_count - 1);
    var _cat_entry = _catalog[_ed.selected_cmd_catalog_idx];
    
    draw_set_color(_pal.accent_cyan);
    draw_text(144, 412, "ADD COMMAND (" + string(_ed.selected_cmd_catalog_idx + 1) + "/" + string(_cat_count) + "):");
    draw_set_color(_pal.text_primary);
    draw_text(144, 436, "[" + _cat_entry.category + "] " + _cat_entry.label);
    
    if (render_ui_button(144, 464, 238, 500, "< Prev Cmd", false, true)) {
        _ed.selected_cmd_catalog_idx = (_ed.selected_cmd_catalog_idx + _cat_count - 1) mod _cat_count;
    }
    if (render_ui_button(246, 464, 340, 500, "Next Cmd >", false, true)) {
        _ed.selected_cmd_catalog_idx = (_ed.selected_cmd_catalog_idx + 1) mod _cat_count;
    }
    if (render_ui_button(348, 464, 440, 500, "+ Append", true, true)) {
        array_push(_ev.commands, sys_event_create_command(_cat_entry.cmd, _cat_entry.default_p1, _cat_entry.default_p2));
        global.project_dirty = true;
    }
    
    // Right Column: Command Sequence List (Reorder, Configure Parameters, Remove)
    draw_set_color(_pal.accent_gold);
    draw_text(468, 92, "COMMAND EXECUTION SEQUENCE (" + string(array_length(_ev.commands)) + " commands):");
    
    var _max_vis = min(6, array_length(_ev.commands));
    for (var c = 0; c < _max_vis; c++) {
        var _cmd_obj = _ev.commands[c];
        var _cy1 = 120 + c * 78;
        var _cy2 = _cy1 + 70;
        
        draw_set_color(_pal.panel_alt);
        draw_rectangle(468, _cy1, 1136, _cy2, false);
        draw_set_color(_pal.border_inner);
        draw_rectangle(468, _cy1, 1136, _cy2, true);
        
        draw_set_color(_pal.accent_cyan);
        draw_text(478, _cy1 + 6, "#" + string(c + 1) + ": " + _cmd_obj.cmd);
        
        // Parameter 1 & Parameter 2 text fields
        _cmd_obj.p1 = render_ui_text_field("ev_cmd_p1_" + string(c), 478, _cy1 + 30, 740, _cy1 + 62, _cmd_obj.p1, 90);
        _cmd_obj.p2 = render_ui_text_field("ev_cmd_p2_" + string(c), 750, _cy1 + 30, 960, _cy1 + 62, _cmd_obj.p2, 90);
        
        // Reorder Up / Down & Delete Command buttons
        if (render_ui_button(970, _cy1 + 30, 1014, _cy1 + 62, "▲", false, c > 0)) {
            var _tmp = _ev.commands[c - 1];
            _ev.commands[c - 1] = _ev.commands[c];
            _ev.commands[c] = _tmp;
            global.project_dirty = true;
        }
        if (render_ui_button(1020, _cy1 + 30, 1064, _cy1 + 62, "▼", false, c + 1 < array_length(_ev.commands))) {
            var _tmp2 = _ev.commands[c + 1];
            _ev.commands[c + 1] = _ev.commands[c];
            _ev.commands[c] = _tmp2;
            global.project_dirty = true;
        }
        if (render_ui_button(1070, _cy1 + 30, 1128, _cy1 + 62, "Del", false, true)) {
            array_delete(_ev.commands, c, 1);
            global.project_dirty = true;
            return;
        }
    }
    
    if (render_ui_button(936, 614, 1136, 654, "Done (Esc)", true, true)) {
        input_end_text_edit();
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}
