/// @description ST★RLIGHT ENGINE - Item Manager
/// Creates and configures Items with editable custom IDs, validated numeric fields, and multi-entry Event Commands (Event ID + Param 1 + Param 2).

function editor_items_ensure_default() {
    if (is_undefined(global.project)) return;
    if (!is_array(global.project.items) || array_length(global.project.items) == 0) {
        global.project.items = [
            sys_item_create_default("item_star_burger", "Star Burger", ITEM_CATEGORY.HEALING)
        ];
    }
    for (var i = 0; i < array_length(global.project.items); i++) {
        var _it = global.project.items[i];
        if (!variable_struct_exists(_it, "event_commands") || !is_array(_it.event_commands)) {
            _it.event_commands = [];
        }
    }
}

function editor_items_draw_modal() {
    var _ed = global.editor;
    var _pal = global.palette;
    var _pp_enabled = sys_project_pp_enabled();
    editor_items_ensure_default();
    
    var _items = global.project.items;
    _ed.selected_item_idx = clamp(_ed.selected_item_idx, 0, array_length(_items) - 1);
    var _it = _items[_ed.selected_item_idx];
    
    render_window_frame(96, 36, 1184, 684, "ITEM MANAGER — " + _it.name + " [" + _it.id + "]", _pal.accent_gold);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    if (render_ui_button(120, 78, 250, 114, "< Prev Item", false, array_length(_items) > 1)) {
        input_end_text_edit();
        _ed.selected_item_idx = (_ed.selected_item_idx + array_length(_items) - 1) mod array_length(_items);
        _ed.item_ev_scroll = 0;
        return;
    }
    if (render_ui_button(258, 78, 388, 114, "Next Item >", false, array_length(_items) > 1)) {
        input_end_text_edit();
        _ed.selected_item_idx = (_ed.selected_item_idx + 1) mod array_length(_items);
        _ed.item_ev_scroll = 0;
        return;
    }
    if (render_ui_button(398, 78, 578, 114, "+ Create Item", false, true)) {
        input_end_text_edit();
        var _nid = "item_0" + string(array_length(_items) + 1);
        array_push(_items, sys_item_create_default(_nid, "New Item " + string(array_length(_items) + 1), ITEM_CATEGORY.CONSUMABLE));
        _ed.selected_item_idx = array_length(_items) - 1;
        _ed.item_ev_scroll = 0;
        global.project_dirty = true;
        return;
    }
    if (render_ui_button(588, 78, 748, 114, "Delete Item", false, array_length(_items) > 1)) {
        input_end_text_edit();
        array_delete(_items, _ed.selected_item_idx, 1);
        _ed.selected_item_idx = 0;
        global.project_dirty = true;
        return;
    }
    
    // Left Column: Custom ID, Name, Description, Category, Editable Numeric Fields
    draw_set_color(_pal.accent_gold);
    draw_text(120, 130, "Custom Item ID:");
    render_ui_custom_id_field("it_custom_id", "item", _it, 120, 154, 460, 188);
    
    draw_set_color(_pal.accent_gold);
    draw_text(120, 200, "Item Name:");
    _it.name = render_ui_text_field("it_name", 120, 224, 460, 258, _it.name, 40);
    
    draw_text(120, 270, "Description:");
    _it.description = render_ui_text_field("it_desc", 120, 294, 460, 328, _it.description, 100);
    
    var _cat_names = ["Consumable", "Healing Item", "Weapon", "Armor", "Accessory", "Key Item"];
    if (render_ui_button(120, 342, 460, 378, "Category: " + _cat_names[clamp(_it.category, 0, 5)], false, true)) {
        _it.category = (_it.category + 1) mod 6;
        global.project_dirty = true;
    }
    
    // Editable Numeric Price & Max Stack
    draw_set_color(_pal.accent_cyan);
    draw_text(120, 394, "Price ($):");
    _it.price = render_ui_number_field("it_price", 120, 418, 282, 452, _it.price, 0, 99999, false);
    
    draw_set_color(_pal.accent_cyan);
    draw_text(296, 394, "Max Stack:");
    _it.max_stack = render_ui_number_field("it_stack", 296, 418, 460, 452, _it.max_stack, 1, 999, false);
    
    if (render_ui_button(120, 466, 282, 502, "Field Use: " + (_it.usable_field ? "YES" : "NO"), _it.usable_field, true)) {
        _it.usable_field = !_it.usable_field;
        global.project_dirty = true;
    }
    if (render_ui_button(296, 466, 460, 502, "Battle Use: " + (_it.usable_battle ? "YES" : "NO"), _it.usable_battle, true)) {
        _it.usable_battle = !_it.usable_battle;
        global.project_dirty = true;
    }
    
    // Right Column Top: Editable Numeric Healing & Equipment Bonuses
    draw_set_color(_pal.accent_cyan);
    draw_text(496, 130, "CONSUMABLE & HEALING EFFECTS (Editable Numbers):");
    
    draw_set_color(_pal.text_secondary);
    draw_text(496, 156, "HP Restore:");
    _it.hp_restore = render_ui_number_field("it_hp_rest", 496, 180, 668, 214, _it.hp_restore, 0, 9999, false);
    
    if (_pp_enabled) {
        draw_set_color(_pal.text_secondary);
        draw_text(684, 156, "PP/MP Restore:");
        _it.mp_restore = render_ui_number_field("it_mp_rest", 684, 180, 868, 214, _it.mp_restore, 0, 9999, false);
    } else {
        draw_set_color(_pal.text_muted);
        draw_text(684, 186, "(PP/MP Disabled)");
    }
    
    if (render_ui_button(884, 180, 1156, 214, "Revive Fallen: " + (_it.revive ? "YES" : "NO"), _it.revive, true)) {
        _it.revive = !_it.revive;
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.accent_cyan);
    draw_text(496, 230, "EQUIPMENT STAT BONUSES (Supports +/- Values):");
    
    draw_set_color(_pal.text_secondary);
    draw_text(496, 256, "Bonus ATK:");
    _it.bonus_attack = render_ui_number_field("it_b_atk", 496, 280, 696, 314, _it.bonus_attack, -999, 999, false);
    
    draw_set_color(_pal.text_secondary);
    draw_text(716, 256, "Bonus DEF:");
    _it.bonus_defense = render_ui_number_field("it_b_def", 716, 280, 916, 314, _it.bonus_defense, -999, 999, false);
    
    draw_set_color(_pal.text_secondary);
    draw_text(936, 256, "Bonus SPD:");
    _it.bonus_speed = render_ui_number_field("it_b_spd", 936, 280, 1156, 314, _it.bonus_speed, -999, 999, false);
    
    // Right Column Bottom: Full Item Event Configuration (Map Event ID + Multi-Entry Event Commands with 3 Entries!)
    draw_set_color(_pal.accent_gold);
    draw_text(496, 332, "ON-USE EVENT CONFIGURATION (Map Event ID & Multi-Entry Commands):");
    
    draw_set_color(_pal.text_secondary);
    draw_text(496, 360, "Map Event ID:");
    _it.trigger_event_id = render_ui_text_field("it_trig_ev", 636, 356, 916, 388, _it.trigger_event_id, 40);
    
    // Command Catalog Selector & Adder for Item Event Commands
    var _catalog = sys_event_get_command_catalog();
    var _cat_count = array_length(_catalog);
    _ed.selected_cmd_catalog_idx = clamp(_ed.selected_cmd_catalog_idx, 0, _cat_count - 1);
    var _cat_entry = _catalog[_ed.selected_cmd_catalog_idx];
    
    if (render_ui_button(926, 356, 962, 388, "<", false, true)) {
        _ed.selected_cmd_catalog_idx = (_ed.selected_cmd_catalog_idx + _cat_count - 1) mod _cat_count;
    }
    if (render_ui_button(966, 356, 1002, 388, ">", false, true)) {
        _ed.selected_cmd_catalog_idx = (_ed.selected_cmd_catalog_idx + 1) mod _cat_count;
    }
    if (render_ui_button(1008, 356, 1156, 388, "+ Add Entry", true, true)) {
        array_push(_it.event_commands, sys_event_create_command(_cat_entry.cmd, _cat_entry.default_p1, _cat_entry.default_p2));
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.accent_cyan);
    draw_text(496, 396, "Selected Template: [" + _cat_entry.cmd + "] — P1: " + (_cat_entry.p1_name != "" ? _cat_entry.p1_name : "None") + " | P2: " + (_cat_entry.p2_name != "" ? _cat_entry.p2_name : "None"));
    
    // Column headers clearly distinguishing Entry 1 (Event/Command ID), Entry 2 (Param 1), and Entry 3 (Param 2)
    draw_set_color(_pal.accent_gold);
    draw_text(496, 422, "1. Event / Command ID");
    draw_text(712, 422, "2. Parameter 1 (Arg 1)");
    draw_text(928, 422, "3. Parameter 2 (Arg 2)");
    
    var _ec_list = _it.event_commands;
    var _ec_count = array_length(_ec_list);
    var _vis_ec = 3;
    _ed.item_ev_scroll = clamp(_ed.item_ev_scroll, 0, max(0, _ec_count - _vis_ec));
    
    if (_ec_count == 0) {
        draw_set_color(_pal.text_muted);
        draw_text(496, 456, "No item event commands yet. Click '+ Add Entry' above to add one.");
    } else {
        for (var e = 0; e < min(_vis_ec, _ec_count - _ed.item_ev_scroll); e++) {
            var _eidx = _ed.item_ev_scroll + e;
            var _ec = _ec_list[_eidx];
            var _ey1 = 448 + e * 52;
            var _ey2 = _ey1 + 44;
            
            draw_set_color(_pal.panel_alt);
            draw_rectangle(496, _ey1, 1142, _ey2, false);
            draw_set_color(_pal.border_inner);
            draw_rectangle(496, _ey1, 1142, _ey2, true);
            
            // Entry 1: Event / Command ID
            _ec.cmd = render_ui_text_field("it_ec_cmd_" + string(_eidx), 502, _ey1 + 6, 704, _ey2 - 6, _ec.cmd, 40);
            // Entry 2: Parameter 1
            _ec.p1 = render_ui_text_field("it_ec_p1_" + string(_eidx), 712, _ey1 + 6, 920, _ey2 - 6, _ec.p1, 80);
            // Entry 3: Parameter 2
            _ec.p2 = render_ui_text_field("it_ec_p2_" + string(_eidx), 928, _ey1 + 6, 1088, _ey2 - 6, _ec.p2, 80);
            
            if (render_ui_button(1094, _ey1 + 6, 1138, _ey2 - 6, "Del", false, true)) {
                array_delete(_ec_list, _eidx, 1);
                global.project_dirty = true;
                return;
            }
        }
        render_scrollbar(1148, 448, 448 + _vis_ec * 52 - 8, _ec_count, _vis_ec, _ed.item_ev_scroll);
    }
    
    if (render_ui_button(496, 616, 580, 656, "▲ Up", false, _ed.item_ev_scroll > 0)) {
        _ed.item_ev_scroll--;
    }
    if (render_ui_button(588, 616, 680, 656, "▼ Down", false, _ed.item_ev_scroll + _vis_ec < _ec_count)) {
        _ed.item_ev_scroll++;
    }
    
    if (render_ui_button(956, 616, 1156, 656, "Done (Esc)", true, true)) {
        input_end_text_edit();
        _ed.active_modal = EDITOR_MODAL.NONE;
    }
}
