{
  "$GMScript": "v1",
  "%Name": "scr_editor_items",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_editor_items",
  "parent": {
    "name": "Editor",
    "path": "folders/Engine/Editor.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}