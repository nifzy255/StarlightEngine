/// @description ST★RLIGHT ENGINE - Pixel-Art Rendering & UI Primitives
/// Implements EarthBound/Undertale-inspired rectangular frames, buttons, text fields, validated numeric fields, and scrollbars.

function core_render_init() {
    global.palette = {
        space_dark: make_color_rgb(6, 7, 18),
        space_navy: make_color_rgb(13, 17, 38),
        panel_bg: make_color_rgb(14, 16, 30),
        panel_alt: make_color_rgb(22, 26, 48),
        panel_header: make_color_rgb(30, 36, 68),
        border_outer: make_color_rgb(235, 240, 255),
        border_inner: make_color_rgb(95, 112, 168),
        accent_gold: make_color_rgb(255, 214, 74),
        accent_cyan: make_color_rgb(92, 225, 230),
        accent_magenta: make_color_rgb(235, 94, 168),
        accent_green: make_color_rgb(98, 224, 132),
        accent_red: make_color_rgb(242, 84, 91),
        text_primary: make_color_rgb(244, 246, 255),
        text_secondary: make_color_rgb(168, 178, 210),
        text_muted: make_color_rgb(108, 118, 150)
    };
}

function render_starfield_bg() {
    var _pal = global.palette;
    draw_rectangle_color(0, 0, STARLIGHT_BASE_WIDTH, STARLIGHT_BASE_HEIGHT,
        _pal.space_dark, _pal.space_dark, _pal.space_navy, _pal.space_navy, false);
    
    if (!variable_global_exists("starfield") || is_undefined(global.starfield)) return;
    var _stars = global.starfield.stars;
    var _len = array_length(_stars);
    var _old_alpha = draw_get_alpha();
    var _old_col = draw_get_color();
    
    for (var i = 0; i < _len; i++) {
        var _s = _stars[i];
        var _twinkle = 0.75 + 0.25 * sin(_s.twinkle_phase);
        draw_set_alpha(clamp(_s.alpha * _twinkle, 0.1, 1.0));
        draw_set_color(_s.color);
        if (_s.size <= 1) {
            draw_point(_s.x, _s.y);
        } else {
            draw_rectangle(_s.x, _s.y, _s.x + _s.size - 1, _s.y + _s.size - 1, false);
        }
    }
    
    draw_set_alpha(_old_alpha);
    draw_set_color(_old_col);
}

/// @function render_window_frame(_x1, _y1, _x2, _y2, _title, _accent_col)
/// @description Draws an EarthBound/Undertale-style double-bordered pixel window.
function render_window_frame(_x1, _y1, _x2, _y2, _title, _accent_col) {
    var _pal = global.palette;
    var _border = is_undefined(_accent_col) ? _pal.border_outer : _accent_col;
    draw_set_font(fnt_starlight_ui);
    
    // Drop shadow
    draw_set_alpha(0.45);
    draw_set_color(c_black);
    draw_rectangle(_x1 + 4, _y1 + 4, _x2 + 4, _y2 + 4, false);
    draw_set_alpha(1.0);
    
    // Fill background
    draw_set_color(_pal.panel_bg);
    draw_rectangle(_x1, _y1, _x2, _y2, false);
    
    // Optional title header bar (34px height for larger readable font)
    if (!is_undefined(_title) && _title != "") {
        draw_set_color(_pal.panel_header);
        draw_rectangle(_x1 + 3, _y1 + 3, _x2 - 3, _y1 + 34, false);
        draw_set_color(_pal.border_inner);
        draw_line(_x1 + 3, _y1 + 34, _x2 - 3, _y1 + 34);
        
        draw_set_halign(fa_left);
        draw_set_valign(fa_middle);
        draw_set_color(_pal.accent_gold);
        draw_text(_x1 + 12, _y1 + 19, render_fit_text(_title, (_x2 - _x1) - 24));
    }
    
    // Outer crisp pixel border (2px)
    draw_set_color(_border);
    draw_rectangle(_x1, _y1, _x2, _y2, true);
    draw_rectangle(_x1 + 1, _y1 + 1, _x2 - 1, _y2 - 1, true);
    
    // Inner subtle border
    draw_set_color(_pal.border_inner);
    draw_rectangle(_x1 + 3, _y1 + 3, _x2 - 3, _y2 - 3, true);
}

/// @function render_fit_text(_text, _max_width)
/// @description Truncates text with "..." if it exceeds container width, preventing text overlap.
function render_fit_text(_text, _max_width) {
    var _str = string(_text);
    if (_max_width <= 8) return "";
    if (string_width(_str) <= _max_width) return _str;
    var _len = string_length(_str);
    while (_len > 1 && string_width(string_copy(_str, 1, _len) + "...") > _max_width) {
        _len--;
    }
    return string_copy(_str, 1, max(1, _len)) + "...";
}

/// @function render_ui_button(_x1, _y1, _x2, _y2, _label, _is_selected, _is_enabled)
/// @description Draws an interactive pixel button and returns true if clicked.
function render_ui_button(_x1, _y1, _x2, _y2, _label, _is_selected, _is_enabled) {
    var _pal = global.palette;
    draw_set_font(fnt_starlight_ui);
    var _enabled = is_undefined(_is_enabled) ? true : _is_enabled;
    var _selected = is_undefined(_is_selected) ? false : _is_selected;
    var _hover = _enabled && !global.input.mouse_consumed && input_mouse_in_rect(_x1, _y1, _x2, _y2);
    var _active = _selected || _hover;
    
    var _bg = _pal.panel_alt;
    if (!_enabled) {
        _bg = make_color_rgb(16, 18, 28);
    } else if (_active) {
        _bg = make_color_rgb(40, 48, 88);
    }
    
    draw_set_color(_bg);
    draw_rectangle(_x1, _y1, _x2, _y2, false);
    
    var _border_col = !_enabled ? _pal.text_muted : (_active ? _pal.accent_gold : _pal.border_inner);
    draw_set_color(_border_col);
    draw_rectangle(_x1, _y1, _x2, _y2, true);
    if (_active && _enabled) {
        draw_rectangle(_x1 + 1, _y1 + 1, _x2 - 1, _y2 - 1, true);
    }
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_middle);
    var _cy = mean(_y1, _y2);
    var _text_x = _x1 + 10;
    
    if (_active && _enabled) {
        draw_set_color(_pal.accent_gold);
        draw_text(_x1 + 6, _cy, "★");
        _text_x = _x1 + 24;
    }
    
    draw_set_color(!_enabled ? _pal.text_muted : (_active ? _pal.text_primary : _pal.text_secondary));
    draw_text(_text_x, _cy, render_fit_text(_label, (_x2 - _text_x) - 6));
    
    if (_enabled && input_click_in_rect(_x1, _y1, _x2, _y2)) {
        var _ulbl = string_upper(string_trim(string(_label)));
        if (_ulbl == "YES" || _ulbl == "NO") {
            // Choice buttons trigger dedicated choice_yes / choice_no in sys_dialogue_select_choice
        } else if (_ulbl == "CANCEL" || string_pos("BACK ", _ulbl) == 1 || string_pos("RESUME ", _ulbl) == 1) {
            core_audio_play_default_sound("menu_cancel");
        } else {
            core_audio_play_default_sound("menu_confirm");
        }
        return true;
    }
    return false;
}

/// @function render_ui_text_field(_id, _x1, _y1, _x2, _y2, _current_val, _max_len)
/// @description Renders an editable single-line text box and returns updated string value. Supports Esc to cancel.
function render_ui_text_field(_id, _x1, _y1, _x2, _y2, _current_val, _max_len) {
    var _pal = global.palette;
    draw_set_font(fnt_starlight_ui);
    var _is_editing = (global.input.text_input_active && global.input.text_input_id == _id);
    var _hover = !global.input.mouse_consumed && input_mouse_in_rect(_x1, _y1, _x2, _y2);
    
    // Check if user pressed Escape while editing this field
    if (global.input.text_input_cancelled && global.input.text_input_last_id == _id) {
        _current_val = global.input.text_input_original;
    }
    
    if (input_click_in_rect(_x1, _y1, _x2, _y2)) {
        input_begin_text_edit(_id, _current_val, _max_len);
        _is_editing = true;
    } else if (_is_editing && global.input.mb_left_pressed && !input_mouse_in_rect(_x1, _y1, _x2, _y2)) {
        input_end_text_edit();
        _is_editing = false;
    }
    
    var _val = _is_editing ? global.input.text_input_buffer : string(_current_val);
    
    draw_set_color(_is_editing ? make_color_rgb(28, 34, 64) : make_color_rgb(10, 12, 22));
    draw_rectangle(_x1, _y1, _x2, _y2, false);
    
    draw_set_color(_is_editing ? _pal.accent_cyan : (_hover ? _pal.border_outer : _pal.border_inner));
    draw_rectangle(_x1, _y1, _x2, _y2, true);
    
    var _display = render_fit_text(_val, (_x2 - _x1) - 18);
    if (_is_editing && ((global.engine.frame_counter div 20) mod 2 == 0)) {
        _display += "_";
    }
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_middle);
    draw_set_color(_pal.text_primary);
    draw_text(_x1 + 8, mean(_y1, _y2), _display);
    
    return _val;
}

/// @function render_validate_number_string(_str, _min_val, _max_val, _is_decimal)
/// @description Validates whether a typed string is a well-formed number within allowed sign/decimal rules.
function render_validate_number_string(_str, _min_val, _max_val, _is_decimal) {
    var _s = string_trim(string(_str));
    if (_s == "" || _s == "-" || _s == "." || _s == "-.") return { valid: false, value: 0, reason: "Empty number" };
    
    var _len = string_length(_s);
    var _dot_count = 0;
    for (var i = 1; i <= _len; i++) {
        var _c = string_char_at(_s, i);
        if (_c == "-") {
            if (i != 1 || _min_val >= 0) {
                return { valid: false, value: 0, reason: "Negative values not allowed here" };
            }
        } else if (_c == ".") {
            if (!_is_decimal) {
                return { valid: false, value: 0, reason: "Whole integer required" };
            }
            _dot_count++;
            if (_dot_count > 1) {
                return { valid: false, value: 0, reason: "Multiple decimal points" };
            }
        } else {
            var _code = ord(_c);
            if (_code < ord("0") || _code > ord("9")) {
                return { valid: false, value: 0, reason: "Non-numeric character" };
            }
        }
    }
    
    var _num = real(_s);
    var _out_of_range = (_num < _min_val || _num > _max_val);
    var _clamped = clamp(_num, _min_val, _max_val);
    if (!_is_decimal) _clamped = round(_clamped);
    return {
        valid: true,
        in_bounds: !_out_of_range,
        value: _clamped,
        raw_value: _num,
        reason: _out_of_range ? ("Range: " + string(_min_val) + ".." + string(_max_val)) : ""
    };
}

/// @function render_ui_number_field(_id, _x1, _y1, _x2, _y2, _current_val, _min_val, _max_val, _is_decimal)
/// @description Editable numeric input field with validation, negative-value restriction, range clamping, and Esc cancel.
function render_ui_number_field(_id, _x1, _y1, _x2, _y2, _current_val, _min_val, _max_val, _is_decimal) {
    var _pal = global.palette;
    draw_set_font(fnt_starlight_ui);
    var _is_editing = (global.input.text_input_active && global.input.text_input_id == _id);
    var _hover = !global.input.mouse_consumed && input_mouse_in_rect(_x1, _y1, _x2, _y2);
    var _result_val = _current_val;
    
    // Check if editing was just committed via Enter
    var _just_committed = (global.input.text_input_committed && global.input.text_input_last_id == _id);
    
    if (input_click_in_rect(_x1, _y1, _x2, _y2)) {
        input_begin_text_edit(_id, string(_current_val), 16);
        _is_editing = true;
    } else if (_is_editing && global.input.mb_left_pressed && !input_mouse_in_rect(_x1, _y1, _x2, _y2)) {
        // Clicking outside commits the typed number
        input_end_text_edit();
        _is_editing = false;
        _just_committed = true;
    }
    
    if (_just_committed) {
        var _check = render_validate_number_string(global.input.text_input_buffer, _min_val, _max_val, _is_decimal);
        if (_check.valid) {
            if (_check.value != _current_val) {
                _result_val = _check.value;
                global.project_dirty = true;
            }
            if (!_check.in_bounds) {
                core_log_toast("Clamped value to [" + string(_min_val) + " .. " + string(_max_val) + "]");
            }
        } else {
            core_log_warning("Number Input", "Invalid number '" + global.input.text_input_buffer + "' (" + _check.reason + "). Kept " + string(_current_val) + ".");
        }
        global.input.text_input_last_id = "";
    }
    
    var _live_valid = true;
    var _display_str = string(_result_val);
    if (_is_editing) {
        _display_str = global.input.text_input_buffer;
        var _lchk = render_validate_number_string(_display_str, _min_val, _max_val, _is_decimal);
        _live_valid = _lchk.valid && _lchk.in_bounds;
    }
    
    draw_set_color(_is_editing ? (_live_valid ? make_color_rgb(28, 34, 64) : make_color_rgb(58, 18, 28)) : make_color_rgb(10, 12, 22));
    draw_rectangle(_x1, _y1, _x2, _y2, false);
    
    var _bcol = _pal.border_inner;
    if (_is_editing) {
        _bcol = _live_valid ? _pal.accent_cyan : _pal.accent_red;
    } else if (_hover) {
        _bcol = _pal.accent_gold;
    }
    draw_set_color(_bcol);
    draw_rectangle(_x1, _y1, _x2, _y2, true);
    if (_is_editing) {
        draw_rectangle(_x1 + 1, _y1 + 1, _x2 - 1, _y2 - 1, true);
    }
    
    var _fitted = render_fit_text(_display_str, (_x2 - _x1) - 22);
    if (_is_editing && ((global.engine.frame_counter div 20) mod 2 == 0)) {
        _fitted += "_";
    }
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_middle);
    draw_set_color(_live_valid ? _pal.text_primary : _pal.accent_red);
    draw_text(_x1 + 8, mean(_y1, _y2), _fitted);
    
    if (_is_editing && !_live_valid) {
        draw_set_halign(fa_right);
        draw_set_color(_pal.accent_red);
        draw_text(_x2 - 6, mean(_y1, _y2), "!");
        draw_set_halign(fa_left);
    }
    
    return _result_val;
}

/// @function render_scrollbar(_x, _y1, _y2, _total_items, _visible_items, _scroll_offset)
/// @description Draws a vertical pixel scrollbar indicator.
function render_scrollbar(_x, _y1, _y2, _total_items, _visible_items, _scroll_offset) {
    var _pal = global.palette;
    var _track_h = max(16, _y2 - _y1);
    draw_set_color(make_color_rgb(10, 12, 24));
    draw_rectangle(_x, _y1, _x + 8, _y2, false);
    draw_set_color(_pal.border_inner);
    draw_rectangle(_x, _y1, _x + 8, _y2, true);
    
    if (_total_items <= _visible_items || _total_items <= 0) {
        draw_set_color(_pal.border_inner);
        draw_rectangle(_x + 2, _y1 + 2, _x + 6, _y2 - 2, false);
        return;
    }
    
    var _ratio = clamp(_visible_items / _total_items, 0.1, 1.0);
    var _thumb_h = max(16, floor(_track_h * _ratio));
    var _max_scroll = max(1, _total_items - _visible_items);
    var _pos_ratio = clamp(_scroll_offset / _max_scroll, 0.0, 1.0);
    var _thumb_y = _y1 + floor((_track_h - _thumb_h) * _pos_ratio);
    
    draw_set_color(_pal.accent_cyan);
    draw_rectangle(_x + 1, _thumb_y, _x + 7, _thumb_y + _thumb_h, false);
}

/// @function render_horizontal_scrollbar(_x1, _x2, _y, _total_items, _visible_items, _scroll_offset)
/// @description Draws a horizontal pixel scrollbar indicator for wide tab bars.
function render_horizontal_scrollbar(_x1, _x2, _y, _total_items, _visible_items, _scroll_offset) {
    var _pal = global.palette;
    var _track_w = max(16, _x2 - _x1);
    draw_set_color(make_color_rgb(10, 12, 24));
    draw_rectangle(_x1, _y, _x2, _y + 6, false);
    draw_set_color(_pal.border_inner);
    draw_rectangle(_x1, _y, _x2, _y + 6, true);
    
    if (_total_items <= _visible_items || _total_items <= 0) {
        draw_set_color(_pal.border_inner);
        draw_rectangle(_x1 + 2, _y + 1, _x2 - 2, _y + 5, false);
        return;
    }
    
    var _ratio = clamp(_visible_items / _total_items, 0.1, 1.0);
    var _thumb_w = max(16, floor(_track_w * _ratio));
    var _max_scroll = max(1, _total_items - _visible_items);
    var _pos_ratio = clamp(_scroll_offset / _max_scroll, 0.0, 1.0);
    var _thumb_x = _x1 + floor((_track_w - _thumb_w) * _pos_ratio);
    
    draw_set_color(_pal.accent_cyan);
    draw_rectangle(_thumb_x, _y + 1, _thumb_x + _thumb_w, _y + 5, false);
}
