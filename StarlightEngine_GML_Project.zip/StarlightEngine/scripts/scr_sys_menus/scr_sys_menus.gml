/// @description ST★RLIGHT ENGINE - Playable Runtime Loop, NPC Movement & In-Game Menus
/// Executes overworld gameplay, NPC pathing, entity interactions, and the RPG Pause Menu.

function runtime_update() {
    var _rt = global.runtime;
    _rt.playtime_seconds += (1 / 60);
    if (_rt.battle_grace_timer > 0) _rt.battle_grace_timer--;
    
    // Quick return to Editor during Playtest via F1
    if (global.playtest_active && global.input.shortcut_project_mgr) {
        runtime_exit_playtest_to_editor();
        return;
    }
    
    // 1. Update active Dialogue if open
    if (_rt.dialogue.active) {
        sys_dialogue_update();
        return;
    }
    
    // 2. Update active Event sequence
    if (_rt.event_runner.active) {
        sys_event_update();
        if (_rt.dialogue.active || _rt.event_runner.wait_frames > 0) {
            return;
        }
    }
    
    // 3. Toggle or update In-Game Pause Menu (C or Escape opens; X, C, or Escape closes)
    if (_rt.pause_menu_open) {
        runtime_update_pause_menu();
        return;
    }
    if (global.input.nav_menu) {
        _rt.pause_menu_open = true;
        _rt.pause_tab_index = 0;
        _rt.pause_sub_index = 0;
        core_audio_play_sfx_ui("ui_select");
        input_consume_all();
        return;
    }
    
    var _map = editor_map_find_by_id(_rt.current_map_id);
    if (!is_struct(_map)) return;
    
    // 4. Player Movement (WASD / Arrow Keys) & Directional Animation
    if (_rt.player_movement_enabled) {
        var _ax = global.input.axis_x;
        var _ay = global.input.axis_y;
        var _spd = _rt.player_move_speed;
        if (keyboard_check(vk_shift)) _spd *= 1.35;
        var _prev_p_state = _rt.player_anim_state;
        
        if (_ax != 0 || _ay != 0) {
            if (_ay > 0) _rt.player_facing = DIR_FACING.DOWN;
            else if (_ay < 0) _rt.player_facing = DIR_FACING.UP;
            else if (_ax < 0) _rt.player_facing = DIR_FACING.LEFT;
            else if (_ax > 0) _rt.player_facing = DIR_FACING.RIGHT;
            
            var _vx = _ax * _spd;
            var _vy = _ay * _spd;
            if (_ax != 0 && _ay != 0) {
                _vx *= 0.7071;
                _vy *= 0.7071;
            }
            
            var _moved = false;
            if (_vx != 0 && !runtime_check_tile_collision(_map, _rt.player_x + _vx, _rt.player_y, 26, 28) &&
                !runtime_check_npc_collision(_rt.player_x + _vx, _rt.player_y)) {
                _rt.player_x += _vx;
                _moved = true;
            }
            if (_vy != 0 && !runtime_check_tile_collision(_map, _rt.player_x, _rt.player_y + _vy, 26, 28) &&
                !runtime_check_npc_collision(_rt.player_x, _rt.player_y + _vy)) {
                _rt.player_y += _vy;
                _moved = true;
            }
            
            if (_moved) {
                _rt.player_anim_state = keyboard_check(vk_shift) ? "Running" : "Walking";
                if ((global.engine.frame_counter mod 16) == 0) {
                    _rt.stats_telemetry.steps_taken++;
                }
                runtime_check_automatic_events(_map);
            } else {
                _rt.player_anim_state = "Idle";
            }
        } else {
            _rt.player_anim_state = "Idle";
        }
        
        // Reset frame only when switching animation states, NOT when switching facing directions
        if (_rt.player_anim_state != _prev_p_state) {
            _rt.player_anim_frame = 0;
        }
        var _leader_spr_id = (array_length(_rt.party) > 0) ? _rt.party[0].sprite_id : "spr_hero_default";
        var _p_fps = core_assets_get_anim_fps(_leader_spr_id, _rt.player_anim_state, _rt.player_facing);
        _rt.player_anim_frame += (_p_fps / 60.0);
        
        // 5. Player Interaction (Z / Enter)
        if (global.input.nav_confirm) {
            if (runtime_try_interact(_map)) {
                input_consume_all();
                return;
            }
        }
    }
    
    // 6. Update NPCs (4 Movement Modes + Collision)
    for (var i = 0; i < array_length(_rt.active_npcs); i++) {
        runtime_update_npc_instance(_rt.active_npcs[i], _map);
    }
    
    // 7. Update Enemies (6 AI Modes + Collision + Contact Battle)
    for (var j = 0; j < array_length(_rt.active_enemies); j++) {
        sys_enemy_update_map_instance(_rt.active_enemies[j], _map);
        if (global.scene.current == ENGINE_SCENE.RUNTIME_BATTLE) return;
    }
    
    // 8. Update Runtime Camera
    camera_runtime_update(_rt.player_x + 16, _rt.player_y + 16, _map.width * _map.tile_size, _map.height * _map.tile_size, false);
}

function runtime_check_npc_collision(_px, _py) {
    var _npcs = global.runtime.active_npcs;
    for (var i = 0; i < array_length(_npcs); i++) {
        var _n = _npcs[i];
        if (_n.condition_var != "" && !sys_variable_check(_n.condition_var, _n.condition_val)) {
            continue;
        }
        if (rectangle_in_rectangle(_px + 2, _py + 2, _px + 26, _py + 28, _n.x + 2, _n.y + 2, _n.x + 28, _n.y + 28) > 0) {
            return true;
        }
    }
    return false;
}

function runtime_update_npc_instance(_npc, _map) {
    if (!is_struct(_npc)) return;
    // Check variable visibility condition
    if (_npc.condition_var != "" && !sys_variable_check(_npc.condition_var, _npc.condition_val)) {
        return;
    }
    
    var _vx = 0;
    var _vy = 0;
    var _spd = _npc.move_speed;
    
    switch (_npc.move_mode) {
        case NPC_MOVE_MODE.STAY_STILL:
            break;
            
        case NPC_MOVE_MODE.WANDER_RADIUS:
            _npc.wait_timer--;
            if (_npc.wait_timer <= 0) {
                _npc.wait_timer = max(30, _npc.wait_frames + irandom_range(-15, 25));
                if (irandom(2) == 0) {
                    _npc.wander_vx = 0;
                    _npc.wander_vy = 0;
                } else {
                    var _dir = choose(0, 90, 180, 270);
                    _npc.wander_vx = lengthdir_x(_spd, _dir);
                    _npc.wander_vy = lengthdir_y(_spd, _dir);
                    if (_dir == 0) _npc.facing = DIR_FACING.RIGHT;
                    else if (_dir == 180) _npc.facing = DIR_FACING.LEFT;
                    else if (_dir == 90) _npc.facing = DIR_FACING.UP;
                    else _npc.facing = DIR_FACING.DOWN;
                }
            }
            if (point_distance(_npc.spawn_x, _npc.spawn_y, _npc.x + _npc.wander_vx, _npc.y + _npc.wander_vy) <= _npc.wander_radius) {
                _vx = _npc.wander_vx;
                _vy = _npc.wander_vy;
            }
            break;
            
        case NPC_MOVE_MODE.SCRIPTED_PATH:
        case NPC_MOVE_MODE.REPEAT_SCRIPTED_PATH:
            if (!_npc.path_finished && is_array(_npc.path_points) && array_length(_npc.path_points) > 0) {
                var _wp = _npc.path_points[_npc.path_index];
                var _tx = _wp.grid_x * _map.tile_size;
                var _ty = _wp.grid_y * _map.tile_size;
                var _dist = point_distance(_npc.x, _npc.y, _tx, _ty);
                if (_dist <= _spd) {
                    _npc.x = _tx;
                    _npc.y = _ty;
                    _npc.path_index++;
                    if (_npc.path_index >= array_length(_npc.path_points)) {
                        if (_npc.move_mode == NPC_MOVE_MODE.REPEAT_SCRIPTED_PATH) {
                            _npc.path_index = 0;
                        } else {
                            _npc.path_finished = true;
                        }
                    }
                } else {
                    var _pdir = point_direction(_npc.x, _npc.y, _tx, _ty);
                    _vx = lengthdir_x(_spd, _pdir);
                    _vy = lengthdir_y(_spd, _pdir);
                }
            }
            break;
    }
    
    var _prev_n_state = _npc.anim_state;
    if (_vx != 0 || _vy != 0) {
        if (abs(_vy) >= abs(_vx)) {
            _npc.facing = (_vy > 0) ? DIR_FACING.DOWN : DIR_FACING.UP;
        } else {
            _npc.facing = (_vx > 0) ? DIR_FACING.RIGHT : DIR_FACING.LEFT;
        }
        var _hits_player = rectangle_in_rectangle(_npc.x + _vx + 2, _npc.y + _vy + 2, _npc.x + _vx + 28, _npc.y + _vy + 28,
            global.runtime.player_x, global.runtime.player_y, global.runtime.player_x + 28, global.runtime.player_y + 28) > 0;
        if (!_hits_player && !runtime_check_tile_collision(_map, _npc.x + _vx, _npc.y + _vy, 26, 26)) {
            _npc.x += _vx;
            _npc.y += _vy;
            _npc.anim_state = "Walking";
        } else {
            _npc.anim_state = "Idle";
        }
    } else {
        _npc.anim_state = "Idle";
    }
    if (_npc.anim_state != _prev_n_state) {
        _npc.anim_frame = 0;
    }
    var _n_fps = core_assets_get_anim_fps(_npc.sprite_id, _npc.anim_state, _npc.facing);
    _npc.anim_frame += (_n_fps / 60.0);
}

function runtime_check_automatic_events(_map) {
    if (!variable_struct_exists(_map, "events") || !is_array(_map.events)) return;
    var _rt = global.runtime;
    var _px = _rt.player_x + 16;
    var _py = _rt.player_y + 16;
    var _tsize = _map.tile_size;
    var _inside_id = "";
    
    for (var i = 0; i < array_length(_map.events); i++) {
        var _ev = _map.events[i];
        if (_ev.trigger_mode == EVENT_TRIGGER_MODE.AUTOMATIC || _ev.trigger_mode == EVENT_TRIGGER_MODE.CONDITIONAL) {
            var _ex1 = _ev.grid_x * _tsize;
            var _ey1 = _ev.grid_y * _tsize;
            var _ex2 = _ex1 + (max(1, _ev.grid_w) * _tsize);
            var _ey2 = _ey1 + (max(1, _ev.grid_h) * _tsize);
            if (_px >= _ex1 && _px <= _ex2 && _py >= _ey1 && _py <= _ey2) {
                _inside_id = _ev.id;
                if (_rt.active_auto_event_Lock != _ev.id) {
                    _rt.active_auto_event_Lock = _ev.id;
                    sys_event_trigger_map_event(_ev);
                }
                break;
            }
        }
    }
    if (_inside_id == "") {
        _rt.active_auto_event_Lock = "";
    }
}

function runtime_try_interact(_map) {
    var _rt = global.runtime;
    var _probe_x = _rt.player_x + 16;
    var _probe_y = _rt.player_y + 16;
    var _reach = 26;
    switch (_rt.player_facing) {
        case DIR_FACING.DOWN: _probe_y += _reach; break;
        case DIR_FACING.UP: _probe_y -= _reach; break;
        case DIR_FACING.LEFT: _probe_x -= _reach; break;
        case DIR_FACING.RIGHT: _probe_x += _reach; break;
    }
    
    // 1. Check NPCs
    for (var i = 0; i < array_length(_rt.active_npcs); i++) {
        var _n = _rt.active_npcs[i];
        if (_n.condition_var != "" && !sys_variable_check(_n.condition_var, _n.condition_val)) {
            continue;
        }
        var _n_sc = variable_struct_exists(_n, "sprite_scale") ? sys_sprite_clamp_scale(_n.sprite_scale) : 1.0;
        var _n_reach = 34 + max(0, (_n_sc - 1.0) * 12);
        if (point_distance(_probe_x, _probe_y, _n.x + 16, _n.y + 16) <= _n_reach) {
            // Turn NPC toward player
            if (_rt.player_facing == DIR_FACING.DOWN) _n.facing = DIR_FACING.UP;
            else if (_rt.player_facing == DIR_FACING.UP) _n.facing = DIR_FACING.DOWN;
            else if (_rt.player_facing == DIR_FACING.LEFT) _n.facing = DIR_FACING.RIGHT;
            else if (_rt.player_facing == DIR_FACING.RIGHT) _n.facing = DIR_FACING.LEFT;
            
            core_audio_play_default_sound("gameplay_interact");
            sys_dialogue_start_tree(_n.dialogue_tree, _n.name, _n.portrait_sprite_id, false);
            return true;
        }
    }
    
    // 2. Check Stationary Objects (Signs, Books, Doors, Chests, Furniture, Invisible Triggers)
    for (var j = 0; j < array_length(_rt.active_objects); j++) {
        var _o = _rt.active_objects[j];
        var _o_sc = variable_struct_exists(_o, "sprite_scale") ? sys_sprite_clamp_scale(_o.sprite_scale) : 1.0;
        var _range = (variable_struct_exists(_o, "interact_range") ? max(24, _o.interact_range) : 42) + max(0, (_o_sc - 1.0) * 12);
        if (point_distance(_probe_x, _probe_y, _o.x + 16, _o.y + 16) <= _range) {
            var _req_dir = variable_struct_exists(_o, "interact_dir") ? string_upper(_o.interact_dir) : "ANY";
            var _p_dir_str = string_upper(sys_sprite_get_dir_name(_rt.player_facing));
            if (_req_dir != "ANY" && _req_dir != "" && _req_dir != _p_dir_str) {
                continue;
            }
            core_audio_play_default_sound("gameplay_interact");
            // Stationary objects never display speaker names per Section 8
            sys_dialogue_start_tree(_o.dialogue_tree, "", "", true);
            return true;
        }
    }
    
    // 3. Check Player-Interaction Events
    if (variable_struct_exists(_map, "events") && is_array(_map.events)) {
        var _tsize = _map.tile_size;
        for (var k = 0; k < array_length(_map.events); k++) {
            var _ev = _map.events[k];
            if (_ev.trigger_mode == EVENT_TRIGGER_MODE.PLAYER_INTERACT) {
                var _ex1 = _ev.grid_x * _tsize;
                var _ey1 = _ev.grid_y * _tsize;
                var _ex2 = _ex1 + (max(1, _ev.grid_w) * _tsize);
                var _ey2 = _ey1 + (max(1, _ev.grid_h) * _tsize);
                if (point_in_rectangle(_probe_x, _probe_y, _ex1 - 8, _ey1 - 8, _ex2 + 8, _ey2 + 8)) {
                    var _trig_ok = sys_event_trigger_map_event(_ev);
                    if (_trig_ok) core_audio_play_default_sound("gameplay_interact");
                    return _trig_ok;
                }
            }
        }
    }
    return false;
}

/// @function runtime_exit_playtest_to_editor()
/// @description Restores the unsaved editor state snapshot after playtesting without altering saved files.
function runtime_exit_playtest_to_editor() {
    if (!is_undefined(global.playtest_snapshot)) {
        global.project = json_parse(global.playtest_snapshot);
        global.playtest_snapshot = undefined;
    }
    global.playtest_active = false;
    scene_switch_to(ENGINE_SCENE.EDITOR);
    core_log_toast("Returned to Editor from Playtest.");
}

// ============================================================================
// RUNTIME RENDERING (World Layers + Entities + Foreground + HUD/Menus)
// ============================================================================

function runtime_draw_gui() {
    var _rt = global.runtime;
    var _pal = global.palette;
    var _map = editor_map_find_by_id(_rt.current_map_id);
    
    // Clear background
    draw_set_color(_pal.space_dark);
    draw_rectangle(0, 0, STARLIGHT_BASE_WIDTH, STARLIGHT_BASE_HEIGHT, false);
    
    if (!is_struct(_map)) return;
    
    camera_runtime_sync_aspect_ratio();
    var _cam = global.camera.runtime;
    var _vx_off = _cam.viewport_x;
    var _shake_x = (_cam.shake_timer > 0) ? random_range(-_cam.shake_magnitude, _cam.shake_magnitude) : 0;
    var _shake_y = (_cam.shake_timer > 0) ? random_range(-_cam.shake_magnitude, _cam.shake_magnitude) : 0;
    var _zoom = _cam.zoom;
    var _tsize = _map.tile_size;
    var _scaled_tile = _tsize * _zoom;
    
    // 1. Render Lower Visual Layers: Background (0), Ground (1), Decorations (2)
    for (var l = 0; l <= 2; l++) {
        runtime_draw_map_layer(_map, l, _cam.x + _shake_x, _cam.y + _shake_y, _zoom, _scaled_tile, _vx_off, _cam.viewport_w);
    }
    
    // 2. Render Stationary Objects (Skip rendering if set to Invisible; apply configured Object Scale)
    for (var o = 0; o < array_length(_rt.active_objects); o++) {
        var _obj = _rt.active_objects[o];
        var _obj_vis = !variable_struct_exists(_obj, "visible") || _obj.visible;
        if (!_obj_vis) continue;
        var _ox = _vx_off + ((_obj.x - (_cam.x + _shake_x)) * _zoom);
        var _oy = (_obj.y - (_cam.y + _shake_y)) * _zoom;
        var _ofps = core_assets_get_anim_fps(_obj.sprite_id, "Idle", DIR_FACING.DOWN);
        var _oframe = global.engine.frame_counter * (_ofps / 60.0);
        var _osc = variable_struct_exists(_obj, "sprite_scale") ? sys_sprite_clamp_scale(_obj.sprite_scale) : 1.0;
        core_assets_draw_entity_sprite_scaled(_obj.sprite_id, "Idle", _oframe, _ox, _oy, _scaled_tile, _scaled_tile, DIR_FACING.DOWN, undefined, _osc, false);
    }
    
    // 3. Render Visible NPCs (Apply configured NPC Scale)
    for (var n = 0; n < array_length(_rt.active_npcs); n++) {
        var _npc = _rt.active_npcs[n];
        if (_npc.condition_var != "" && !sys_variable_check(_npc.condition_var, _npc.condition_val)) {
            continue;
        }
        var _nx = _vx_off + ((_npc.x - (_cam.x + _shake_x)) * _zoom);
        var _ny = (_npc.y - (_cam.y + _shake_y)) * _zoom;
        var _nsc = variable_struct_exists(_npc, "sprite_scale") ? sys_sprite_clamp_scale(_npc.sprite_scale) : 1.0;
        core_assets_draw_entity_sprite_scaled(_npc.sprite_id, _npc.anim_state, _npc.anim_frame, _nx, _ny, _scaled_tile, _scaled_tile, _npc.facing, make_color_rgb(245, 168, 92), _nsc, false);
    }
    
    // 4. Render Active Overworld Enemies (Uses Overworld Sprite, Facing Direction & Overworld Scale)
    for (var e = 0; e < array_length(_rt.active_enemies); e++) {
        var _en = _rt.active_enemies[e];
        if (_en.defeated) continue;
        if (_en.condition_var != "" && !sys_variable_check(_en.condition_var, _en.condition_val)) {
            continue;
        }
        var _ex = _vx_off + ((_en.x - (_cam.x + _shake_x)) * _zoom);
        var _ey = (_en.y - (_cam.y + _shake_y)) * _zoom;
        var _efacing = variable_struct_exists(_en, "facing") ? _en.facing : DIR_FACING.DOWN;
        var _esc = variable_struct_exists(_en, "sprite_scale") ? sys_sprite_clamp_scale(_en.sprite_scale) : 1.0;
        core_assets_draw_entity_sprite_scaled(_en.sprite_id, _en.anim_state, _en.anim_frame, _ex, _ey, _scaled_tile, _scaled_tile, _efacing, make_color_rgb(235, 76, 96), _esc, false);
    }
    
    // 5. Render Player Character (Uses Character Sprite Scale)
    var _leader_spr = (array_length(_rt.party) > 0) ? _rt.party[0].sprite_id : "spr_hero_default";
    var _leader_sc = (array_length(_rt.party) > 0 && variable_struct_exists(_rt.party[0], "sprite_scale"))
        ? sys_sprite_clamp_scale(_rt.party[0].sprite_scale) : 1.0;
    var _px = _vx_off + ((_rt.player_x - (_cam.x + _shake_x)) * _zoom);
    var _py = (_rt.player_y - (_cam.y + _shake_y)) * _zoom;
    core_assets_draw_entity_sprite_scaled(_leader_spr, _rt.player_anim_state, _rt.player_anim_frame, _px, _py, _scaled_tile, _scaled_tile, _rt.player_facing, make_color_rgb(92, 198, 245), _leader_sc, false);
    
    // 6. Render Foreground Layer (Layer 3) ABOVE Characters per Section 6
    runtime_draw_map_layer(_map, MAP_LAYER_TYPE.FOREGROUND, _cam.x + _shake_x, _cam.y + _shake_y, _zoom, _scaled_tile, _vx_off, _cam.viewport_w);
    
    // 7. Render 8:7 Aspect Ratio Pillarbox Frame if configured
    runtime_draw_aspect_frame();
    
    // 8. Render Dialogue Box if active
    if (_rt.dialogue.active) {
        sys_dialogue_draw_gui();
    }
    
    // 9. Render Pause Menu if open
    if (_rt.pause_menu_open) {
        runtime_draw_pause_menu();
    }
}

function runtime_draw_map_layer(_map, _layer_idx, _cam_x, _cam_y, _zoom, _scaled_tile, _vx_off, _vw) {
    if (!variable_struct_exists(_map, "layers") || _layer_idx >= array_length(_map.layers)) return;
    var _layer = _map.layers[_layer_idx];
    if (variable_struct_exists(_layer, "visible") && !_layer.visible) return;
    
    var _grid = _layer.data;
    var _w = _map.width;
    var _h = _map.height;
    var _tsize = _map.tile_size;
    var _tset = variable_struct_exists(_map, "tileset_id") ? _map.tileset_id : "ts_default_16bit";
    var _vx_max = _vx_off + _vw;
    
    for (var gy = 0; gy < _h; gy++) {
        var _sy = ((gy * _tsize) - _cam_y) * _zoom;
        if (_sy + _scaled_tile < 0 || _sy > STARLIGHT_BASE_HEIGHT) continue;
        for (var gx = 0; gx < _w; gx++) {
            var _tval = _grid[gy * _w + gx];
            if (_tval > 0) {
                var _sx = _vx_off + (((gx * _tsize) - _cam_x) * _zoom);
                if (_sx + _scaled_tile < _vx_off || _sx > _vx_max) continue;
                core_assets_draw_tile(_tset, _tval, _sx, _sy, _scaled_tile);
            }
        }
    }
}

// ============================================================================
// IN-GAME PAUSE MENU (Party, Inventory, Statistics, Save/Load, Settings)
// ============================================================================

function runtime_update_pause_menu() {
    var _rt = global.runtime;
    if (global.input.nav_cancel || global.input.nav_menu) {
        _rt.pause_menu_open = false;
        core_audio_play_sfx_ui("ui_cancel");
        input_consume_all();
        return;
    }
    if (global.input.nav_up) {
        _rt.pause_tab_index = (_rt.pause_tab_index + 5) mod 6;
        _rt.pause_sub_index = 0;
        core_audio_play_sfx_ui("ui_move");
    } else if (global.input.nav_down) {
        _rt.pause_tab_index = (_rt.pause_tab_index + 1) mod 6;
        _rt.pause_sub_index = 0;
        core_audio_play_sfx_ui("ui_move");
    } else if (global.input.nav_confirm && _rt.pause_tab_index == 5) {
        _rt.pause_menu_open = false;
        if (global.playtest_active) {
            runtime_exit_playtest_to_editor();
        } else {
            scene_switch_to(ENGINE_SCENE.MAIN_MENU);
        }
        input_consume_all();
    }
}

function runtime_draw_pause_menu() {
    var _rt = global.runtime;
    var _pal = global.palette;
    camera_runtime_sync_aspect_ratio();
    var _cam = global.camera.runtime;
    var _vx1 = _cam.viewport_x;
    var _vw = _cam.viewport_w;
    var _pp_enabled = sys_project_pp_enabled();
    
    draw_set_alpha(0.55);
    draw_set_color(c_black);
    draw_rectangle(_vx1, 0, _vx1 + _vw, STARLIGHT_BASE_HEIGHT, false);
    draw_set_alpha(1.0);
    
    // Adapt menu layout cleanly for both 16:9 (1280px) and 8:7 (824px)
    var _pad = (_vw < 1000) ? 16 : 64;
    var _left_w = (_vw < 1000) ? 228 : 260;
    var _lx1 = _vx1 + _pad;
    var _lx2 = _lx1 + _left_w;
    var _rx1 = _lx2 + 16;
    var _rx2 = _vx1 + _vw - _pad;
    var _ry1 = 56;
    var _ry2 = 664;
    
    // Left Menu Bar
    render_window_frame(_lx1, _ry1, _lx2, _ry2, "GAME MENU", _pal.accent_gold);
    var _exit_label = global.playtest_active ? "Return to Editor" : "Return to Title";
    var _tabs = ["Party", "Inventory", "Statistics", "Save / Load", "Settings", _exit_label];
    for (var i = 0; i < 6; i++) {
        var _by1 = 108 + i * 58;
        if (render_ui_button(_lx1 + 14, _by1, _lx2 - 14, _by1 + 46, _tabs[i], (_rt.pause_tab_index == i), true)) {
            _rt.pause_tab_index = i;
            _rt.pause_sub_index = 0;
            if (i == 5) {
                _rt.pause_menu_open = false;
                if (global.playtest_active) {
                    runtime_exit_playtest_to_editor();
                } else {
                    scene_switch_to(ENGINE_SCENE.MAIN_MENU);
                }
                return;
            }
        }
    }
    
    // Gold & Playtime badge at bottom of left panel
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(_pal.accent_gold);
    draw_text(_lx1 + 18, 536, "GOLD: $" + string(_rt.gold));
    draw_set_color(_pal.text_secondary);
    draw_text(_lx1 + 18, 568, "TIME: " + sys_stats_format_playtime(_rt.playtime_seconds));
    if (render_ui_button(_lx1 + 14, 604, _lx2 - 14, 646, "Resume (X / C / Esc)", false, true)) {
        _rt.pause_menu_open = false;
        return;
    }
    
    switch (_rt.pause_tab_index) {
        case 0: // PARTY (No free healing button — healing comes from items/events/locations)
            render_window_frame(_rx1, _ry1, _rx2, _ry2, "PARTY STATUS", _pal.accent_cyan);
            for (var p = 0; p < array_length(_rt.party); p++) {
                var _pm = _rt.party[p];
                var _cy1 = _ry1 + 48 + p * 140;
                var _cy2 = _cy1 + 126;
                draw_set_color(_pal.panel_alt);
                draw_rectangle(_rx1 + 18, _cy1, _rx2 - 18, _cy2, false);
                draw_set_color(_pal.border_inner);
                draw_rectangle(_rx1 + 18, _cy1, _rx2 - 18, _cy2, true);
                
                core_assets_draw_entity_sprite(_pm.sprite_id, "Idle", 0, _rx1 + 32, _cy1 + 20, 64, 64, DIR_FACING.DOWN, undefined);
                draw_set_color(_pal.accent_gold);
                draw_text(_rx1 + 112, _cy1 + 14, _pm.name + "   —   Level " + string(_pm.level));
                draw_set_color(_pal.accent_green);
                var _hp_line = "HP: " + string(_pm.current_hp) + " / " + string(_pm.max_hp);
                if (_pp_enabled) {
                    _hp_line += "     PP/MP: " + string(_pm.current_mp) + " / " + string(_pm.max_mp);
                }
                draw_text(_rx1 + 112, _cy1 + 46, _hp_line);
                draw_set_color(_pal.text_secondary);
                draw_text(_rx1 + 112, _cy1 + 78, "EXP: " + string(_pm.exp) + " / " + string(sys_leveling_exp_for_next_level(_pm)) +
                    "   |   ATK: " + string(sys_stats_get_effective_attack(_pm)) +
                    "  DEF: " + string(sys_stats_get_effective_defense(_pm)) +
                    "  SPD: " + string(sys_stats_get_effective_speed(_pm)));
            }
            break;
            
        case 1: // INVENTORY
            render_window_frame(_rx1, _ry1, _rx2, _ry2, "INVENTORY", _pal.accent_gold);
            if (array_length(_rt.inventory) == 0) {
                draw_set_color(_pal.text_secondary);
                draw_text(_rx1 + 24, _ry1 + 60, "Your inventory is currently empty.");
            } else {
                for (var it = 0; it < array_length(_rt.inventory); it++) {
                    var _slot = _rt.inventory[it];
                    var _idef = sys_item_find_def(_slot.item_id);
                    var _desc = is_struct(_idef) ? _idef.description : "";
                    var _iy1 = _ry1 + 52 + it * 68;
                    draw_set_color(_pal.panel_alt);
                    draw_rectangle(_rx1 + 18, _iy1, _rx2 - 18, _iy1 + 58, false);
                    draw_set_color(_pal.border_inner);
                    draw_rectangle(_rx1 + 18, _iy1, _rx2 - 18, _iy1 + 58, true);
                    
                    draw_set_color(_pal.text_primary);
                    draw_text(_rx1 + 32, _iy1 + 8, _slot.name + "  x" + string(_slot.quantity));
                    draw_set_color(_pal.text_secondary);
                    draw_text(_rx1 + 32, _iy1 + 32, render_fit_text(_desc, (_rx2 - _rx1) - 210));
                    
                    if (render_ui_button(_rx2 - 156, _iy1 + 8, _rx2 - 28, _iy1 + 48, "Use / Equip", false, true)) {
                        var _res = sys_inventory_use_item(_slot.item_id, _rt.party[0], false);
                        core_log_toast(_res.message);
                        return;
                    }
                }
            }
            break;
            
        case 2: // STATISTICS
            render_window_frame(_rx1, _ry1, _rx2, _ry2, "CHARACTER & ADVENTURE STATISTICS", _pal.accent_cyan);
            var _hero = _rt.party[0];
            draw_set_color(_pal.accent_gold);
            draw_text(_rx1 + 24, _ry1 + 54, "LEADER: " + _hero.name + " (Level " + string(_hero.level) + ")");
            draw_set_color(_pal.text_primary);
            draw_text(_rx1 + 24, _ry1 + 90, "Effective Attack: " + string(sys_stats_get_effective_attack(_hero)) + " (Base " + string(_hero.attack) + ")");
            draw_text(_rx1 + 24, _ry1 + 122, "Effective Defense: " + string(sys_stats_get_effective_defense(_hero)) + " (Base " + string(_hero.defense) + ")");
            draw_text(_rx1 + 24, _ry1 + 154, "Effective Speed: " + string(sys_stats_get_effective_speed(_hero)) + " (Base " + string(_hero.speed) + ")");
            draw_text(_rx1 + 24, _ry1 + 186, "Equipped Weapon: " + (_hero.equipment.weapon != "" ? _hero.equipment.weapon : "None"));
            draw_text(_rx1 + 24, _ry1 + 218, "Equipped Armor: " + (_hero.equipment.armor != "" ? _hero.equipment.armor : "None"));
            draw_text(_rx1 + 24, _ry1 + 250, "Equipped Accessory: " + (_hero.equipment.accessory != "" ? _hero.equipment.accessory : "None"));
            
            draw_set_color(_pal.accent_cyan);
            draw_text(_rx1 + 24, _ry1 + 300, "ADVENTURE TELEMETRY:");
            draw_set_color(_pal.text_secondary);
            draw_text(_rx1 + 24, _ry1 + 332, "Steps Taken: " + string(_rt.stats_telemetry.steps_taken));
            draw_text(_rx1 + 24, _ry1 + 364, "Battles Won: " + string(_rt.stats_telemetry.battles_won) + " / " + string(_rt.stats_telemetry.battles_fought));
            draw_text(_rx1 + 24, _ry1 + 396, "Total EXP Earned: " + string(_rt.stats_telemetry.total_exp_earned));
            draw_text(_rx1 + 24, _ry1 + 428, "Total Gold Earned: $" + string(_rt.stats_telemetry.total_gold_earned));
            break;
            
        case 3: // SAVE / LOAD
            render_window_frame(_rx1, _ry1, _rx2, _ry2, "SAVE & LOAD PROGRESS", _pal.accent_green);
            var _slots = core_game_get_save_slots(4);
            for (var s = 0; s < array_length(_slots); s++) {
                var _sl = _slots[s];
                var _sy1 = _ry1 + 52 + s * 124;
                var _sy2 = _sy1 + 110;
                draw_set_color(_pal.panel_alt);
                draw_rectangle(_rx1 + 18, _sy1, _rx2 - 18, _sy2, false);
                draw_set_color(_sl.exists ? _pal.accent_cyan : _pal.border_inner);
                draw_rectangle(_rx1 + 18, _sy1, _rx2 - 18, _sy2, true);
                
                var _info_max_w = (_rx2 - _rx1) - 270;
                draw_set_color(_pal.accent_gold);
                draw_text(_rx1 + 32, _sy1 + 10, render_fit_text("SLOT " + string(_sl.slot) + ": " + _sl.save_name, _info_max_w));
                draw_set_color(_pal.text_primary);
                draw_text(_rx1 + 32, _sy1 + 40, render_fit_text("Party: " + _sl.party_names + " | Map: " + _sl.map_name, _info_max_w));
                draw_set_color(_pal.text_secondary);
                draw_text(_rx1 + 32, _sy1 + 70, render_fit_text("Time: " + sys_stats_format_playtime(_sl.playtime_seconds) + " | " + _sl.save_date, _info_max_w));
                
                if (render_ui_button(_rx2 - 236, _sy1 + 32, _rx2 - 134, _sy1 + 76, "Save", false, true)) {
                    core_game_save_slot(_sl.slot, "");
                    return;
                }
                if (render_ui_button(_rx2 - 126, _sy1 + 32, _rx2 - 26, _sy1 + 76, "Load", false, _sl.exists && !_sl.corrupted)) {
                    core_game_load_slot(_sl.slot);
                    return;
                }
            }
            break;
            
        case 4: // SETTINGS
            render_window_frame(_rx1, _ry1, _rx2, _ry2, "GAMEPLAY SETTINGS", _pal.accent_cyan);
            var _btn_w = min(440, (_rx2 - _rx1) - 64);
            if (render_ui_button(_rx1 + 32, _ry1 + 64, _rx1 + 32 + _btn_w, _ry1 + 112, "Music Volume: " + string(round(global.config.music_volume * 100)) + "%", false, true)) {
                global.config.music_volume = (global.config.music_volume >= 1.0) ? 0.0 : clamp(global.config.music_volume + 0.2, 0.0, 1.0);
                core_audio_sync_volumes();
                core_config_save();
            }
            if (render_ui_button(_rx1 + 32, _ry1 + 132, _rx1 + 32 + _btn_w, _ry1 + 180, "SFX Volume: " + string(round(global.config.sfx_volume * 100)) + "%", false, true)) {
                global.config.sfx_volume = (global.config.sfx_volume >= 1.0) ? 0.0 : clamp(global.config.sfx_volume + 0.2, 0.0, 1.0);
                core_config_save();
            }
            if (render_ui_button(_rx1 + 32, _ry1 + 200, _rx1 + 32 + _btn_w, _ry1 + 248, "Player Walk Speed: " + string(_rt.player_move_speed), false, true)) {
                _rt.player_move_speed = (_rt.player_move_speed >= 4.5) ? 2.5 : (_rt.player_move_speed + 0.5);
            }
            if (render_ui_button(_rx1 + 32, _ry1 + 268, _rx1 + 32 + _btn_w, _ry1 + 316, "Fullscreen (F4): " + (global.config.fullscreen ? "ON" : "OFF"), global.config.fullscreen, true)) {
                global.config.fullscreen = !global.config.fullscreen;
                core_config_apply_display();
                core_config_save();
            }
            break;
    }
}
