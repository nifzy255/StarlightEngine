{
  "$GMScript": "v1",
  "%Name": "scr_sys_menus",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_sys_menus",
  "parent": {
    "name": "Systems",
    "path": "folders/Engine/Systems.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}