/// @description ST★RLIGHT ENGINE - Map Canvas, Layers, Creation & Resizing
/// Handles multi-layer map rendering, grid snapping, entity placement, and Map Manager operations.

function editor_map_create_empty_struct(_id, _name, _w, _h, _tile_size) {
    var _total = _w * _h;
    var _bg = array_create(_total, 0);
    var _ground = array_create(_total, 1); // Default grass/floor on Ground layer
    var _deco = array_create(_total, 0);
    var _fg = array_create(_total, 0);
    var _col = array_create(_total, 0);
    
    return {
        id: _id,
        name: _name,
        width: _w,
        height: _h,
        tile_size: is_undefined(_tile_size) ? 32 : _tile_size,
        tileset_id: "ts_default_16bit",
        bgm_id: "",
        layers: [
            { name: "Background", type: MAP_LAYER_TYPE.BACKGROUND, visible: true, data: _bg },
            { name: "Ground", type: MAP_LAYER_TYPE.GROUND, visible: true, data: _ground },
            { name: "Decorations", type: MAP_LAYER_TYPE.DECORATIONS, visible: true, data: _deco },
            { name: "Foreground", type: MAP_LAYER_TYPE.FOREGROUND, visible: true, data: _fg }
        ],
        collision: _col,
        events: [],
        objects: [],
        npcs: [],
        enemies: []
    };
}

function editor_map_find_by_id(_map_id) {
    if (is_undefined(global.project) || !is_array(global.project.maps)) return undefined;
    for (var i = 0; i < array_length(global.project.maps); i++) {
        var _m = global.project.maps[i];
        if (_m.id == _map_id || _m.name == _map_id) {
            return _m;
        }
    }
    return undefined;
}

function editor_map_resize(_map, _new_w, _new_h) {
    if (!is_struct(_map)) return;
    _new_w = clamp(round(_new_w), 8, 128);
    _new_h = clamp(round(_new_h), 8, 128);
    if (_new_w == _map.width && _new_h == _map.height) return;
    
    editor_push_undo_snapshot();
    var _old_w = _map.width;
    var _old_h = _map.height;
    
    // Resize all 4 visual tile layers
    for (var l = 0; l < array_length(_map.layers); l++) {
        var _old_data = _map.layers[l].data;
        var _new_data = array_create(_new_w * _new_h, 0);
        for (var gy = 0; gy < min(_old_h, _new_h); gy++) {
            for (var gx = 0; gx < min(_old_w, _new_w); gx++) {
                _new_data[gy * _new_w + gx] = _old_data[gy * _old_w + gx];
            }
        }
        _map.layers[l].data = _new_data;
    }
    
    // Resize collision array
    var _old_col = _map.collision;
    var _new_col = array_create(_new_w * _new_h, 0);
    for (var cy = 0; cy < min(_old_h, _new_h); cy++) {
        for (var cx = 0; cx < min(_old_w, _new_w); cx++) {
            _new_col[cy * _new_w + cx] = _old_col[cy * _old_w + cx];
        }
    }
    _map.collision = _new_col;
    _map.width = _new_w;
    _map.height = _new_h;
    global.project_dirty = true;
    core_log_toast("Resized map to " + string(_new_w) + "x" + string(_new_h));
}

function editor_map_update_canvas_interaction(_map) {
    var _ed = global.editor;
    var _cam = global.camera.editor;
    
    _ed.in_canvas = input_mouse_in_rect(_cam.viewport_x, _cam.viewport_y,
        _cam.viewport_x + _cam.viewport_w, _cam.viewport_y + _cam.viewport_h);
        
    if (!_ed.in_canvas || global.input.mouse_consumed || _ed.active_modal != EDITOR_MODAL.NONE) {
        _ed.hover_grid_x = -1;
        _ed.hover_grid_y = -1;
        _ed.stroke_in_progress = false;
        return;
    }
    
    var _wx = camera_editor_screen_to_world_x(global.input.mouse_gui_x);
    var _wy = camera_editor_screen_to_world_y(global.input.mouse_gui_y);
    var _gx = floor(_wx / _map.tile_size);
    var _gy = floor(_wy / _map.tile_size);
    
    if (_gx >= 0 && _gx < _map.width && _gy >= 0 && _gy < _map.height) {
        _ed.hover_grid_x = _gx;
        _ed.hover_grid_y = _gy;
    } else {
        _ed.hover_grid_x = -1;
        _ed.hover_grid_y = -1;
        return;
    }
    
    // Continuous painting for Tiles and Collision on Left Mouse Hold
    if (_ed.active_tool == EDITOR_TOOL.TILES || _ed.active_tool == EDITOR_TOOL.COLLISION) {
        if (global.input.mb_left_pressed) {
            editor_push_undo_snapshot();
            _ed.stroke_in_progress = true;
        }
        if (global.input.mb_left_held && _ed.stroke_in_progress) {
            if (_ed.active_tool == EDITOR_TOOL.COLLISION) {
                var _cval = (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) ? 1 : 0;
                editor_collision_set_cell(_map, _gx, _gy, _cval);
            } else {
                var _tval = (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) ? _ed.selected_tile_index : 0;
                editor_tiles_set_cell(_map, _ed.active_layer, _gx, _gy, _tval);
            }
        }
        if (global.input.mb_left_released) {
            _ed.stroke_in_progress = false;
        }
        
        // Right-clicking on canvas in Tiles mode samples the tile under cursor (eyedropper)
        if (global.input.mb_right_pressed && _ed.active_tool == EDITOR_TOOL.TILES) {
            var _sampled = editor_tiles_get_cell(_map, _ed.active_layer, _gx, _gy);
            if (_sampled > 0) {
                _ed.selected_tile_index = _sampled;
                core_log_toast("Sampled Tile #" + string(_sampled));
            }
        }
        return;
    }
    
    // Discrete Entity Tools (Events, Objects, NPCs, Enemies): Left-Click Places/Erases, Right-Click Inspects
    if (global.input.mb_left_pressed) {
        editor_push_undo_snapshot();
        switch (_ed.active_tool) {
            case EDITOR_TOOL.EVENTS:
                if (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) editor_events_place_at(_map, _gx, _gy);
                else editor_events_remove_at(_map, _gx, _gy);
                break;
            case EDITOR_TOOL.OBJECTS:
                if (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) editor_objects_place_at(_map, _gx, _gy);
                else editor_objects_remove_at(_map, _gx, _gy);
                break;
            case EDITOR_TOOL.NPCS:
                if (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) editor_npcs_place_at(_map, _gx, _gy);
                else editor_npcs_remove_at(_map, _gx, _gy);
                break;
            case EDITOR_TOOL.ENEMIES:
                if (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) editor_enemies_place_at(_map, _gx, _gy);
                else editor_enemies_remove_at(_map, _gx, _gy);
                break;
        }
    } else if (global.input.mb_right_pressed) {
        // Right-click inspects the entity at (_gx, _gy) regardless of which entity tool is selected
        if (editor_events_inspect_at(_map, _gx, _gy)) return;
        if (editor_objects_inspect_at(_map, _gx, _gy)) return;
        if (editor_npcs_inspect_at(_map, _gx, _gy)) return;
        if (editor_enemies_inspect_at(_map, _gx, _gy)) return;
    }
}

function editor_map_draw_canvas(_map) {
    var _ed = global.editor;
    var _cam = global.camera.editor;
    var _pal = global.palette;
    
    var _vx1 = _cam.viewport_x;
    var _vy1 = _cam.viewport_y;
    var _vx2 = _vx1 + _cam.viewport_w;
    var _vy2 = _vy1 + _cam.viewport_h;
    
    // Canvas backdrop
    draw_set_color(make_color_rgb(9, 11, 22));
    draw_rectangle(_vx1, _vy1, _vx2, _vy2, false);
    
    var _tsize = _map.tile_size;
    var _zoom = _cam.zoom;
    var _cell_px = _tsize * _zoom;
    
    // 1. Draw all visible Tile Layers (0..3)
    for (var l = 0; l < array_length(_map.layers); l++) {
        var _layer = _map.layers[l];
        if (variable_struct_exists(_layer, "visible") && !_layer.visible) continue;
        var _data = _layer.data;
        for (var gy = 0; gy < _map.height; gy++) {
            var _sy = camera_editor_world_to_screen_y(gy * _tsize);
            if (_sy + _cell_px < _vy1 || _sy > _vy2) continue;
            for (var gx = 0; gx < _map.width; gx++) {
                var _tval = _data[gy * _map.width + gx];
                if (_tval > 0) {
                    var _sx = camera_editor_world_to_screen_x(gx * _tsize);
                    if (_sx + _cell_px < _vx1 || _sx > _vx2) continue;
                    core_assets_draw_tile(_map.tileset_id, _tval, _sx, _sy, _cell_px);
                }
            }
        }
    }
    
    // 2. Draw Placed Stationary Objects (with Editor-Only Visual Indicator for Invisible Objects & Scaled Rendering)
    for (var o = 0; o < array_length(_map.objects); o++) {
        var _obj = _map.objects[o];
        var _ox = camera_editor_world_to_screen_x(_obj.grid_x * _tsize);
        var _oy = camera_editor_world_to_screen_y(_obj.grid_y * _tsize);
        if (_ox + _cell_px >= _vx1 && _ox <= _vx2 && _oy + _cell_px >= _vy1 && _oy <= _vy2) {
            var _obj_vis = !variable_struct_exists(_obj, "visible") || _obj.visible;
            var _obj_sc = variable_struct_exists(_obj, "sprite_scale") ? sys_sprite_clamp_scale(_obj.sprite_scale) : 1.0;
            if (_obj_vis) {
                core_assets_draw_entity_sprite_scaled(_obj.sprite_id, "Idle", 0, _ox, _oy, _cell_px, _cell_px, DIR_FACING.DOWN, undefined, _obj_sc, false);
            } else {
                draw_set_alpha(0.35);
                draw_set_color(_pal.accent_magenta);
                draw_rectangle(_ox + 2, _oy + 2, _ox + _cell_px - 2, _oy + _cell_px - 2, false);
                draw_set_alpha(1.0);
                draw_set_color(_pal.accent_gold);
                draw_rectangle(_ox + 2, _oy + 2, _ox + _cell_px - 2, _oy + _cell_px - 2, true);
                draw_text(_ox + 3, _oy + 4, render_fit_text("INVIS", _cell_px - 4));
            }
        }
    }
    
    // 3. Draw Placed NPCs (with Configured NPC Sprite Scale)
    for (var n = 0; n < array_length(_map.npcs); n++) {
        var _npc = _map.npcs[n];
        var _nx = camera_editor_world_to_screen_x(_npc.grid_x * _tsize);
        var _ny = camera_editor_world_to_screen_y(_npc.grid_y * _tsize);
        if (_nx + _cell_px >= _vx1 && _nx <= _vx2 && _ny + _cell_px >= _vy1 && _ny <= _vy2) {
            var _npc_sc = variable_struct_exists(_npc, "sprite_scale") ? sys_sprite_clamp_scale(_npc.sprite_scale) : 1.0;
            core_assets_draw_entity_sprite_scaled(_npc.sprite_id, "Idle", 0, _nx, _ny, _cell_px, _cell_px, _npc.facing, make_color_rgb(245, 168, 92), _npc_sc, false);
            draw_set_color(_pal.accent_gold);
            draw_text(_nx + 2, _ny - 14, render_fit_text(_npc.name, _cell_px * 2));
        }
    }
    
    // 4. Draw Placed Enemies (Uses Overworld Enemy Sprite & Overworld Scale from Enemy Database)
    for (var e = 0; e < array_length(_map.enemies); e++) {
        var _en = _map.enemies[e];
        var _ex = camera_editor_world_to_screen_x(_en.grid_x * _tsize);
        var _ey = camera_editor_world_to_screen_y(_en.grid_y * _tsize);
        if (_ex + _cell_px >= _vx1 && _ex <= _vx2 && _ey + _cell_px >= _vy1 && _ey <= _vy2) {
            var _edef_m = sys_enemy_find_def(_en.enemy_id);
            var _espr_id = (is_struct(_edef_m) && variable_struct_exists(_edef_m, "sprite_id")) ? _edef_m.sprite_id : "spr_enemy_default";
            var _eow_sc = (is_struct(_edef_m) && variable_struct_exists(_edef_m, "overworld_scale")) ? sys_sprite_clamp_scale(_edef_m.overworld_scale) : 1.0;
            var _elbl = is_struct(_edef_m) ? _edef_m.name : "FOE";
            core_assets_draw_entity_sprite_scaled(_espr_id, "Idle", 0, _ex, _ey, _cell_px, _cell_px, DIR_FACING.DOWN, make_color_rgb(235, 76, 96), _eow_sc, false);
            draw_set_color(_pal.accent_red);
            draw_text(_ex + 2, _ey - 14, render_fit_text(_elbl, _cell_px * 2));
        }
    }
    
    // 5. Draw Event Trigger Zones (visible in Editor, invisible in Gameplay)
    for (var ev = 0; ev < array_length(_map.events); ev++) {
        var _ev = _map.events[ev];
        var _evx1 = camera_editor_world_to_screen_x(_ev.grid_x * _tsize);
        var _evy1 = camera_editor_world_to_screen_y(_ev.grid_y * _tsize);
        var _evx2 = _evx1 + (max(1, _ev.grid_w) * _cell_px);
        var _evy2 = _evy1 + (max(1, _ev.grid_h) * _cell_px);
        draw_set_alpha(0.32);
        draw_set_color(_pal.accent_cyan);
        draw_rectangle(_evx1, _evy1, _evx2, _evy2, false);
        draw_set_alpha(1.0);
        draw_rectangle(_evx1, _evy1, _evx2, _evy2, true);
        draw_set_color(_pal.text_primary);
        draw_text(_evx1 + 4, _evy1 + 4, render_fit_text("EV: " + _ev.name, (_evx2 - _evx1) - 6));
    }
    
    // 6. Draw Collision Overlay (only in Editor when enabled)
    if (_ed.show_collision_overlay || _ed.active_tool == EDITOR_TOOL.COLLISION) {
        editor_collision_draw_overlay(_map, _vx1, _vy1, _vx2, _vy2, _cell_px);
    }
    
    // 7. Draw Grid Lines & Map Boundary Outline
    var _map_sx1 = camera_editor_world_to_screen_x(0);
    var _map_sy1 = camera_editor_world_to_screen_y(0);
    var _map_sx2 = camera_editor_world_to_screen_x(_map.width * _tsize);
    var _map_sy2 = camera_editor_world_to_screen_y(_map.height * _tsize);
    
    if (_ed.show_grid) {
        draw_set_alpha(0.20);
        draw_set_color(_pal.border_inner);
        for (var gx = 0; gx <= _map.width; gx++) {
            var _lx = camera_editor_world_to_screen_x(gx * _tsize);
            if (_lx >= _vx1 && _lx <= _vx2) {
                draw_line(_lx, max(_vy1, _map_sy1), _lx, min(_vy2, _map_sy2));
            }
        }
        for (var gy = 0; gy <= _map.height; gy++) {
            var _ly = camera_editor_world_to_screen_y(gy * _tsize);
            if (_ly >= _vy1 && _ly <= _vy2) {
                draw_line(max(_vx1, _map_sx1), _ly, min(_vx2, _map_sx2), _ly);
            }
        }
        draw_set_alpha(1.0);
    }
    
    draw_set_color(_pal.accent_gold);
    draw_rectangle(_map_sx1, _map_sy1, _map_sx2, _map_sy2, true);
    
    // 8. Draw Hover Selection Highlight
    if (_ed.in_canvas && _ed.hover_grid_x >= 0 && _ed.hover_grid_y >= 0) {
        var _hx1 = camera_editor_world_to_screen_x(_ed.hover_grid_x * _tsize);
        var _hy1 = camera_editor_world_to_screen_y(_ed.hover_grid_y * _tsize);
        var _hcol = (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) ? _pal.accent_gold : _pal.accent_red;
        draw_set_color(_hcol);
        draw_rectangle(_hx1, _hy1, _hx1 + _cell_px, _hy1 + _cell_px, true);
        draw_rectangle(_hx1 + 1, _hy1 + 1, _hx1 + _cell_px - 1, _hy1 + _cell_px - 1, true);
    }
}

function editor_map_draw_manager_modal(_map) {
    var _pal = global.palette;
    render_window_frame(180, 64, 1100, 656, "MAP MANAGER — CREATE, RESIZE & CONFIGURE MAPS", _pal.accent_cyan);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    draw_set_color(_pal.accent_gold);
    draw_text(212, 112, "Custom Map ID:");
    render_ui_custom_id_field("map_custom_id", "map", _map, 212, 136, 520, 172);
    
    draw_set_color(_pal.accent_gold);
    draw_text(544, 112, "Active Map Name:");
    _map.name = render_ui_text_field("map_edit_name", 544, 136, 1068, 172, _map.name, 40);
    
    // Direct Editable Numeric Fields for Map Width, Map Height, and Grid Size
    draw_set_color(_pal.accent_cyan);
    draw_text(212, 192, "MAP DIMENSIONS & GRID SIZE (Click Field, Type Number, Press Enter):");
    
    draw_set_color(_pal.text_secondary);
    draw_text(212, 224, "Map Width (8..128):");
    var _new_w = render_ui_number_field("map_num_w", 212, 248, 440, 286, _map.width, 8, 128, false);
    if (_new_w != _map.width) {
        editor_map_resize(_map, _new_w, _map.height);
    }
    
    draw_set_color(_pal.text_secondary);
    draw_text(468, 224, "Map Height (8..128):");
    var _new_h = render_ui_number_field("map_num_h", 468, 248, 696, 286, _map.height, 8, 128, false);
    if (_new_h != _map.height) {
        editor_map_resize(_map, _map.width, _new_h);
    }
    
    draw_set_color(_pal.text_secondary);
    draw_text(724, 224, "Grid Size px (16..64):");
    _map.tile_size = render_ui_number_field("map_num_grid", 724, 248, 952, 286, _map.tile_size, 16, 64, false);
    
    if (render_ui_button(212, 300, 480, 338, "Quick Grid: " + (_map.tile_size == 32 ? "Switch to 16px" : "Switch to 32px"), false, true)) {
        _map.tile_size = (_map.tile_size == 32) ? 16 : 32;
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.accent_cyan);
    draw_text(212, 362, "PROJECT MAPS (" + string(array_length(global.project.maps)) + "):");
    for (var i = 0; i < min(5, array_length(global.project.maps)); i++) {
        var _m = global.project.maps[i];
        var _my1 = 392 + i * 42;
        if (render_ui_button(212, _my1, 756, _my1 + 36, _m.id + " — " + _m.name + " (" + string(_m.width) + "x" + string(_m.height) + ")", (global.editor.active_map_index == i), true)) {
            input_end_text_edit();
            global.editor.active_map_index = i;
        }
    }
    
    if (render_ui_button(780, 392, 1068, 436, "+ Create New Map", false, true)) {
        var _new_id = "map_0" + string(array_length(global.project.maps) + 1);
        var _new_map = editor_map_create_empty_struct(_new_id, "New Map " + string(array_length(global.project.maps) + 1), 24, 16, 32);
        array_push(global.project.maps, _new_map);
        global.editor.active_map_index = array_length(global.project.maps) - 1;
        global.project_dirty = true;
        core_log_toast("Created " + _new_map.name);
    }
    
    if (render_ui_button(780, 450, 1068, 494, "Delete Active Map", false, array_length(global.project.maps) > 1)) {
        array_delete(global.project.maps, global.editor.active_map_index, 1);
        global.editor.active_map_index = 0;
        global.project_dirty = true;
        core_log_toast("Deleted map.");
    }
    
    if (render_ui_button(868, 594, 1068, 636, "Close (Esc)", true, true)) {
        input_end_text_edit();
        global.editor.active_modal = EDITOR_MODAL.NONE;
    }
}
