{
  "$GMScript": "v1",
  "%Name": "scr_editor_main",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_editor_main",
  "parent": {
    "name": "Editor",
    "path": "folders/Engine/Editor.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}