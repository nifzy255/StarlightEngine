/// @description ST★RLIGHT ENGINE - Central RPG Editor Controller
/// Manages the visual editor layout, left toolbar, mouse modes (Place/Erase), Undo/Redo stack, and modals.

function editor_init_state() {
    global.editor = {
        active_map_index: 0,
        active_tool: EDITOR_TOOL.TILES,
        mouse_mode: MOUSE_EDIT_MODE.PLACE,
        active_layer: MAP_LAYER_TYPE.GROUND,
        selected_tile_index: 1,
        selected_tileset_id: "ts_default_16bit",
        show_grid: true,
        show_collision_overlay: true,
        collision_overlay_alpha: 0.42,
        active_modal: EDITOR_MODAL.NONE,
        return_modal: EDITOR_MODAL.NONE,
        
        // Selected entity references for right-click property inspection
        inspect_event: undefined,
        inspect_object: undefined,
        inspect_npc: undefined,
        inspect_enemy_inst: undefined,
        
        // Database manager selection indices & scroll offsets
        selected_char_idx: 0,
        selected_item_idx: 0,
        selected_var_idx: 0,
        selected_audio_idx: 0,
        selected_sprite_idx: 0,
        selected_enemy_def_idx: 0,
        selected_cmd_catalog_idx: 0,
        tile_page_offset: 0,
        tile_confirm_mode: 0,
        tile_pending_png_rel: "",
        tile_pending_png_name: "",
        sprite_anim_state: "Walking",
        sprite_anim_dir: "Down",
        sprite_frame_idx: 0,
        sprite_preview_playing: true,
        sprite_filmstrip_scroll: 0,
        dlg_active_branch: "starter",
        dlg_tab_scroll: 0,
        dlg_node_scroll: 0,
        item_ev_scroll: 0,
        pm_tab_idx: 0,
        pm_sound_group_idx: 0,
        pm_sound_scroll: 0,
        
        // Undo / Redo snapshot history stacks (Ctrl+Z / Ctrl+Y)
        undo_stack: [],
        redo_stack: [],
        stroke_in_progress: false,
        
        // Hover grid cell tracking
        hover_grid_x: -1,
        hover_grid_y: -1,
        in_canvas: false
    };
}

function editor_open_current_project() {
    editor_init_state();
    if (!is_undefined(global.project) && array_length(global.project.maps) > 0) {
        global.editor.active_map_index = 0;
        var _m = global.project.maps[0];
        if (variable_struct_exists(_m, "tileset_id")) {
            global.editor.selected_tileset_id = _m.tileset_id;
        }
    }
    global.camera.editor.x = 0;
    global.camera.editor.y = 0;
    global.camera.editor.target_x = 0;
    global.camera.editor.target_y = 0;
    global.camera.editor.zoom = 1.0;
    global.camera.editor.target_zoom = 1.0;
}

function editor_get_active_map() {
    if (is_undefined(global.project) || !is_array(global.project.maps) || array_length(global.project.maps) == 0) {
        return undefined;
    }
    global.editor.active_map_index = clamp(global.editor.active_map_index, 0, array_length(global.project.maps) - 1);
    return global.project.maps[global.editor.active_map_index];
}

function editor_push_undo_snapshot() {
    var _map = editor_get_active_map();
    if (!is_struct(_map)) return;
    var _snap = json_stringify(_map);
    array_push(global.editor.undo_stack, _snap);
    if (array_length(global.editor.undo_stack) > 30) {
        array_delete(global.editor.undo_stack, 0, 1);
    }
    global.editor.redo_stack = [];
    global.project_dirty = true;
}

function editor_perform_undo() {
    var _ed = global.editor;
    if (array_length(_ed.undo_stack) == 0) {
        core_log_toast("Nothing to undo.");
        return;
    }
    var _cur_map = editor_get_active_map();
    if (is_struct(_cur_map)) {
        array_push(_ed.redo_stack, json_stringify(_cur_map));
    }
    var _prev_json = _ed.undo_stack[array_length(_ed.undo_stack) - 1];
    array_delete(_ed.undo_stack, array_length(_ed.undo_stack) - 1, 1);
    global.project.maps[_ed.active_map_index] = json_parse(_prev_json);
    global.project_dirty = true;
    core_log_toast("Undo applied.");
}

function editor_perform_redo() {
    var _ed = global.editor;
    if (array_length(_ed.redo_stack) == 0) {
        core_log_toast("Nothing to redo.");
        return;
    }
    var _cur_map = editor_get_active_map();
    if (is_struct(_cur_map)) {
        array_push(_ed.undo_stack, json_stringify(_cur_map));
    }
    var _next_json = _ed.redo_stack[array_length(_ed.redo_stack) - 1];
    array_delete(_ed.redo_stack, array_length(_ed.redo_stack) - 1, 1);
    global.project.maps[_ed.active_map_index] = json_parse(_next_json);
    global.project_dirty = true;
    core_log_toast("Redo applied.");
}

function editor_update() {
    var _ed = global.editor;
    var _map = editor_get_active_map();
    if (!is_struct(_map)) return;
    
    // F1 toggles Project Manager modal
    if (global.input.shortcut_project_mgr) {
        input_end_text_edit();
        if (_ed.active_modal == EDITOR_MODAL.PROJECT_MANAGER) {
            _ed.active_modal = EDITOR_MODAL.NONE;
        } else {
            _ed.active_modal = EDITOR_MODAL.PROJECT_MANAGER;
        }
        input_consume_all();
        return;
    }
    
    // Escape closes any open modal dialog (or returns to parent inspector from Sprite Manager)
    if (_ed.active_modal != EDITOR_MODAL.NONE) {
        if (global.input.nav_cancel && !global.input.text_input_active) {
            if (_ed.active_modal == EDITOR_MODAL.SPRITE_MANAGER && _ed.return_modal != EDITOR_MODAL.NONE) {
                _ed.active_modal = _ed.return_modal;
                _ed.return_modal = EDITOR_MODAL.NONE;
            } else {
                _ed.active_modal = EDITOR_MODAL.NONE;
                _ed.return_modal = EDITOR_MODAL.NONE;
            }
            input_consume_all();
        }
        return;
    }
    
    // Editor keyboard shortcuts (when no modal or text field is active)
    if (!global.input.text_input_active) {
        if (global.input.shortcut_toggle_mode) {
            _ed.mouse_mode = (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) ? MOUSE_EDIT_MODE.ERASE : MOUSE_EDIT_MODE.PLACE;
            core_log_toast("Mouse Mode: " + (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE ? "PLACE" : "ERASE"));
        }
        if (global.input.shortcut_undo) {
            editor_perform_undo();
        } else if (global.input.shortcut_redo) {
            editor_perform_redo();
        } else if (global.input.shortcut_save) {
            core_saveload_save_project();
        }
    }
    
    // Update independent Editor Map Camera (WASD + Mouse Wheel Zoom)
    var _map_pw = _map.width * _map.tile_size;
    var _map_ph = _map.height * _map.tile_size;
    camera_editor_update(_map_pw, _map_ph, (_ed.active_modal == EDITOR_MODAL.NONE));
    
    // Update mouse hover cell & canvas painting
    editor_map_update_canvas_interaction(_map);
}

function editor_draw_gui() {
    var _ed = global.editor;
    var _pal = global.palette;
    var _map = editor_get_active_map();
    
    // Base editor background
    draw_set_color(_pal.space_dark);
    draw_rectangle(0, 0, STARLIGHT_BASE_WIDTH, STARLIGHT_BASE_HEIGHT, false);
    
    // 1. Center Map Canvas (drawn first, clipped to viewport)
    if (is_struct(_map)) {
        editor_map_draw_canvas(_map);
    }
    
    // If a modal window is active, block mouse interaction on background editor panels
    var _modal_open = (_ed.active_modal != EDITOR_MODAL.NONE);
    var _prev_mouse_consumed = global.input.mouse_consumed;
    if (_modal_open) {
        global.input.mouse_consumed = true;
    }
    
    // 2. Top Database & Project Bar
    editor_draw_top_bar(_map);
    
    // 3. Left Vertical Toolbar (Collision, Tiles, Events, Objects, NPCs, Enemies)
    editor_draw_left_toolbar();
    
    // 4. Right Layer & Map Properties Sidebar
    if (is_struct(_map)) {
        editor_draw_right_sidebar(_map);
    }
    
    // 5. Bottom Status Bar
    editor_draw_status_bar(_map);
    
    // 6. Active Modal Window (Tile Selector, Inspectors, Database Managers, Project Manager)
    if (_modal_open) {
        global.input.mouse_consumed = _prev_mouse_consumed;
        editor_draw_active_modal(_map);
    }
}

function editor_draw_top_bar(_map) {
    var _ed = global.editor;
    var _pal = global.palette;
    
    draw_set_color(_pal.panel_header);
    draw_rectangle(0, 0, STARLIGHT_BASE_WIDTH, 42, false);
    draw_set_color(_pal.border_inner);
    draw_line(0, 42, STARLIGHT_BASE_WIDTH, 42);
    
    var _proj_title = is_struct(global.project) ? global.project.name : "Untitled";
    if (global.project_dirty) _proj_title += " *";
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_middle);
    draw_set_color(_pal.accent_gold);
    draw_text(12, 21, render_fit_text("★ " + _proj_title, 210));
    
    // Top Manager Buttons
    var _mgr_buttons = [
        { label: "Project (F1)", modal: EDITOR_MODAL.PROJECT_MANAGER },
        { label: "Maps", modal: EDITOR_MODAL.MAP_MANAGER },
        { label: "Characters", modal: EDITOR_MODAL.CHARACTER_MANAGER },
        { label: "Items", modal: EDITOR_MODAL.ITEM_MANAGER },
        { label: "Enemies DB", modal: EDITOR_MODAL.ENEMY_INSPECTOR },
        { label: "Variables", modal: EDITOR_MODAL.VARIABLE_MANAGER },
        { label: "Sprites", modal: EDITOR_MODAL.SPRITE_MANAGER },
        { label: "Audio", modal: EDITOR_MODAL.AUDIO_MANAGER }
    ];
    
    var _bx = 230;
    var _bw = 112;
    for (var i = 0; i < array_length(_mgr_buttons); i++) {
        var _b = _mgr_buttons[i];
        var _sel = (_ed.active_modal == _b.modal);
        if (render_ui_button(_bx, 5, _bx + _bw, 37, _b.label, _sel, true)) {
            input_end_text_edit();
            if (_b.modal == EDITOR_MODAL.ENEMY_INSPECTOR) {
                _ed.inspect_enemy_inst = undefined;
            }
            _ed.return_modal = EDITOR_MODAL.NONE;
            _ed.active_modal = (_ed.active_modal == _b.modal) ? EDITOR_MODAL.NONE : _b.modal;
            return;
        }
        _bx += _bw + 6;
    }
    
    // Quick Playtest Button on Top-Right
    if (render_ui_button(1180, 5, 1272, 37, "▶ Play", false, true)) {
        editor_project_start_playtest();
    }
}

function editor_draw_left_toolbar() {
    var _ed = global.editor;
    var _pal = global.palette;
    
    render_window_frame(0, 42, 188, 682, "EDITOR TOOLS", _pal.border_outer);
    
    var _tools = [
        { id: EDITOR_TOOL.COLLISION, label: "Collision" },
        { id: EDITOR_TOOL.TILES, label: "Tiles (R-Click)" },
        { id: EDITOR_TOOL.EVENTS, label: "Events" },
        { id: EDITOR_TOOL.OBJECTS, label: "Objects" },
        { id: EDITOR_TOOL.NPCS, label: "NPCs" },
        { id: EDITOR_TOOL.ENEMIES, label: "Enemies" }
    ];
    
    for (var i = 0; i < array_length(_tools); i++) {
        var _t = _tools[i];
        var _by1 = 84 + i * 48;
        var _by2 = _by1 + 40;
        
        // Right-clicking the Tiles toolbar button opens the Tile Selection Menu per Section 6
        if (_t.id == EDITOR_TOOL.TILES && input_right_click_in_rect(10, _by1, 178, _by2)) {
            _ed.active_tool = EDITOR_TOOL.TILES;
            _ed.active_modal = EDITOR_MODAL.TILE_SELECTOR;
            core_audio_play_sfx_ui("ui_select");
            return;
        }
        
        if (render_ui_button(10, _by1, 178, _by2, _t.label, (_ed.active_tool == _t.id), true)) {
            _ed.active_tool = _t.id;
            return;
        }
    }
    
    // Mouse Mode Toggle Indicator (Z key: Place vs Erase)
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(_pal.accent_cyan);
    draw_text(12, 384, "MOUSE MODE (Z Key):");
    var _mode_str = (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) ? "MODE: PLACE" : "MODE: ERASE";
    if (render_ui_button(10, 408, 178, 448, _mode_str, (_ed.mouse_mode == MOUSE_EDIT_MODE.ERASE), true)) {
        _ed.mouse_mode = (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) ? MOUSE_EDIT_MODE.ERASE : MOUSE_EDIT_MODE.PLACE;
    }
    
    // Undo / Redo Buttons
    if (render_ui_button(10, 460, 90, 496, "Undo", false, array_length(_ed.undo_stack) > 0)) {
        editor_perform_undo();
    }
    if (render_ui_button(98, 460, 178, 496, "Redo", false, array_length(_ed.redo_stack) > 0)) {
        editor_perform_redo();
    }
    
    // Quick Tile Palette open button when Tiles tool is active
    if (render_ui_button(10, 508, 178, 544, "Tile Palette...", false, true)) {
        _ed.active_tool = EDITOR_TOOL.TILES;
        _ed.active_modal = EDITOR_MODAL.TILE_SELECTOR;
    }
    
    // Save Project Button
    if (render_ui_button(10, 556, 178, 594, "Save Project", false, true)) {
        core_saveload_save_project();
    }
    
    // Active Tool Quick Help
    draw_set_color(_pal.text_muted);
    draw_text(12, 608, "L-Click: Paint/Place");
    draw_text(12, 628, "R-Click: Inspect/Edit");
    draw_text(12, 648, "WASD: Pan Map Camera");
}

function editor_draw_right_sidebar(_map) {
    var _ed = global.editor;
    var _pal = global.palette;
    
    render_window_frame(1012, 42, STARLIGHT_BASE_WIDTH, 682, "MAP & LAYERS", _pal.border_outer);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(_pal.accent_gold);
    draw_text(1024, 82, render_fit_text("Map: " + _map.name, 240));
    draw_set_color(_pal.text_secondary);
    draw_text(1024, 106, "Size: " + string(_map.width) + "x" + string(_map.height) + " (" + string(_map.tile_size) + "px)");
    
    // Map Switcher Prev / Next
    var _mcount = array_length(global.project.maps);
    if (render_ui_button(1024, 132, 1138, 166, "< Prev Map", false, _mcount > 1)) {
        _ed.active_map_index = (_ed.active_map_index + _mcount - 1) mod _mcount;
    }
    if (render_ui_button(1146, 132, 1266, 166, "Next Map >", false, _mcount > 1)) {
        _ed.active_map_index = (_ed.active_map_index + 1) mod _mcount;
    }
    
    // Visual Layers (Background, Ground, Decorations, Foreground)
    draw_set_color(_pal.accent_cyan);
    draw_text(1024, 184, "VISUAL LAYERS:");
    var _layer_names = ["0: Background", "1: Ground", "2: Decorations", "3: Foreground"];
    for (var l = 0; l < 4; l++) {
        var _ly1 = 210 + l * 42;
        var _ly2 = _ly1 + 36;
        var _lstruct = _map.layers[l];
        var _vis = variable_struct_exists(_lstruct, "visible") ? _lstruct.visible : true;
        
        if (render_ui_button(1024, _ly1, 1212, _ly2, _layer_names[l], (_ed.active_layer == l), true)) {
            _ed.active_layer = l;
        }
        var _vis_lbl = _vis ? "V" : "-";
        if (render_ui_button(1218, _ly1, 1266, _ly2, _vis_lbl, _vis, true)) {
            _lstruct.visible = !_vis;
        }
    }
    
    // Grid & Collision Overlay Toggles
    draw_set_color(_pal.accent_cyan);
    draw_text(1024, 390, "VIEWPORT OVERLAYS:");
    if (render_ui_button(1024, 416, 1266, 452, "Grid Lines: " + (_ed.show_grid ? "ON" : "OFF"), _ed.show_grid, true)) {
        _ed.show_grid = !_ed.show_grid;
    }
    if (render_ui_button(1024, 460, 1266, 496, "Collision Overlay: " + (_ed.show_collision_overlay ? "ON" : "OFF"), _ed.show_collision_overlay, true)) {
        _ed.show_collision_overlay = !_ed.show_collision_overlay;
    }
    
    // Zoom Controls
    var _cam = global.camera.editor;
    draw_set_color(_pal.accent_cyan);
    draw_text(1024, 514, "ZOOM: " + string(round(_cam.zoom * 100)) + "%");
    if (render_ui_button(1024, 540, 1100, 576, "Zoom -", false, true)) {
        _cam.target_zoom = clamp(_cam.target_zoom - 0.25, _cam.min_zoom, _cam.max_zoom);
    }
    if (render_ui_button(1108, 540, 1184, 576, "100%", false, true)) {
        _cam.target_zoom = 1.0;
    }
    if (render_ui_button(1192, 540, 1266, 576, "Zoom +", false, true)) {
        _cam.target_zoom = clamp(_cam.target_zoom + 0.25, _cam.min_zoom, _cam.max_zoom);
    }
    
    // Active Selected Tile Preview
    draw_set_color(_pal.text_secondary);
    draw_text(1024, 594, "Active Tile #" + string(_ed.selected_tile_index));
    core_assets_draw_tile(_ed.selected_tileset_id, _ed.selected_tile_index, 1218, 590, 36);
}

function editor_draw_status_bar(_map) {
    var _ed = global.editor;
    var _pal = global.palette;
    
    draw_set_color(_pal.panel_header);
    draw_rectangle(0, 682, STARLIGHT_BASE_WIDTH, STARLIGHT_BASE_HEIGHT, false);
    draw_set_color(_pal.border_inner);
    draw_line(0, 682, STARLIGHT_BASE_WIDTH, 682);
    
    var _tool_names = ["COLLISION", "TILES", "EVENTS", "OBJECTS", "NPCS", "ENEMIES"];
    var _tname = _tool_names[clamp(_ed.active_tool, 0, 5)];
    var _mname = (_ed.mouse_mode == MOUSE_EDIT_MODE.PLACE) ? "PLACE" : "ERASE";
    var _cell_str = (_ed.in_canvas && _ed.hover_grid_x >= 0)
        ? ("Grid: (" + string(_ed.hover_grid_x) + ", " + string(_ed.hover_grid_y) + ")")
        : "Grid: (-, -)";
    var _dirty_str = global.project_dirty ? "UNSAVED CHANGES *" : "ALL CHANGES SAVED";
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_middle);
    draw_set_color(_pal.accent_gold);
    draw_text(14, 701, "TOOL: " + _tname + "   |   MOUSE: " + _mname + "   |   " + _cell_str);
    
    draw_set_halign(fa_right);
    draw_set_color(global.project_dirty ? _pal.accent_magenta : _pal.accent_green);
    draw_text(STARLIGHT_BASE_WIDTH - 16, 701, _dirty_str + "   |   F1: Project Manager");
    draw_set_halign(fa_left);
}

function editor_draw_active_modal(_map) {
    var _ed = global.editor;
    // Dim backdrop behind modal and block canvas clicks
    draw_set_alpha(0.55);
    draw_set_color(c_black);
    draw_rectangle(0, 0, STARLIGHT_BASE_WIDTH, STARLIGHT_BASE_HEIGHT, false);
    draw_set_alpha(1.0);
    
    switch (_ed.active_modal) {
        case EDITOR_MODAL.TILE_SELECTOR:
            editor_tiles_draw_selector_modal(_map);
            break;
        case EDITOR_MODAL.EVENT_INSPECTOR:
            editor_events_draw_inspector_modal(_map);
            break;
        case EDITOR_MODAL.OBJECT_INSPECTOR:
            editor_objects_draw_inspector_modal(_map);
            break;
        case EDITOR_MODAL.NPC_INSPECTOR:
            editor_npcs_draw_inspector_modal(_map);
            break;
        case EDITOR_MODAL.ENEMY_INSPECTOR:
            editor_enemies_draw_inspector_modal(_map);
            break;
        case EDITOR_MODAL.CHARACTER_MANAGER:
            editor_characters_draw_modal();
            break;
        case EDITOR_MODAL.ITEM_MANAGER:
            editor_items_draw_modal();
            break;
        case EDITOR_MODAL.VARIABLE_MANAGER:
            editor_variables_draw_modal();
            break;
        case EDITOR_MODAL.AUDIO_MANAGER:
            editor_audio_draw_modal(_map);
            break;
        case EDITOR_MODAL.SPRITE_MANAGER:
            editor_sprites_draw_modal();
            break;
        case EDITOR_MODAL.PROJECT_MANAGER:
        case EDITOR_MODAL.UNSAVED_CONFIRM:
            editor_project_draw_modal();
            break;
        case EDITOR_MODAL.MAP_MANAGER:
            editor_map_draw_manager_modal(_map);
            break;
    }
}
