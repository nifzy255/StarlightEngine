/// @description ST★RLIGHT ENGINE - Party Management System
/// Manages active party members, recruitment, removal, healing, and party-wide status checks.

function sys_party_init_starting_roster() {
    global.runtime.party = [];
    if (is_undefined(global.project)) return;
    
    var _start_id = variable_struct_exists(global.project, "starting_char_id") ? global.project.starting_char_id : "";
    var _def = sys_character_find_def(_start_id);
    if (is_undefined(_def) && array_length(global.project.characters) > 0) {
        _def = global.project.characters[0];
    }
    if (is_undefined(_def)) {
        _def = sys_character_create_default("char_01", "Hero");
    }
    
    array_push(global.runtime.party, sys_character_instantiate_runtime(_def));
}

function sys_party_find_member(_char_id_or_name) {
    var _party = global.runtime.party;
    for (var i = 0; i < array_length(_party); i++) {
        if (_party[i].id == _char_id_or_name || _party[i].name == _char_id_or_name) {
            return _party[i];
        }
    }
    return undefined;
}

function sys_party_add_member(_char_id_or_name) {
    if (!is_undefined(sys_party_find_member(_char_id_or_name))) {
        return false; // Already in active party
    }
    var _def = sys_character_find_def(_char_id_or_name);
    if (is_undefined(_def)) {
        core_log_warning("Party System", "Character definition not found: " + string(_char_id_or_name));
        return false;
    }
    var _inst = sys_character_instantiate_runtime(_def);
    array_push(global.runtime.party, _inst);
    core_log_toast(_inst.name + " joined the party!");
    return true;
}

function sys_party_remove_member(_char_id_or_name) {
    var _party = global.runtime.party;
    if (array_length(_party) <= 1) {
        core_log_warning("Party System", "Cannot remove the last remaining party member.");
        return false;
    }
    for (var i = 0; i < array_length(_party); i++) {
        if (_party[i].id == _char_id_or_name || _party[i].name == _char_id_or_name) {
            var _removed_name = _party[i].name;
            array_delete(_party, i, 1);
            core_log_toast(_removed_name + " left the party.");
            return true;
        }
    }
    return false;
}

function sys_party_heal_all() {
    var _party = global.runtime.party;
    for (var i = 0; i < array_length(_party); i++) {
        _party[i].current_hp = _party[i].max_hp;
        _party[i].rolling_hp = _party[i].max_hp;
        _party[i].current_mp = _party[i].max_mp;
        _party[i].status_effect = "";
    }
}

function sys_party_refill_hp() {
    var _party = global.runtime.party;
    for (var i = 0; i < array_length(_party); i++) {
        _party[i].current_hp = _party[i].max_hp;
        _party[i].rolling_hp = _party[i].max_hp;
    }
}

function sys_party_refill_mp() {
    var _party = global.runtime.party;
    for (var i = 0; i < array_length(_party); i++) {
        _party[i].current_mp = _party[i].max_mp;
    }
}

function sys_party_is_defeated() {
    var _party = global.runtime.party;
    if (array_length(_party) == 0) return true;
    for (var i = 0; i < array_length(_party); i++) {
        if (_party[i].current_hp > 0) return false;
    }
    return true;
}
