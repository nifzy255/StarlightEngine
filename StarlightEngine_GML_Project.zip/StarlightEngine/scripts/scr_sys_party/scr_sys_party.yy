{
  "$GMScript": "v1",
  "%Name": "scr_sys_party",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_sys_party",
  "parent": {
    "name": "Systems",
    "path": "folders/Engine/Systems.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}