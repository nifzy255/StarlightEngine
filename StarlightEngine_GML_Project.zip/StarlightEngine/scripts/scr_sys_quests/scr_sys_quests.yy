{
  "$GMScript": "v1",
  "%Name": "scr_sys_quests",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_sys_quests",
  "parent": {
    "name": "Systems",
    "path": "folders/Engine/Systems.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}