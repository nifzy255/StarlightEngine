/// @description ST★RLIGHT ENGINE - Quest System
/// Tracks quest progression, variable-linked objectives, and completion rewards.

function sys_quest_init_runtime() {
    global.runtime.quests = {};
    if (is_undefined(global.project) || !variable_struct_exists(global.project, "quests")) return;
    
    var _qlist = global.project.quests;
    for (var i = 0; i < array_length(_qlist); i++) {
        var _q = _qlist[i];
        variable_struct_set(global.runtime.quests, _q.id, {
            id: _q.id,
            title: _q.title,
            description: _q.description,
            state: "inactive" // inactive, active, completed
        });
    }
}

function sys_quest_set_state(_quest_id, _state) {
    if (!is_struct(global.runtime) || !is_struct(global.runtime.quests)) return;
    if (variable_struct_exists(global.runtime.quests, _quest_id)) {
        var _q = variable_struct_get(global.runtime.quests, _quest_id);
        _q.state = _state;
        core_log_toast("Quest Updated: " + _q.title + " (" + _state + ")");
    }
}
