/// @description ST★RLIGHT ENGINE - Event Command Database & Execution Engine
/// Implements all 34 centralized event commands across Party, Inventory, Audio, Variable,
/// Character, Map, Dialogue, and Other categories with frame-safe sequential execution.

#macro MAX_EVENT_COMMANDS_PER_FRAME 64

function sys_event_get_command_catalog() {
    return [
        // Party Commands
        { cmd: "add_party_member", category: "Party", label: "Add Party Member", p1_name: "Character ID", p2_name: "", default_p1: "char_01", default_p2: "" },
        { cmd: "remove_party_member", category: "Party", label: "Remove Party Member", p1_name: "Character ID", p2_name: "", default_p1: "char_01", default_p2: "" },
        
        // Inventory Commands
        { cmd: "add_item", category: "Inventory", label: "Add Item", p1_name: "Item ID", p2_name: "Quantity", default_p1: "item_star_burger", default_p2: "1" },
        { cmd: "remove_item", category: "Inventory", label: "Remove Item", p1_name: "Item ID", p2_name: "Quantity", default_p1: "item_star_burger", default_p2: "1" },
        { cmd: "check_item_quantity", category: "Inventory", label: "Check Item Quantity", p1_name: "Item ID", p2_name: "Min Quantity", default_p1: "item_star_burger", default_p2: "1" },
        
        // Audio Commands
        { cmd: "pause_music", category: "Audio", label: "Pause Music", p1_name: "", p2_name: "", default_p1: "", default_p2: "" },
        { cmd: "resume_music", category: "Audio", label: "Resume Music", p1_name: "", p2_name: "", default_p1: "", default_p2: "" },
        { cmd: "stop_music", category: "Audio", label: "Stop Music", p1_name: "", p2_name: "", default_p1: "", default_p2: "" },
        { cmd: "start_music", category: "Audio", label: "Start Music", p1_name: "Track ID", p2_name: "Repeat (TRUE/FALSE)", default_p1: "bgm_hometown", default_p2: "TRUE" },
        { cmd: "play_sfx", category: "Audio", label: "Play Sound Effect", p1_name: "Sound ID", p2_name: "", default_p1: "sfx_chime", default_p2: "" },
        
        // Variable Commands
        { cmd: "set_variable", category: "Variable", label: "Set Variable", p1_name: "Variable Name", p2_name: "Value (TRUE/FALSE)", default_p1: "VAR_01", default_p2: "TRUE" },
        { cmd: "toggle_variable", category: "Variable", label: "Toggle Variable", p1_name: "Variable Name", p2_name: "", default_p1: "VAR_01", default_p2: "" },
        { cmd: "check_variable", category: "Variable", label: "Check Variable", p1_name: "Variable Name", p2_name: "Expected (TRUE/FALSE)", default_p1: "VAR_01", default_p2: "TRUE" },
        
        // Character Commands
        { cmd: "add_exp", category: "Character", label: "Add EXP", p1_name: "Amount", p2_name: "Character ID (or ALL)", default_p1: "25", default_p2: "ALL" },
        { cmd: "set_exp", category: "Character", label: "Set EXP", p1_name: "Amount", p2_name: "Character ID", default_p1: "0", default_p2: "char_01" },
        { cmd: "add_gold", category: "Character", label: "Add Gold", p1_name: "Amount", p2_name: "", default_p1: "50", default_p2: "" },
        { cmd: "take_gold", category: "Character", label: "Take Gold", p1_name: "Amount", p2_name: "", default_p1: "20", default_p2: "" },
        { cmd: "refill_hp", category: "Character", label: "Refill HP", p1_name: "", p2_name: "", default_p1: "", default_p2: "" },
        { cmd: "refill_mp", category: "Character", label: "Refill MP", p1_name: "", p2_name: "", default_p1: "", default_p2: "" },
        { cmd: "change_char_stats", category: "Character", label: "Change Character Statistics", p1_name: "Stat (attack/defense/speed/max_hp)", p2_name: "Delta (+/-)", default_p1: "attack", default_p2: "2" },
        
        // Map Commands
        { cmd: "teleport_map", category: "Map", label: "Teleport To Map", p1_name: "Destination Map ID", p2_name: "Grid X,Y (e.g. 5,8)", default_p1: "map_01", default_p2: "5,5" },
        { cmd: "change_player_pos", category: "Map", label: "Change Player Position", p1_name: "Grid X", p2_name: "Grid Y", default_p1: "5", default_p2: "5" },
        { cmd: "change_player_dir", category: "Map", label: "Change Player Direction", p1_name: "Direction (DOWN/LEFT/RIGHT/UP)", p2_name: "", default_p1: "DOWN", default_p2: "" },
        
        // Dialogue Commands
        { cmd: "display_dialogue", category: "Dialogue", label: "Display Dialogue", p1_name: "Dialogue Text", p2_name: "Speaker Name (Optional)", default_p1: "A mysterious starlight shines overhead.", default_p2: "" },
        { cmd: "display_choices", category: "Dialogue", label: "Display Choices", p1_name: "Prompt Text", p2_name: "Yes Var / No Var", default_p1: "Will you accept this quest?", default_p2: "VAR_QUEST_YES" },
        { cmd: "conditional_dialogue", category: "Dialogue", label: "Conditional Dialogue Branch", p1_name: "Variable Name", p2_name: "True Text | False Text", default_p1: "VAR_01", default_p2: "Thank you for helping!|Please help us!" },
        
        // Other Commands
        { cmd: "wait", category: "Other", label: "Wait", p1_name: "Duration (Frames)", p2_name: "", default_p1: "30", default_p2: "" },
        { cmd: "play_animation", category: "Other", label: "Play Animation", p1_name: "Animation Name", p2_name: "Target", default_p1: "Attacking", default_p2: "player" },
        { cmd: "change_screen_fade", category: "Other", label: "Change Screen Fade", p1_name: "Target Alpha (0.0 - 1.0)", p2_name: "Speed", default_p1: "0.0", default_p2: "0.08" },
        { cmd: "change_background", category: "Other", label: "Change Background", p1_name: "R,G,B Color", p2_name: "", default_p1: "12,16,38", default_p2: "" },
        { cmd: "start_battle", category: "Other", label: "Start Battle", p1_name: "Enemy ID", p2_name: "", default_p1: "enemy_stardust_mite", default_p2: "" },
        { cmd: "heal_party", category: "Other", label: "Heal Party", p1_name: "", p2_name: "", default_p1: "", default_p2: "" },
        { cmd: "change_char_name", category: "Other", label: "Change Character Name", p1_name: "Character ID", p2_name: "New Name", default_p1: "char_01", default_p2: "Star Hero" },
        { cmd: "set_player_movement", category: "Other", label: "Set Player Movement Enabled", p1_name: "Enabled (TRUE/FALSE)", p2_name: "", default_p1: "TRUE", default_p2: "" }
    ];
}

function sys_event_create_command(_cmd_type, _p1, _p2) {
    return {
        cmd: _cmd_type,
        p1: is_undefined(_p1) ? "" : string(_p1),
        p2: is_undefined(_p2) ? "" : string(_p2)
    };
}

function sys_event_init_runner() {
    return {
        active: false,
        queue: [],
        pc: 0,
        wait_frames: 0,
        condition_passed: true,
        active_event_id: ""
    };
}

function sys_event_enqueue_commands(_cmd_array) {
    if (!is_array(_cmd_array) || array_length(_cmd_array) == 0) return;
    var _runner = global.runtime.event_runner;
    for (var i = 0; i < array_length(_cmd_array); i++) {
        array_push(_runner.queue, _cmd_array[i]);
    }
    _runner.active = true;
}

function sys_event_trigger_map_event(_ev_struct) {
    if (!is_struct(_ev_struct)) return false;
    var _ev_id = variable_struct_exists(_ev_struct, "id") ? _ev_struct.id : "";
    
    // Check one-time completion
    var _one_time = variable_struct_exists(_ev_struct, "one_time") ? _ev_struct.one_time : false;
    if (_one_time && _ev_id != "" && variable_struct_exists(global.runtime.completed_events, _ev_id)) {
        return false;
    }
    
    // Check variable trigger condition if configured
    if (variable_struct_exists(_ev_struct, "condition_var") && _ev_struct.condition_var != "") {
        var _exp_val = variable_struct_exists(_ev_struct, "condition_val") ? _ev_struct.condition_val : true;
        if (!sys_variable_check(_ev_struct.condition_var, _exp_val)) {
            return false;
        }
    }
    
    if (_one_time && _ev_id != "") {
        variable_struct_set(global.runtime.completed_events, _ev_id, true);
    }
    
    if (variable_struct_exists(_ev_struct, "commands") && is_array(_ev_struct.commands)) {
        global.runtime.event_runner.active_event_id = _ev_id;
        global.runtime.event_runner.condition_passed = true;
        sys_event_enqueue_commands(_ev_struct.commands);
        return true;
    }
    return false;
}

function sys_event_trigger_by_id(_event_id) {
    var _map = editor_map_find_by_id(global.runtime.current_map_id);
    if (!is_struct(_map) || !variable_struct_exists(_map, "events")) return false;
    for (var i = 0; i < array_length(_map.events); i++) {
        if (_map.events[i].id == _event_id || _map.events[i].name == _event_id) {
            return sys_event_trigger_map_event(_map.events[i]);
        }
    }
    return false;
}

/// @function sys_event_update()
/// @description Executes queued event commands in order with wait timers and infinite-loop protection.
function sys_event_update() {
    var _runner = global.runtime.event_runner;
    if (!_runner.active) return;
    
    // Pause event advancement while dialogue box is actively open
    if (global.runtime.dialogue.active) return;
    
    // Wait timer
    if (_runner.wait_frames > 0) {
        _runner.wait_frames--;
        return;
    }
    
    var _steps_this_frame = 0;
    while (_runner.pc < array_length(_runner.queue) && _steps_this_frame < MAX_EVENT_COMMANDS_PER_FRAME) {
        _steps_this_frame++;
        var _entry = _runner.queue[_runner.pc];
        _runner.pc++;
        
        var _should_yield = sys_event_execute_single(_entry);
        if (_should_yield || global.runtime.dialogue.active || _runner.wait_frames > 0 || global.scene.current == ENGINE_SCENE.RUNTIME_BATTLE) {
            break;
        }
    }
    
    if (_runner.pc >= array_length(_runner.queue)) {
        _runner.queue = [];
        _runner.pc = 0;
        _runner.active = false;
        _runner.condition_passed = true;
        _runner.active_event_id = "";
    }
}

function sys_event_execute_single(_entry) {
    if (!is_struct(_entry) || !variable_struct_exists(_entry, "cmd")) return false;
    var _cmd = _entry.cmd;
    var _p1 = variable_struct_exists(_entry, "p1") ? string(_entry.p1) : "";
    var _p2 = variable_struct_exists(_entry, "p2") ? string(_entry.p2) : "";
    var _runner = global.runtime.event_runner;
    
    // Check Commands update _runner.condition_passed; if previous check failed, skip until next check or end
    if (_cmd != "check_variable" && _cmd != "check_item_quantity" && !_runner.condition_passed) {
        return false;
    }
    
    switch (_cmd) {
        // ---- PARTY COMMANDS ----
        case "add_party_member":
            sys_party_add_member(_p1);
            break;
        case "remove_party_member":
            sys_party_remove_member(_p1);
            break;
            
        // ---- INVENTORY COMMANDS ----
        case "add_item":
            var _add_qty = (_p2 != "") ? max(1, round(real(_p2))) : 1;
            sys_inventory_add_item(_p1, _add_qty);
            break;
        case "remove_item":
            var _rem_qty = (_p2 != "") ? max(1, round(real(_p2))) : 1;
            sys_inventory_remove_item(_p1, _rem_qty);
            break;
        case "check_item_quantity":
            var _req_qty = (_p2 != "") ? max(1, round(real(_p2))) : 1;
            _runner.condition_passed = (sys_inventory_get_quantity(_p1) >= _req_qty);
            break;
            
        // ---- AUDIO COMMANDS ----
        case "pause_music":
            core_audio_pause_music();
            break;
        case "resume_music":
            core_audio_resume_music();
            break;
        case "stop_music":
            core_audio_stop_music();
            break;
        case "start_music":
            var _loop = (string_upper(_p2) != "FALSE" && _p2 != "0");
            core_audio_start_music(_p1, _loop);
            break;
        case "play_sfx":
            core_audio_play_sfx(_p1);
            break;
            
        // ---- VARIABLE COMMANDS ----
        case "set_variable":
            var _val = (string_upper(_p2) == "TRUE" || _p2 == "1");
            sys_variable_set(_p1, _val);
            break;
        case "toggle_variable":
            sys_variable_toggle(_p1);
            break;
        case "check_variable":
            var _exp = (_p2 == "" || string_upper(_p2) == "TRUE" || _p2 == "1");
            _runner.condition_passed = sys_variable_check(_p1, _exp);
            break;
            
        // ---- CHARACTER COMMANDS ----
        case "add_exp":
            var _exp_amt = max(0, round(real(_p1)));
            for (var i = 0; i < array_length(global.runtime.party); i++) {
                var _member = global.runtime.party[i];
                if (_p2 == "" || string_upper(_p2) == "ALL" || _member.id == _p2 || _member.name == _p2) {
                    var _lv_msgs = sys_leveling_add_exp(_member, _exp_amt);
                    for (var m = 0; m < array_length(_lv_msgs); m++) {
                        core_log_toast(_lv_msgs[m]);
                    }
                }
            }
            break;
        case "set_exp":
            var _set_amt = max(0, round(real(_p1)));
            var _tchar = sys_party_find_member(_p2);
            if (!is_struct(_tchar) && array_length(global.runtime.party) > 0) _tchar = global.runtime.party[0];
            if (is_struct(_tchar)) sys_leveling_set_exp(_tchar, _set_amt);
            break;
        case "add_gold":
            var _g_add = max(0, round(real(_p1)));
            global.runtime.gold += _g_add;
            global.runtime.stats_telemetry.total_gold_earned += _g_add;
            core_log_toast("Received " + string(_g_add) + " Gold!");
            break;
        case "take_gold":
            var _g_take = max(0, round(real(_p1)));
            global.runtime.gold = max(0, global.runtime.gold - _g_take);
            break;
        case "refill_hp":
            sys_party_refill_hp();
            core_audio_play_default_sound("battle_heal");
            core_log_toast("Party HP fully restored!");
            break;
        case "refill_mp":
            sys_party_refill_mp();
            core_log_toast("Party PP/MP fully restored!");
            break;
        case "change_char_stats":
            if (array_length(global.runtime.party) > 0) {
                var _leader = global.runtime.party[0];
                var _delta = round(real(_p2));
                var _stat_name = string_lower(_p1);
                if (_stat_name == "attack") _leader.attack = max(1, _leader.attack + _delta);
                else if (_stat_name == "defense") _leader.defense = max(0, _leader.defense + _delta);
                else if (_stat_name == "speed") _leader.speed = max(1, _leader.speed + _delta);
                else if (_stat_name == "max_hp") {
                    _leader.max_hp = max(1, _leader.max_hp + _delta);
                    _leader.current_hp = min(_leader.max_hp, _leader.current_hp + max(0, _delta));
                }
            }
            break;
            
        // ---- MAP COMMANDS ----
        case "teleport_map":
            var _gx = 4;
            var _gy = 4;
            var _comma = string_pos(",", _p2);
            if (_comma > 0) {
                _gx = real(string_copy(_p2, 1, _comma - 1));
                _gy = real(string_copy(_p2, _comma + 1, string_length(_p2) - _comma));
            }
            var _dest_map_struct = editor_map_find_by_id(_p1);
            var _tsize = is_struct(_dest_map_struct) ? _dest_map_struct.tile_size : 32;
            sys_transition_load_map(_p1, _gx * _tsize, _gy * _tsize, global.runtime.player_facing, true);
            return true;
            
        case "change_player_pos":
            var _map_cur = editor_map_find_by_id(global.runtime.current_map_id);
            var _cell_sz = is_struct(_map_cur) ? _map_cur.tile_size : 32;
            global.runtime.player_x = real(_p1) * _cell_sz;
            global.runtime.player_y = real(_p2) * _cell_sz;
            break;
            
        case "change_player_dir":
            var _du = string_upper(_p1);
            if (_du == "UP") global.runtime.player_facing = DIR_FACING.UP;
            else if (_du == "LEFT") global.runtime.player_facing = DIR_FACING.LEFT;
            else if (_du == "RIGHT") global.runtime.player_facing = DIR_FACING.RIGHT;
            else global.runtime.player_facing = DIR_FACING.DOWN;
            break;
            
        // ---- DIALOGUE COMMANDS ----
        case "display_dialogue":
            sys_dialogue_start_simple(_p1, _p2, []);
            return true;
            
        case "display_choices":
            var _yes_var = (_p2 != "") ? _p2 : "VAR_CHOICE_YES";
            var _choices = [
                { label: "YES", next_node_id: "END", set_var: _yes_var, set_val: true, event_commands: [] },
                { label: "NO", next_node_id: "END", set_var: _yes_var, set_val: false, event_commands: [] }
            ];
            sys_dialogue_start_simple(_p1, "", _choices);
            return true;
            
        case "conditional_dialogue":
            var _pipe = string_pos("|", _p2);
            var _true_txt = (_pipe > 0) ? string_copy(_p2, 1, _pipe - 1) : _p2;
            var _false_txt = (_pipe > 0) ? string_copy(_p2, _pipe + 1, string_length(_p2) - _pipe) : "";
            var _chosen = sys_variable_check(_p1, true) ? _true_txt : _false_txt;
            if (_chosen != "") {
                sys_dialogue_start_simple(_chosen, "", []);
                return true;
            }
            break;
            
        // ---- OTHER COMMANDS ----
        case "wait":
            _runner.wait_frames = max(1, round(real(_p1)));
            return true;
            
        case "play_animation":
            global.runtime.player_anim_state = (_p1 != "") ? _p1 : "Idle";
            break;
            
        case "change_screen_fade":
            global.scene.fade_target = clamp(real(_p1), 0.0, 1.0);
            if (_p2 != "") global.scene.fade_speed = clamp(real(_p2), 0.01, 0.5);
            break;
            
        case "change_background":
            global.runtime.bg_override_str = _p1;
            break;
            
        case "start_battle":
            sys_battle_initiate_by_enemy_id(_p1, undefined);
            return true;
            
        case "heal_party":
            sys_party_heal_all();
            core_audio_play_default_sound("battle_heal");
            core_log_toast("The entire party was healed!");
            break;
            
        case "change_char_name":
            var _target_c = sys_party_find_member(_p1);
            if (!is_struct(_target_c) && array_length(global.runtime.party) > 0) _target_c = global.runtime.party[0];
            if (is_struct(_target_c) && _p2 != "") {
                _target_c.name = _p2;
            }
            break;
            
        case "set_player_movement":
            global.runtime.player_movement_enabled = (string_upper(_p1) != "FALSE" && _p1 != "0");
            break;
    }
    return false;
}
