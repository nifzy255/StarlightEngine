{
  "$GMScript": "v1",
  "%Name": "scr_sys_events",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_sys_events",
  "parent": {
    "name": "Systems",
    "path": "folders/Engine/Systems.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}