/// @description ST★RLIGHT ENGINE - Sprite, Animation & 4-Direction Manager
/// Configures per-animation & per-direction frame counts, FPS, loop flags, strip/per-frame PNG imports, and live preview.

function editor_sprites_ensure_dedicated_entry(_sprite_id, _display_name, _archetype, _default_fc) {
    if (is_undefined(global.project)) return undefined;
    if (!is_array(global.project.sprites)) global.project.sprites = [];
    
    for (var i = 0; i < array_length(global.project.sprites); i++) {
        if (global.project.sprites[i].id == _sprite_id) {
            sys_sprite_normalize_animations(global.project.sprites[i]);
            return global.project.sprites[i];
        }
    }
    var _fc = max(1, _default_fc);
    var _new_sp = {
        id: _sprite_id,
        name: (_display_name != "") ? _display_name : _sprite_id,
        file_path: "",
        archetype: (_archetype != "") ? _archetype : "character",
        primary_color: make_color_rgb(92, 198, 245),
        secondary_color: make_color_rgb(255, 214, 74),
        frame_count: _fc,
        animations: sys_sprite_create_default_animations()
    };
    _new_sp.animations.Idle.frame_count = _fc;
    _new_sp.animations.Idle.directions.Down.frame_count = _fc;
    sys_sprite_normalize_animations(_new_sp);
    array_push(global.project.sprites, _new_sp);
    global.project_dirty = true;
    return _new_sp;
}

function editor_sprites_import_entity_png(_sprite_id, _display_name, _archetype, _default_fc) {
    var _src = get_open_filename("PNG Sprite Image (*.png)|*.png", "");
    if (_src == "" || !file_exists(_src)) return false;
    
    var _rel = editor_sprites_copy_png_to_project(_src, _sprite_id);
    var _sp = editor_sprites_ensure_dedicated_entry(_sprite_id, _display_name, _archetype, _default_fc);
    if (!is_struct(_sp)) return false;
    
    _sp.file_path = _rel;
    if (_display_name != "") _sp.name = _display_name;
    // Also set on Idle Down if no directional Idle was set yet so single-PNG entities display immediately
    if (_sp.animations.Idle.directions.Down.file_path == "") {
        _sp.animations.Idle.directions.Down.file_path = _rel;
    }
    core_assets_clear_cache();
    global.project_dirty = true;
    core_log_toast("Imported custom PNG for '" + _sp.name + "'.");
    return true;
}

function editor_sprites_clear_entity_custom_png(_sprite_id) {
    var _def = core_assets_find_sprite_def(_sprite_id);
    if (!is_struct(_def)) return false;
    _def.file_path = "";
    var _skeys = ["Idle", "Walking", "Running", "Attacking", "TakingDamage", "Defeated"];
    var _dkeys = ["Down", "Up", "Left", "Right"];
    for (var s = 0; s < 6; s++) {
        var _st = variable_struct_get(_def.animations, _skeys[s]);
        if (is_struct(_st)) {
            _st.file_path = "";
            _st.frame_files = array_create(max(1, _st.frame_count), "");
            if (is_struct(_st.directions)) {
                for (var d = 0; d < 4; d++) {
                    var _dc = variable_struct_get(_st.directions, _dkeys[d]);
                    if (is_struct(_dc)) {
                        _dc.file_path = "";
                        _dc.frame_files = array_create(max(1, _dc.frame_count), "");
                    }
                }
            }
        }
    }
    core_assets_clear_cache();
    global.project_dirty = true;
    return true;
}

function editor_sprites_open_for_id(_sprite_id) {
    if (is_undefined(global.project)) return;
    if (!is_array(global.project.sprites)) global.project.sprites = [];
    
    var _target_id = (_sprite_id != "") ? _sprite_id : ("spr_custom_" + string(array_length(global.project.sprites) + 1));
    editor_sprites_ensure_dedicated_entry(_target_id, _target_id, "character", 4);
    
    var _found_idx = 0;
    for (var i = 0; i < array_length(global.project.sprites); i++) {
        if (global.project.sprites[i].id == _target_id) {
            _found_idx = i;
            break;
        }
    }
    if (global.editor.active_modal != EDITOR_MODAL.SPRITE_MANAGER) {
        global.editor.return_modal = global.editor.active_modal;
    }
    global.editor.selected_sprite_idx = _found_idx;
    global.editor.active_modal = EDITOR_MODAL.SPRITE_MANAGER;
}

function editor_sprites_copy_png_to_project(_src, _prefix) {
    var _fname = filename_name(_src);
    var _rel = "sprites/" + _prefix + "_" + string(current_time) + "_" + _fname;
    if (global.project_path != "") {
        directory_create(global.project_path + "sprites/");
        file_copy(_src, global.project_path + _rel);
    } else {
        _rel = _src;
    }
    return _rel;
}

function editor_sprites_import_png() {
    var _src = get_open_filename("PNG Sprite Image (*.png)|*.png", "");
    if (_src == "" || !file_exists(_src)) return false;
    
    var _fname = filename_name(_src);
    var _rel = editor_sprites_copy_png_to_project(_src, "base");
    
    var _nid = "spr_custom_" + string(array_length(global.project.sprites) + 1);
    array_push(global.project.sprites, {
        id: _nid,
        name: _fname,
        file_path: _rel,
        archetype: "character",
        primary_color: make_color_rgb(92, 225, 230),
        secondary_color: make_color_rgb(255, 214, 74),
        frame_count: 4,
        animations: sys_sprite_create_default_animations()
    });
    global.editor.selected_sprite_idx = array_length(global.project.sprites) - 1;
    global.project_dirty = true;
    core_log_toast("Created New Sprite: " + _fname);
    return true;
}

/// @function editor_sprites_import_into_clip(_clip, _state_key, _dir_key, _mode)
/// @description Imports a PNG into a specific animation & direction (_mode: 0=Strip/All, 1=Append Frame, 2=Replace Selected Frame).
function editor_sprites_import_into_clip(_clip, _state_key, _dir_key, _mode) {
    if (!is_struct(_clip)) return false;
    var _src = get_open_filename("PNG Animation Frame/Strip (*.png)|*.png", "");
    if (_src == "" || !file_exists(_src)) return false;
    
    var _tag = string_lower(_state_key + "_" + _dir_key);
    var _rel = editor_sprites_copy_png_to_project(_src, _tag);
    
    if (_mode == 0) {
        // Import strip/sheet into this specific animation + direction only
        _clip.file_path = _rel;
        var _probe = sprite_add(_src, 1, false, false, 0, 0);
        if (_probe >= 0 && sprite_exists(_probe)) {
            var _pw = max(1, sprite_get_width(_probe));
            var _ph = max(1, sprite_get_height(_probe));
            if (_pw >= _ph && (_pw mod _ph) == 0) {
                var _auto_frames = clamp(_pw div _ph, 1, 64);
                _clip.frame_count = _auto_frames;
            }
            sprite_delete(_probe);
        }
        sys_sprite_normalize_clip(_clip, _clip.frames, _clip.fps, _clip.loop);
        core_log_toast("Imported strip into " + _state_key + " (" + _dir_key + ") [" + string(_clip.frame_count) + "f]");
    } else if (_mode == 1) {
        // Append a new individual frame PNG to this animation + direction
        sys_sprite_normalize_clip(_clip, _clip.frames, _clip.fps, _clip.loop);
        if (_clip.frame_count == 1 && _clip.frame_files[0] == "" && _clip.file_path == "") {
            _clip.frame_files[0] = _rel;
            global.editor.sprite_frame_idx = 0;
        } else {
            _clip.frame_count = min(64, _clip.frame_count + 1);
            array_push(_clip.frames, _clip.frame_count - 1);
            array_push(_clip.frame_files, _rel);
            global.editor.sprite_frame_idx = _clip.frame_count - 1;
        }
        core_log_toast("Added frame PNG to " + _state_key + " (" + _dir_key + ") [Frame #" + string(global.editor.sprite_frame_idx + 1) + "]");
    } else if (_mode == 2) {
        // Replace only the currently selected frame in this animation + direction
        sys_sprite_normalize_clip(_clip, _clip.frames, _clip.fps, _clip.loop);
        var _fidx = clamp(global.editor.sprite_frame_idx, 0, _clip.frame_count - 1);
        _clip.frame_files[_fidx] = _rel;
        core_log_toast("Replaced Frame #" + string(_fidx + 1) + " in " + _state_key + " (" + _dir_key + ")");
    }
    
    global.project_dirty = true;
    return true;
}

function editor_sprites_dir_name_to_enum(_dir_name) {
    if (_dir_name == "Up") return DIR_FACING.UP;
    if (_dir_name == "Left") return DIR_FACING.LEFT;
    if (_dir_name == "Right") return DIR_FACING.RIGHT;
    return DIR_FACING.DOWN;
}

function editor_sprites_draw_modal() {
    var _ed = global.editor;
    var _pal = global.palette;
    
    if (!is_array(global.project.sprites) || array_length(global.project.sprites) == 0) {
        global.project.sprites = [{
            id: "spr_hero_default",
            name: "Hero Standard Sprite",
            file_path: "",
            archetype: "character",
            primary_color: make_color_rgb(92, 198, 245),
            secondary_color: make_color_rgb(255, 214, 74),
            frame_count: 4,
            animations: sys_sprite_create_default_animations()
        }];
    }
    
    var _slist = global.project.sprites;
    _ed.selected_sprite_idx = clamp(_ed.selected_sprite_idx, 0, array_length(_slist) - 1);
    var _sp = _slist[_ed.selected_sprite_idx];
    sys_sprite_normalize_animations(_sp);
    
    render_window_frame(84, 32, 1196, 688, "SPRITE & DIRECTIONAL ANIMATION MANAGER — " + _sp.name + " [" + _sp.id + "]", _pal.accent_cyan);
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    
    // Top Sprite Selector Bar
    if (render_ui_button(108, 74, 236, 110, "< Prev Sprite", false, array_length(_slist) > 1)) {
        input_end_text_edit();
        _ed.selected_sprite_idx = (_ed.selected_sprite_idx + array_length(_slist) - 1) mod array_length(_slist);
        _ed.sprite_frame_idx = 0;
        return;
    }
    if (render_ui_button(244, 74, 372, 110, "Next Sprite >", false, array_length(_slist) > 1)) {
        input_end_text_edit();
        _ed.selected_sprite_idx = (_ed.selected_sprite_idx + 1) mod array_length(_slist);
        _ed.sprite_frame_idx = 0;
        return;
    }
    if (render_ui_button(382, 74, 572, 110, "+ New Sprite Asset", false, true)) {
        input_end_text_edit();
        var _nid = "spr_custom_" + string(array_length(_slist) + 1);
        array_push(_slist, {
            id: _nid,
            name: "Custom Sprite " + string(array_length(_slist) + 1),
            file_path: "",
            archetype: "character",
            primary_color: make_color_rgb(92, 225, 230),
            secondary_color: make_color_rgb(255, 214, 74),
            frame_count: 4,
            animations: sys_sprite_create_default_animations()
        });
        _ed.selected_sprite_idx = array_length(_slist) - 1;
        global.project_dirty = true;
        return;
    }
    if (render_ui_button(582, 74, 846, 110, "+ Import Full Sprite PNG...", false, true)) {
        input_end_text_edit();
        editor_sprites_import_png();
        return;
    }
    
    // =========================================================================
    // LEFT COLUMN: Custom Sprite ID, Name, Live Directional Preview & Filmstrip
    // =========================================================================
    draw_set_color(_pal.accent_gold);
    draw_text(108, 122, "Custom Sprite ID:");
    render_ui_custom_id_field("sp_custom_id", "sprite", _sp, 108, 146, 448, 180);
    
    draw_set_color(_pal.accent_gold);
    draw_text(108, 188, "Display Name:");
    _sp.name = render_ui_text_field("sp_name", 108, 212, 448, 246, _sp.name, 40);
    
    var _active_state = _ed.sprite_anim_state;
    if (!variable_struct_exists(_sp.animations, _active_state)) _active_state = "Walking";
    var _st_obj = variable_struct_get(_sp.animations, _active_state);
    var _active_dir = _st_obj.directional ? _ed.sprite_anim_dir : "Down";
    var _clip = sys_sprite_get_clip(_sp, _active_state, _active_dir);
    sys_sprite_normalize_clip(_clip, _clip.frames, _clip.fps, _clip.loop);
    
    _ed.sprite_frame_idx = clamp(_ed.sprite_frame_idx, 0, max(0, _clip.frame_count - 1));
    var _facing_enum = editor_sprites_dir_name_to_enum(_active_dir);
    
    // Live Animation Preview Box (Shows 1.0x reference outline + scaled sprite)
    if (!variable_struct_exists(_sp, "scale")) _sp.scale = 1.0;
    _sp.scale = sys_sprite_clamp_scale(_sp.scale);
    var _dims = core_assets_get_sprite_dimensions(_sp.id, _active_state, _facing_enum);
    var _scaled_w = max(1, round(_dims.orig_w * _sp.scale));
    var _scaled_h = max(1, round(_dims.orig_h * _sp.scale));
    
    draw_set_color(_pal.accent_cyan);
    draw_text(108, 256, "PREVIEW (" + string(_sp.scale) + "x): " + string(_dims.orig_w) + "x" + string(_dims.orig_h) + " -> " + string(_scaled_w) + "x" + string(_scaled_h) + "px");
    
    var _anim_f = _ed.sprite_preview_playing
        ? ((global.engine.frame_counter * (_clip.fps / 60.0)) mod max(1, _clip.frame_count))
        : _ed.sprite_frame_idx;
    core_assets_draw_scaled_preview_box(108, 282, 276, 450, _sp.id, _active_state, _anim_f, _facing_enum, undefined, 1.0, _pal.border_outer);
    
    // Preview Playback & Sprite Scale Controls next to Preview Box
    draw_set_color(_pal.text_primary);
    draw_text(286, 282, "Frames: " + string(_clip.frame_count) + " | " + string(_clip.fps) + " FPS");
    
    draw_set_color(_pal.accent_gold);
    draw_text(286, 308, "Scale (0.1..8.0x):");
    var _new_sp_sc = render_ui_number_field("sp_scale_val", 286, 330, 382, 364, _sp.scale, 0.1, 8.0, true);
    if (_new_sp_sc != _sp.scale) {
        _sp.scale = sys_sprite_clamp_scale(_new_sp_sc);
        global.project_dirty = true;
    }
    if (render_ui_button(388, 330, 448, 364, "1.0x", (_sp.scale == 1.0), true)) {
        _sp.scale = 1.0;
        global.project_dirty = true;
    }
    
    if (render_ui_button(286, 372, 448, 408, _ed.sprite_preview_playing ? "⏸ Pause Preview" : "▶ Play Preview", _ed.sprite_preview_playing, true)) {
        _ed.sprite_preview_playing = !_ed.sprite_preview_playing;
    }
    if (render_ui_button(286, 414, 448, 450, "Step Frame >", false, !_ed.sprite_preview_playing)) {
        _ed.sprite_frame_idx = (_ed.sprite_frame_idx + 1) mod max(1, _clip.frame_count);
    }
    
    // Interactive Frame Filmstrip (Click any frame to inspect/replace/remove it)
    draw_set_color(_pal.accent_gold);
    draw_text(108, 464, "FRAME FILMSTRIP (Click Frame #" + string(_ed.sprite_frame_idx + 1) + " / " + string(_clip.frame_count) + "):");
    
    var _max_strip_vis = 4;
    if (_ed.sprite_frame_idx < _ed.sprite_filmstrip_scroll) _ed.sprite_filmstrip_scroll = _ed.sprite_frame_idx;
    if (_ed.sprite_frame_idx >= _ed.sprite_filmstrip_scroll + _max_strip_vis) _ed.sprite_filmstrip_scroll = _ed.sprite_frame_idx - _max_strip_vis + 1;
    _ed.sprite_filmstrip_scroll = clamp(_ed.sprite_filmstrip_scroll, 0, max(0, _clip.frame_count - _max_strip_vis));
    
    if (render_ui_button(108, 490, 138, 554, "<", false, _ed.sprite_filmstrip_scroll > 0)) {
        _ed.sprite_filmstrip_scroll--;
    }
    for (var f = 0; f < min(_max_strip_vis, _clip.frame_count - _ed.sprite_filmstrip_scroll); f++) {
        var _f_actual = _ed.sprite_filmstrip_scroll + f;
        var _fx1 = 144 + f * 66;
        var _fy1 = 490;
        var _fx2 = _fx1 + 60;
        var _fy2 = 554;
        var _fsel = (_ed.sprite_frame_idx == _f_actual);
        draw_set_color(_fsel ? make_color_rgb(46, 58, 108) : _pal.panel_alt);
        draw_rectangle(_fx1, _fy1, _fx2, _fy2, false);
        draw_set_color(_fsel ? _pal.accent_gold : _pal.border_inner);
        draw_rectangle(_fx1, _fy1, _fx2, _fy2, true);
        
        core_assets_draw_entity_sprite(_sp.id, _active_state, _f_actual, _fx1 + 12, _fy1 + 6, 36, 36, _facing_enum, undefined);
        draw_set_color(_fsel ? _pal.accent_gold : _pal.text_secondary);
        draw_text(_fx1 + 14, _fy1 + 40, "#" + string(_f_actual + 1));
        
        if (input_click_in_rect(_fx1, _fy1, _fx2, _fy2)) {
            _ed.sprite_frame_idx = _f_actual;
            core_audio_play_sfx_ui("ui_select");
        }
    }
    if (render_ui_button(412, 490, 448, 554, ">", false, (_ed.sprite_filmstrip_scroll + _max_strip_vis) < _clip.frame_count)) {
        _ed.sprite_filmstrip_scroll++;
    }
    
    // =========================================================================
    // RIGHT COLUMN: Animation State Tabs, 4 Facing Direction Tabs, & Frame Config
    // =========================================================================
    draw_set_color(_pal.accent_gold);
    draw_text(476, 122, "1. SELECT ANIMATION STATE:");
    
    var _state_keys = ["Idle", "Walking", "Running", "Attacking", "TakingDamage", "Defeated"];
    var _state_labels = ["Idle", "Walking", "Running", "Attacking", "Damage", "Defeated"];
    for (var s = 0; s < 6; s++) {
        var _sk = _state_keys[s];
        var _scol = s mod 3;
        var _srow = s div 3;
        var _sx1 = 476 + _scol * 232;
        var _sy1 = 148 + _srow * 42;
        var _sx2 = _sx1 + 220;
        var _sy2 = _sy1 + 36;
        var _st_item = variable_struct_get(_sp.animations, _sk);
        var _st_clip = sys_sprite_get_clip(_sp, _sk, _active_dir);
        var _lbl = _state_labels[s] + " (" + string(_st_clip.frame_count) + "f)";
        if (render_ui_button(_sx1, _sy1, _sx2, _sy2, _lbl, (_active_state == _sk), true)) {
            input_end_text_edit();
            _ed.sprite_anim_state = _sk;
            _ed.sprite_frame_idx = 0;
            _ed.sprite_filmstrip_scroll = 0;
            return;
        }
    }
    
    // Step 2: Select Facing Direction (Up, Down, Left, Right)
    draw_set_color(_pal.accent_cyan);
    if (_st_obj.directional) {
        draw_text(476, 240, "2. SELECT FACING DIRECTION FOR " + string_upper(_active_state) + ":");
        var _dirs = ["Down", "Up", "Left", "Right"];
        var _dir_icons = ["▼ Down", "▲ Up", "◀ Left", "▶ Right"];
        for (var d = 0; d < 4; d++) {
            var _dn = _dirs[d];
            var _dc = variable_struct_get(_st_obj.directions, _dn);
            var _has_c = sys_sprite_clip_has_custom_assets(_dc) ? " ★" : "";
            var _dx1 = 476 + d * 174;
            var _dx2 = _dx1 + 164;
            if (render_ui_button(_dx1, 266, _dx2, 304, _dir_icons[d] + " (" + string(_dc.frame_count) + "f)" + _has_c, (_active_dir == _dn), true)) {
                input_end_text_edit();
                _ed.sprite_anim_dir = _dn;
                _ed.sprite_frame_idx = 0;
                _ed.sprite_filmstrip_scroll = 0;
                return;
            }
        }
    } else {
        draw_text(476, 256, "2. DIRECTION: Non-Directional State (Applies to all facing directions)");
    }
    
    // Step 3: Configurable Frame Count, Add/Remove Frame, Speed/FPS, & Loop
    draw_set_color(_pal.accent_gold);
    draw_text(476, 318, "3. FRAME COUNT & ANIMATION SPEED (" + _active_state + (_st_obj.directional ? (" - " + _active_dir) : "") + "):");
    
    draw_set_color(_pal.text_secondary);
    draw_text(476, 348, "Frame Count (1..64):");
    var _new_fc = render_ui_number_field("sp_clip_fc", 476, 372, 624, 410, _clip.frame_count, 1, 64, false);
    if (_new_fc != _clip.frame_count) {
        _clip.frame_count = _new_fc;
        sys_sprite_normalize_clip(_clip, _clip.frames, _clip.fps, _clip.loop);
        _ed.sprite_frame_idx = clamp(_ed.sprite_frame_idx, 0, _clip.frame_count - 1);
        global.project_dirty = true;
    }
    
    if (render_ui_button(636, 372, 772, 410, "+ Add Frame", false, _clip.frame_count < 64)) {
        _clip.frame_count++;
        sys_sprite_normalize_clip(_clip, _clip.frames, _clip.fps, _clip.loop);
        _ed.sprite_frame_idx = _clip.frame_count - 1;
        global.project_dirty = true;
    }
    if (render_ui_button(782, 372, 932, 410, "- Remove Frame", false, _clip.frame_count > 1)) {
        var _rem_i = clamp(_ed.sprite_frame_idx, 0, _clip.frame_count - 1);
        array_delete(_clip.frames, _rem_i, 1);
        array_delete(_clip.frame_files, _rem_i, 1);
        _clip.frame_count = max(1, _clip.frame_count - 1);
        sys_sprite_normalize_clip(_clip, _clip.frames, _clip.fps, _clip.loop);
        _ed.sprite_frame_idx = clamp(_ed.sprite_frame_idx, 0, _clip.frame_count - 1);
        global.project_dirty = true;
    }
    
    draw_set_color(_pal.text_secondary);
    draw_text(948, 348, "FPS (1..60):");
    var _new_fps = render_ui_number_field("sp_clip_fps", 948, 372, 1052, 410, _clip.fps, 1, 60, false);
    if (_new_fps != _clip.fps) {
        _clip.fps = _new_fps;
        _st_obj.fps = _new_fps;
        global.project_dirty = true;
    }
    
    if (render_ui_button(1062, 372, 1164, 410, _clip.loop ? "Loop: ON" : "Loop: OFF", _clip.loop, true)) {
        _clip.loop = !_clip.loop;
        _st_obj.loop = _clip.loop;
        global.project_dirty = true;
    }
    
    // Step 4: Upload Sprites / Frames Directly Into This Specific Animation & Direction
    draw_set_color(_pal.accent_cyan);
    draw_text(476, 428, "4. IMPORT SPRITES INTO THIS ANIMATION (" + _active_state + " - " + _active_dir + "):");
    
    if (render_ui_button(476, 456, 812, 496, "Import Frames (Strip PNG) Into " + _active_state + " " + _active_dir, false, true)) {
        editor_sprites_import_into_clip(_clip, _active_state, _active_dir, 0);
    }
    if (render_ui_button(824, 456, 1164, 496, "+ Import & Append Frame PNG...", false, true)) {
        editor_sprites_import_into_clip(_clip, _active_state, _active_dir, 1);
    }
    
    if (render_ui_button(476, 506, 812, 546, "Replace Selected Frame #" + string(_ed.sprite_frame_idx + 1) + " PNG...", false, true)) {
        editor_sprites_import_into_clip(_clip, _active_state, _active_dir, 2);
    }
    if (render_ui_button(824, 506, 1164, 546, "Clear Custom PNGs For " + _active_state + " " + _active_dir, false, sys_sprite_clip_has_custom_assets(_clip))) {
        _clip.file_path = "";
        _clip.frame_files = array_create(_clip.frame_count, "");
        global.project_dirty = true;
        core_log_toast("Cleared custom PNGs for " + _active_state + " (" + _active_dir + ").");
    }
    
    // Status summary of current clip asset source
    var _src_info = "Using 4-Way Procedural / Fallback Sprite";
    if (_clip.frame_files[_ed.sprite_frame_idx] != "") {
        _src_info = "Frame #" + string(_ed.sprite_frame_idx + 1) + " File: " + _clip.frame_files[_ed.sprite_frame_idx];
    } else if (_clip.file_path != "") {
        _src_info = "Strip File: " + _clip.file_path;
    }
    draw_set_color(_pal.text_secondary);
    draw_text(476, 562, render_fit_text("Active Source: " + _src_info, 680));
    draw_text(476, 588, "Note: Importing into one animation/direction never overwrites other animations.");
    
    var _done_lbl = (_ed.return_modal != EDITOR_MODAL.NONE) ? "Back to Inspector (Esc)" : "Done (Esc)";
    if (render_ui_button(920, 628, 1164, 668, _done_lbl, true, true)) {
        input_end_text_edit();
        if (_ed.return_modal != EDITOR_MODAL.NONE) {
            _ed.active_modal = _ed.return_modal;
            _ed.return_modal = EDITOR_MODAL.NONE;
        } else {
            _ed.active_modal = EDITOR_MODAL.NONE;
        }
    }
}
