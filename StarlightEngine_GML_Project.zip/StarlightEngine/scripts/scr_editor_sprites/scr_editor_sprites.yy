{
  "$GMScript": "v1",
  "%Name": "scr_editor_sprites",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_editor_sprites",
  "parent": {
    "name": "Editor",
    "path": "folders/Engine/Editor.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}