# ST★RLIGHT ENGINE — Architecture Specification & Development Roadmap

**A 16-bit EarthBound & Undertale-Inspired 2D RPG Creation Engine in GameMaker (GML)**

---

## 1. Architectural Overview

**ST★RLIGHT ENGINE** is built from scratch using a strict separation between the **Engine Core/Systems/Editor** (compiled GML scripts, objects, and rooms) and **User RPG Projects** (external data-driven JSON manifests and assets stored per project in `Projects/<project_id>/`).

Zero game-specific content is hardcoded into the engine runtime. Every map, tileset, sprite animation, audio asset, playable character, party member, item, NPC, interactable object, enemy, dialogue tree, event script, and variable belongs strictly to the loaded project data structure.

### Directory & Resource Hierarchy

```text
StarlightEngine/
├── StarlightEngine.yyp                 # GameMaker Project Manifest
├── ARCHITECTURE_AND_ROADMAP.md         # Architecture & System Documentation
├── options/
│   ├── main/options_main.yy            # Global GameMaker Options
│   └── windows/options_windows.yy      # Windows Target Options (1280x720 base, resizable)
├── rooms/
│   └── rm_starlight_boot/              # Single persistent host room managed by Scene System
├── objects/
│   ├── obj_engine_controller/          # Master persistent lifecycle, input, scene, & UI manager
│   ├── obj_runtime_world/              # Playable RPG runtime controller (maps, camera, entities, menus)
│   ├── obj_battle_controller/          # EarthBound-inspired turn-based battle runtime controller
│   └── obj_editor_controller/          # All-in-one visual RPG editor & database manager controller
├── scripts/
│   ├── scr_core_init/                  # [Engine/Core] Bootstrapping, global state, directory setup
│   ├── scr_core_config/                # [Engine/Core] Engine settings, scaling, resolution, keybinds
│   ├── scr_core_input/                 # [Engine/Core] Debounced keyboard/mouse input & modal isolation
│   ├── scr_core_render/                # [Engine/Core] Pixel-art UI windows, starfield, text & clipping
│   ├── scr_core_camera/                # [Engine/Core] Independent Editor & Gameplay camera controllers
│   ├── scr_core_scene/                 # [Engine/Core] Scene state machine & modal dialog stack
│   ├── scr_core_audio/                 # [Engine/Core] OGG stream manager, SFX, loop, fade, fallback
│   ├── scr_core_assets/                # [Engine/Core] Dynamic PNG sprite loader, tileset slicer, fallback
│   ├── scr_core_saveload/              # [Engine/Core] Project I/O, .slproj import/export, multi-slot saves
│   ├── scr_core_error/                 # [Engine/Core] Non-fatal error handler, validator, toast notifications
│   ├── scr_sys_dialogue/               # [Engine/Systems] Dialogue tree interpreter, choices, typewriter UI
│   ├── scr_sys_events/                 # [Engine/Systems] Event Command Database & frame-safe interpreter
│   ├── scr_sys_characters/             # [Engine/Systems] Character definitions, stats, equipment, abilities
│   ├── scr_sys_party/                  # [Engine/Systems] Active party management, formation, healing
│   ├── scr_sys_inventory/              # [Engine/Systems] Item definitions, stack management, usage logic
│   ├── scr_sys_enemies/                # [Engine/Systems] Overworld enemy AI (6 modes), respawn, contact battle
│   ├── scr_sys_battle/                 # [Engine/Systems] Turn-based combat engine, rolling HP, AI, rewards
│   ├── scr_sys_leveling/               # [Engine/Systems] Configurable EXP curves, level-up stat & skill gains
│   ├── scr_sys_variables/              # [Engine/Systems] Persistent Boolean/Int/Real/String variable store
│   ├── scr_sys_quests/                 # [Engine/Systems] Quest log, stages, conditions, reward hooks
│   ├── scr_sys_stats/                  # [Engine/Systems] Runtime telemetry, playtime, effective stat formulas
│   ├── scr_sys_transitions/            # [Engine/Systems] Map loading, fade transitions, entity instantiation
│   ├── scr_sys_menus/                  # [Engine/Systems] Playable runtime menus (Party, Items, Stats, Save)
│   ├── scr_editor_main/                # [Engine/Editor] Editor shell, toolbar, Undo/Redo stack, Z mode toggle
│   ├── scr_editor_map/                 # [Engine/Editor] Map canvas, grid snap, zoom, layers, resize/create
│   ├── scr_editor_collision/           # [Engine/Editor] Collision grid painting & configurable overlay
│   ├── scr_editor_tiles/               # [Engine/Editor] Tile palette, PNG import, multi-layer paint/replace
│   ├── scr_editor_events/              # [Engine/Editor] Visual Event Editor & command parameter builder
│   ├── scr_editor_objects/             # [Engine/Editor] Interactable Object Editor (chests, signs, doors)
│   ├── scr_editor_npcs/                # [Engine/Editor] NPC Editor (identity, dialogue trees, 4 movement modes)
│   ├── scr_editor_enemies/             # [Engine/Editor] Enemy Editor (overworld AI, battle stats, drops)
│   ├── scr_editor_characters/          # [Engine/Editor] Character Manager (stats, EXP curves, abilities, gear)
│   ├── scr_editor_variables/           # [Engine/Editor] Variable Manager (CRUD, types, defaults, descriptions)
│   ├── scr_editor_audio/               # [Engine/Editor] Audio Manager (OGG import, preview, loop, map assign)
│   ├── scr_editor_sprites/             # [Engine/Editor] Sprite Manager (PNG import, 6 animation states, preview)
│   ├── scr_editor_items/               # [Engine/Editor] Item Manager (categories, effects, prices, stacks)
│   └── scr_editor_project/             # [Engine/Editor] Project Manager (F1 modal, Playtest, Save, Export)
├── sprites/
│   └── spr_pixel_fallback/             # 16x16 procedural fallback base sprite
├── fonts/
│   ├── fnt_starlight_title/            # Pixel-art display font (24pt)
│   ├── fnt_starlight_ui/               # Clean readable pixel UI font (12pt)
│   └── fnt_starlight_small/            # Compact inspector/label pixel font (9pt)
└── datafiles/
    └── Projects/
        └── starfall_demo/              # Complete regression-test Demo RPG ("Starfall Valley")
            ├── project.json            # Master project manifest & databases
            ├── maps/
            │   ├── map_hometown.json   # Connected Map 1: Onett Outskirts
            │   └── map_star_cave.json  # Connected Map 2: Starlight Cavern
            ├── tilesets/               # Project tileset PNGs & metadata
            ├── sprites/                # Project character/NPC/enemy/object PNGs
            ├── audio/                  # Project OGG music & SFX
            └── saves/                  # Player save slots (save_slot_1.json, etc.)
```

---

## 2. Eight-Phase Development Roadmap

### PHASE 1 — Engine Foundation
- Fresh GameMaker project structure (`StarlightEngine.yyp` and modular scripts).
- Engine initialization (`scr_core_init`), configuration (`scr_core_config`), error handler (`scr_core_error`), and debounced input manager (`scr_core_input`).
- Visually appealing **Main Menu** featuring a looping multi-layer parallax night-sky starfield, upper-left `ST★RLIGHT ENGINE` pixel header, and keyboard/mouse navigable buttons (`Projects`, `Settings`, `Credits`, `Exit`).
- **Projects Menu** (`New Project` wizard, `Saved Projects` scrollable list with `Play`, `Edit`, and confirmed `Delete`, `Import Project` via native file dialog `get_open_filename`, and `Back`).
- Initial RPG Editor shell, independent WASD map camera, map rendering, and collision grid foundation.

### PHASE 2 — Map Editing
- **Tile Manager & Selection Menu** (right-click Tiles toolbar button, custom PNG tileset upload, multi-tile selection, preview, paint, erase, flood replace).
- **Visual Layers** (`Background`, `Ground`, `Decorations`, `Foreground` rendering above characters, per-layer visibility & lock controls).
- **Collision Editor** (independent blocking grid, configurable editor overlay hidden during gameplay).
- **Editor Precision Controls** (configurable grid snap, smooth zoom `0.5x`–`4.0x`, `Z` key Place/Erase toggle, `Ctrl+Z` Undo / `Ctrl+Y` Redo command history, Map Creation/Deletion/Resizing).

### PHASE 3 — Characters and Entities
- **Sprite Manager** (`scr_editor_sprites`): PNG import, animation builder supporting `Idle`, `Walking`, `Running`, `Attacking`, `Taking Damage`, and `Defeated` animations with FPS & loop settings.
- **Character Manager** (`scr_editor_characters`): Playable heroes, portraits, stats, leveling curves, abilities, and equipment slots.
- **Object Editor** (`scr_editor_objects`): Stationary interactables (signs, books, doors, chests, furniture) with dialogue trees, YES/NO prompts, and embedded event triggers.
- **NPC Editor** (`scr_editor_npcs`): Identity, portraits, dialogue trees, variable visibility/interaction conditions, and 4 movement behaviors (`Stay Still`, `Wander Within Radius`, `Scripted Movement Path`, `Repeatable Scripted Movement Path`).
- **Enemy Editor** (`scr_editor_enemies`): Overworld & battle sprites, stats, 6 overworld AI behaviors (`Chase Player`, `Run Away`, `Ignore`, `Stop When Nearby`, `Stay Still`, `Wander`), battle skills, rewards, and defeat persistence rules.

### PHASE 4 — Events and Dialogue
- **Event Editor** (`scr_editor_events`): Map trigger placement, sizing, activation modes (`Automatic`, `Player Interaction`, `Conditional`, `One-Time`, `Repeatable`), and visual command list manipulation.
- **Event Command Database** (`scr_sys_events`): All 32+ commands across Party, Inventory, Audio, Variable, Character, Map, Dialogue, and Other categories, with frame-budget execution guards against infinite loops.
- **Variable Manager** (`scr_editor_variables`, `scr_sys_variables`): Boolean (`TRUE`/`FALSE`), Integer, Decimal, and String variables with descriptions and conditional evaluation.
- **Dialogue Tree System** (`scr_sys_dialogue`): Multi-node dialogue sequences, branching player choices, YES/NO prompts, conditional nodes, one-time vs repeat dialogue, and choice-triggered events.

### PHASE 5 — RPG Systems
- **Party & Character Systems** (`scr_sys_party`, `scr_sys_characters`): Active party roster, stat computation, equipment bonuses.
- **Experience & Leveling System** (`scr_sys_leveling`): Per-character EXP curves, automatic level-up stat increases, and level-gated ability unlocking.
- **Item Manager & Inventory System** (`scr_editor_items`, `scr_sys_inventory`): Consumables, Healing items, Weapons, Armor, Accessories, and Key Items with stack limits, field/battle usage, and custom event hooks.
- **Audio Manager & Engine** (`scr_editor_audio`, `scr_core_audio`): OGG music & SFX import, preview, volume, looping, map-assigned BGM, and crash-proof missing-audio handling.

### PHASE 6 — Battle System
- **EarthBound-Inspired Turn-Based Battle Engine** (`scr_sys_battle`, `obj_battle_controller`):
  - Animated psychedelic/geometric battle background & party status cards with rolling HP counters.
  - Commands: `Attack`, `Abilities`, `Items`, `Defend`, `Run`.
  - Configurable combat formulas (Attack, Defense, Speed, Critical Hits, Healing, Status Effects, Weaknesses, Resistances).
  - Configurable Enemy AI action weights & targeting.
  - Victory screen distributing EXP, Gold, Items, triggering post-battle events, and applying enemy defeat rules.
  - Customizable party defeat handling (Game Over screen, respawn at checkpoint map, or custom event).

### PHASE 7 — Gameplay and Persistence
- **Complete Playable Runtime** (`obj_runtime_world`, `scr_sys_menus`): Editor UI hidden, WASD/Arrow movement, collision & boundary detection, entity interaction (`E`/`Z`/`Enter`), smooth map transitions, and in-game menu (`Party`, `Inventory`, `Statistics`, `Save/Load`, `Settings`).
- **Save & Load System** (`scr_core_saveload`): Multi-slot JSON saves with schema versioning, storing current map, player position, party stats/EXP/levels, inventory, gold, variables, defeated enemy states, playtime, and timestamp.
- **Playtest Mode**: Instant in-memory snapshot launch from the editor (`F1` -> `Playtest`) without overwriting disk files, with one-key return to the exact editor state.

### PHASE 8 — Project Management, Demo RPG, and Verification
- **Project Manager (`F1`)** (`scr_editor_project`): Edit project metadata, Starting Map, Starting Character, Playtest, Save Project, Export portable `.slproj` bundle, Save & Exit with dirty-state protection.
- **Demo Project (`starfall_demo`)**: Complete 2-map playable demo RPG exercising every engine feature without a single line of hardcoded demo logic.
- **Automated Verification Suite**: Static & structural verification script checking all `.yyp`/`.yy` links, GML syntax/function integrity, event command handlers, and Demo RPG data schemas.
