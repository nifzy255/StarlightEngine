{
  "$GMFont": "",
  "%Name": "fnt_starlight_title",
  "AntiAlias": 0,
  "applyKerning": 0,
  "ascender": 26,
  "ascenderOffset": 0,
  "bold": true,
  "canGenerateBitmap": true,
  "charset": 0,
  "first": 0,
  "fontName": "Consolas",
  "glyphOperations": 0,
  "glyphs": {
    "32": {
      "character": 32,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 4,
      "y": 4
    },
    "33": {
      "character": 33,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 29,
      "y": 4
    },
    "34": {
      "character": 34,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 54,
      "y": 4
    },
    "35": {
      "character": 35,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 79,
      "y": 4
    },
    "36": {
      "character": 36,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 105,
      "y": 4
    },
    "37": {
      "character": 37,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 130,
      "y": 4
    },
    "38": {
      "character": 38,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 156,
      "y": 4
    },
    "39": {
      "character": 39,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 182,
      "y": 4
    },
    "40": {
      "character": 40,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 207,
      "y": 4
    },
    "41": {
      "character": 41,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 232,
      "y": 4
    },
    "42": {
      "character": 42,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 257,
      "y": 4
    },
    "43": {
      "character": 43,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 282,
      "y": 4
    },
    "44": {
      "character": 44,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 307,
      "y": 4
    },
    "45": {
      "character": 45,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 332,
      "y": 4
    },
    "46": {
      "character": 46,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 357,
      "y": 4
    },
    "47": {
      "character": 47,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 382,
      "y": 4
    },
    "48": {
      "character": 48,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 407,
      "y": 4
    },
    "49": {
      "character": 49,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 432,
      "y": 4
    },
    "50": {
      "character": 50,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 457,
      "y": 4
    },
    "51": {
      "character": 51,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 482,
      "y": 4
    },
    "52": {
      "character": 52,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 507,
      "y": 4
    },
    "53": {
      "character": 53,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 532,
      "y": 4
    },
    "54": {
      "character": 54,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 557,
      "y": 4
    },
    "55": {
      "character": 55,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 582,
      "y": 4
    },
    "56": {
      "character": 56,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 607,
      "y": 4
    },
    "57": {
      "character": 57,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 632,
      "y": 4
    },
    "58": {
      "character": 58,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 657,
      "y": 4
    },
    "59": {
      "character": 59,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 682,
      "y": 4
    },
    "60": {
      "character": 60,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 707,
      "y": 4
    },
    "61": {
      "character": 61,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 732,
      "y": 4
    },
    "62": {
      "character": 62,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 757,
      "y": 4
    },
    "63": {
      "character": 63,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 782,
      "y": 4
    },
    "64": {
      "character": 64,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 807,
      "y": 4
    },
    "65": {
      "character": 65,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 832,
      "y": 4
    },
    "66": {
      "character": 66,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 857,
      "y": 4
    },
    "67": {
      "character": 67,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 882,
      "y": 4
    },
    "68": {
      "character": 68,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 907,
      "y": 4
    },
    "69": {
      "character": 69,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 932,
      "y": 4
    },
    "70": {
      "character": 70,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 957,
      "y": 4
    },
    "71": {
      "character": 71,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 982,
      "y": 4
    },
    "72": {
      "character": 72,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 4,
      "y": 42
    },
    "73": {
      "character": 73,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 29,
      "y": 42
    },
    "74": {
      "character": 74,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 54,
      "y": 42
    },
    "75": {
      "character": 75,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 79,
      "y": 42
    },
    "76": {
      "character": 76,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 105,
      "y": 42
    },
    "77": {
      "character": 77,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 130,
      "y": 42
    },
    "78": {
      "character": 78,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 155,
      "y": 42
    },
    "79": {
      "character": 79,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 180,
      "y": 42
    },
    "80": {
      "character": 80,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 205,
      "y": 42
    },
    "81": {
      "character": 81,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 230,
      "y": 42
    },
    "82": {
      "character": 82,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 255,
      "y": 42
    },
    "83": {
      "character": 83,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 281,
      "y": 42
    },
    "84": {
      "character": 84,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 306,
      "y": 42
    },
    "85": {
      "character": 85,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 331,
      "y": 42
    },
    "86": {
      "character": 86,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 356,
      "y": 42
    },
    "87": {
      "character": 87,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 381,
      "y": 42
    },
    "88": {
      "character": 88,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 407,
      "y": 42
    },
    "89": {
      "character": 89,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 433,
      "y": 42
    },
    "90": {
      "character": 90,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 459,
      "y": 42
    },
    "91": {
      "character": 91,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 484,
      "y": 42
    },
    "92": {
      "character": 92,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 509,
      "y": 42
    },
    "93": {
      "character": 93,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 534,
      "y": 42
    },
    "94": {
      "character": 94,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 559,
      "y": 42
    },
    "95": {
      "character": 95,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 584,
      "y": 42
    },
    "96": {
      "character": 96,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 610,
      "y": 42
    },
    "97": {
      "character": 97,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 635,
      "y": 42
    },
    "98": {
      "character": 98,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 660,
      "y": 42
    },
    "99": {
      "character": 99,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 685,
      "y": 42
    },
    "100": {
      "character": 100,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 710,
      "y": 42
    },
    "101": {
      "character": 101,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 735,
      "y": 42
    },
    "102": {
      "character": 102,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 760,
      "y": 42
    },
    "103": {
      "character": 103,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 785,
      "y": 42
    },
    "104": {
      "character": 104,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 810,
      "y": 42
    },
    "105": {
      "character": 105,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 835,
      "y": 42
    },
    "106": {
      "character": 106,
      "h": 34,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 860,
      "y": 42
    },
    "107": {
      "character": 107,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 885,
      "y": 42
    },
    "108": {
      "character": 108,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 910,
      "y": 42
    },
    "109": {
      "character": 109,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 935,
      "y": 42
    },
    "110": {
      "character": 110,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 960,
      "y": 42
    },
    "111": {
      "character": 111,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 985,
      "y": 42
    },
    "112": {
      "character": 112,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 4,
      "y": 82
    },
    "113": {
      "character": 113,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 29,
      "y": 82
    },
    "114": {
      "character": 114,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 54,
      "y": 82
    },
    "115": {
      "character": 115,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 79,
      "y": 82
    },
    "116": {
      "character": 116,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 104,
      "y": 82
    },
    "117": {
      "character": 117,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 129,
      "y": 82
    },
    "118": {
      "character": 118,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 154,
      "y": 82
    },
    "119": {
      "character": 119,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 179,
      "y": 82
    },
    "120": {
      "character": 120,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 205,
      "y": 82
    },
    "121": {
      "character": 121,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 230,
      "y": 82
    },
    "122": {
      "character": 122,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 255,
      "y": 82
    },
    "123": {
      "character": 123,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 280,
      "y": 82
    },
    "124": {
      "character": 124,
      "h": 33,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 305,
      "y": 82
    },
    "125": {
      "character": 125,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 330,
      "y": 82
    },
    "126": {
      "character": 126,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 355,
      "y": 82
    },
    "8212": {
      "character": 8212,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 380,
      "y": 82
    },
    "8226": {
      "character": 8226,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 406,
      "y": 82
    },
    "9650": {
      "character": 9650,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 431,
      "y": 82
    },
    "9654": {
      "character": 9654,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 457,
      "y": 82
    },
    "9660": {
      "character": 9660,
      "h": 32,
      "offset": 0,
      "shift": 20,
      "w": 20,
      "x": 483,
      "y": 82
    },
    "9733": {
      "character": 9733,
      "h": 32,
      "offset": 0,
      "shift": 19,
      "w": 19,
      "x": 509,
      "y": 82
    }
  },
  "hinting": 0,
  "includeTTF": false,
  "interpreter": 0,
  "italic": false,
  "kerningPairs": [],
  "last": 0,
  "lineHeight": 39,
  "maintainGms1Font": false,
  "name": "fnt_starlight_title",
  "parent": {
    "name": "Fonts",
    "path": "folders/Engine/Fonts.yy"
  },
  "pointRounding": 0,
  "ranges": [
    {
      "lower": 32,
      "upper": 126
    },
    {
      "lower": 8212,
      "upper": 8226
    },
    {
      "lower": 9650,
      "upper": 9733
    }
  ],
  "regenerateBitmap": false,
  "resourceType": "GMFont",
  "resourceVersion": "2.0",
  "sampleText": "abcdef ABCDEF\n0123456789 .,<>\"'&!?\nthe quick brown fox jumps over the lazy dog\nTHE QUICK BROWN FOX JUMPS OVER THE LAZY DOG\nDefault character: \u25af (9647)",
  "sdfSpread": 8,
  "size": 26.0,
  "styleName": "Bold",
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "TTFName": "",
  "usesSDF": false
}