{
  "$GMFont": "",
  "%Name": "fnt_starlight_small",
  "AntiAlias": 0,
  "applyKerning": 0,
  "ascender": 13,
  "ascenderOffset": 0,
  "bold": false,
  "canGenerateBitmap": true,
  "charset": 0,
  "first": 0,
  "fontName": "Consolas",
  "glyphOperations": 0,
  "glyphs": {
    "32": {
      "character": 32,
      "h": 16,
      "offset": 0,
      "shift": 7,
      "w": 7,
      "x": 4,
      "y": 4
    },
    "33": {
      "character": 33,
      "h": 16,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 17,
      "y": 4
    },
    "34": {
      "character": 34,
      "h": 16,
      "offset": 0,
      "shift": 9,
      "w": 9,
      "x": 31,
      "y": 4
    },
    "35": {
      "character": 35,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 46,
      "y": 4
    },
    "36": {
      "character": 36,
      "h": 17,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 66,
      "y": 4
    },
    "37": {
      "character": 37,
      "h": 16,
      "offset": 0,
      "shift": 16,
      "w": 16,
      "x": 84,
      "y": 4
    },
    "38": {
      "character": 38,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 106,
      "y": 4
    },
    "39": {
      "character": 39,
      "h": 16,
      "offset": 0,
      "shift": 6,
      "w": 6,
      "x": 126,
      "y": 4
    },
    "40": {
      "character": 40,
      "h": 16,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 138,
      "y": 4
    },
    "41": {
      "character": 41,
      "h": 16,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 152,
      "y": 4
    },
    "42": {
      "character": 42,
      "h": 16,
      "offset": 0,
      "shift": 10,
      "w": 10,
      "x": 166,
      "y": 4
    },
    "43": {
      "character": 43,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 182,
      "y": 4
    },
    "44": {
      "character": 44,
      "h": 16,
      "offset": 0,
      "shift": 7,
      "w": 7,
      "x": 202,
      "y": 4
    },
    "45": {
      "character": 45,
      "h": 16,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 215,
      "y": 4
    },
    "46": {
      "character": 46,
      "h": 16,
      "offset": 0,
      "shift": 7,
      "w": 7,
      "x": 229,
      "y": 4
    },
    "47": {
      "character": 47,
      "h": 16,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 242,
      "y": 4
    },
    "48": {
      "character": 48,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 256,
      "y": 4
    },
    "49": {
      "character": 49,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 274,
      "y": 4
    },
    "50": {
      "character": 50,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 292,
      "y": 4
    },
    "51": {
      "character": 51,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 310,
      "y": 4
    },
    "52": {
      "character": 52,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 328,
      "y": 4
    },
    "53": {
      "character": 53,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 346,
      "y": 4
    },
    "54": {
      "character": 54,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 364,
      "y": 4
    },
    "55": {
      "character": 55,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 382,
      "y": 4
    },
    "56": {
      "character": 56,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 400,
      "y": 4
    },
    "57": {
      "character": 57,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 418,
      "y": 4
    },
    "58": {
      "character": 58,
      "h": 16,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 436,
      "y": 4
    },
    "59": {
      "character": 59,
      "h": 16,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 450,
      "y": 4
    },
    "60": {
      "character": 60,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 464,
      "y": 4
    },
    "61": {
      "character": 61,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 484,
      "y": 4
    },
    "62": {
      "character": 62,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 504,
      "y": 4
    },
    "63": {
      "character": 63,
      "h": 16,
      "offset": 0,
      "shift": 10,
      "w": 10,
      "x": 524,
      "y": 4
    },
    "64": {
      "character": 64,
      "h": 16,
      "offset": 0,
      "shift": 16,
      "w": 16,
      "x": 540,
      "y": 4
    },
    "65": {
      "character": 65,
      "h": 16,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 562,
      "y": 4
    },
    "66": {
      "character": 66,
      "h": 16,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 581,
      "y": 4
    },
    "67": {
      "character": 67,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 600,
      "y": 4
    },
    "68": {
      "character": 68,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 618,
      "y": 4
    },
    "69": {
      "character": 69,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 638,
      "y": 4
    },
    "70": {
      "character": 70,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 656,
      "y": 4
    },
    "71": {
      "character": 71,
      "h": 16,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 674,
      "y": 4
    },
    "72": {
      "character": 72,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 693,
      "y": 4
    },
    "73": {
      "character": 73,
      "h": 16,
      "offset": 0,
      "shift": 7,
      "w": 7,
      "x": 713,
      "y": 4
    },
    "74": {
      "character": 74,
      "h": 17,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 726,
      "y": 4
    },
    "75": {
      "character": 75,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 740,
      "y": 4
    },
    "76": {
      "character": 76,
      "h": 16,
      "offset": 0,
      "shift": 11,
      "w": 11,
      "x": 760,
      "y": 4
    },
    "77": {
      "character": 77,
      "h": 16,
      "offset": 0,
      "shift": 16,
      "w": 16,
      "x": 777,
      "y": 4
    },
    "78": {
      "character": 78,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 799,
      "y": 4
    },
    "79": {
      "character": 79,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 819,
      "y": 4
    },
    "80": {
      "character": 80,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 839,
      "y": 4
    },
    "81": {
      "character": 81,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 857,
      "y": 4
    },
    "82": {
      "character": 82,
      "h": 16,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 877,
      "y": 4
    },
    "83": {
      "character": 83,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 896,
      "y": 4
    },
    "84": {
      "character": 84,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 914,
      "y": 4
    },
    "85": {
      "character": 85,
      "h": 16,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 932,
      "y": 4
    },
    "86": {
      "character": 86,
      "h": 16,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 951,
      "y": 4
    },
    "87": {
      "character": 87,
      "h": 16,
      "offset": 0,
      "shift": 17,
      "w": 17,
      "x": 970,
      "y": 4
    },
    "88": {
      "character": 88,
      "h": 16,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 993,
      "y": 4
    },
    "89": {
      "character": 89,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 4,
      "y": 27
    },
    "90": {
      "character": 90,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 24,
      "y": 27
    },
    "91": {
      "character": 91,
      "h": 16,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 42,
      "y": 27
    },
    "92": {
      "character": 92,
      "h": 16,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 56,
      "y": 27
    },
    "93": {
      "character": 93,
      "h": 16,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 70,
      "y": 27
    },
    "94": {
      "character": 94,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 84,
      "y": 27
    },
    "95": {
      "character": 95,
      "h": 16,
      "offset": 0,
      "shift": 9,
      "w": 9,
      "x": 104,
      "y": 27
    },
    "96": {
      "character": 96,
      "h": 16,
      "offset": 0,
      "shift": 9,
      "w": 9,
      "x": 119,
      "y": 27
    },
    "97": {
      "character": 97,
      "h": 16,
      "offset": 0,
      "shift": 11,
      "w": 11,
      "x": 134,
      "y": 27
    },
    "98": {
      "character": 98,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 151,
      "y": 27
    },
    "99": {
      "character": 99,
      "h": 16,
      "offset": 0,
      "shift": 10,
      "w": 10,
      "x": 169,
      "y": 27
    },
    "100": {
      "character": 100,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 185,
      "y": 27
    },
    "101": {
      "character": 101,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 203,
      "y": 27
    },
    "102": {
      "character": 102,
      "h": 16,
      "offset": 0,
      "shift": 9,
      "w": 9,
      "x": 221,
      "y": 27
    },
    "103": {
      "character": 103,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 236,
      "y": 27
    },
    "104": {
      "character": 104,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 254,
      "y": 27
    },
    "105": {
      "character": 105,
      "h": 16,
      "offset": 0,
      "shift": 7,
      "w": 7,
      "x": 272,
      "y": 27
    },
    "106": {
      "character": 106,
      "h": 18,
      "offset": 0,
      "shift": 8,
      "w": 8,
      "x": 285,
      "y": 27
    },
    "107": {
      "character": 107,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 299,
      "y": 27
    },
    "108": {
      "character": 108,
      "h": 16,
      "offset": 0,
      "shift": 7,
      "w": 7,
      "x": 317,
      "y": 27
    },
    "109": {
      "character": 109,
      "h": 16,
      "offset": 0,
      "shift": 17,
      "w": 17,
      "x": 330,
      "y": 27
    },
    "110": {
      "character": 110,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 353,
      "y": 27
    },
    "111": {
      "character": 111,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 371,
      "y": 27
    },
    "112": {
      "character": 112,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 389,
      "y": 27
    },
    "113": {
      "character": 113,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 407,
      "y": 27
    },
    "114": {
      "character": 114,
      "h": 16,
      "offset": 0,
      "shift": 9,
      "w": 9,
      "x": 425,
      "y": 27
    },
    "115": {
      "character": 115,
      "h": 16,
      "offset": 0,
      "shift": 10,
      "w": 10,
      "x": 440,
      "y": 27
    },
    "116": {
      "character": 116,
      "h": 16,
      "offset": 0,
      "shift": 9,
      "w": 9,
      "x": 456,
      "y": 27
    },
    "117": {
      "character": 117,
      "h": 16,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 471,
      "y": 27
    },
    "118": {
      "character": 118,
      "h": 16,
      "offset": 0,
      "shift": 11,
      "w": 11,
      "x": 489,
      "y": 27
    },
    "119": {
      "character": 119,
      "h": 16,
      "offset": 0,
      "shift": 15,
      "w": 15,
      "x": 506,
      "y": 27
    },
    "120": {
      "character": 120,
      "h": 16,
      "offset": 0,
      "shift": 11,
      "w": 11,
      "x": 527,
      "y": 27
    },
    "121": {
      "character": 121,
      "h": 16,
      "offset": 0,
      "shift": 11,
      "w": 11,
      "x": 544,
      "y": 27
    },
    "122": {
      "character": 122,
      "h": 16,
      "offset": 0,
      "shift": 10,
      "w": 10,
      "x": 561,
      "y": 27
    },
    "123": {
      "character": 123,
      "h": 17,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 577,
      "y": 27
    },
    "124": {
      "character": 124,
      "h": 18,
      "offset": 0,
      "shift": 7,
      "w": 7,
      "x": 595,
      "y": 27
    },
    "125": {
      "character": 125,
      "h": 17,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 608,
      "y": 27
    },
    "126": {
      "character": 126,
      "h": 16,
      "offset": 0,
      "shift": 14,
      "w": 14,
      "x": 626,
      "y": 27
    },
    "8212": {
      "character": 8212,
      "h": 16,
      "offset": 0,
      "shift": 16,
      "w": 16,
      "x": 646,
      "y": 27
    },
    "8226": {
      "character": 8226,
      "h": 16,
      "offset": 0,
      "shift": 11,
      "w": 11,
      "x": 668,
      "y": 27
    },
    "9650": {
      "character": 9650,
      "h": 16,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 685,
      "y": 27
    },
    "9654": {
      "character": 9654,
      "h": 16,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 704,
      "y": 27
    },
    "9660": {
      "character": 9660,
      "h": 16,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 723,
      "y": 27
    },
    "9733": {
      "character": 9733,
      "h": 16,
      "offset": 0,
      "shift": 15,
      "w": 15,
      "x": 742,
      "y": 27
    }
  },
  "hinting": 0,
  "includeTTF": false,
  "interpreter": 0,
  "italic": false,
  "kerningPairs": [],
  "last": 0,
  "lineHeight": 20,
  "maintainGms1Font": false,
  "name": "fnt_starlight_small",
  "parent": {
    "name": "Fonts",
    "path": "folders/Engine/Fonts.yy"
  },
  "pointRounding": 0,
  "ranges": [
    {
      "lower": 32,
      "upper": 126
    },
    {
      "lower": 8212,
      "upper": 8226
    },
    {
      "lower": 9650,
      "upper": 9733
    }
  ],
  "regenerateBitmap": false,
  "resourceType": "GMFont",
  "resourceVersion": "2.0",
  "sampleText": "abcdef ABCDEF\n0123456789 .,<>\"'&!?\nthe quick brown fox jumps over the lazy dog\nTHE QUICK BROWN FOX JUMPS OVER THE LAZY DOG\nDefault character: \u25af (9647)",
  "sdfSpread": 8,
  "size": 13.0,
  "styleName": "Regular",
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "TTFName": "",
  "usesSDF": false
}