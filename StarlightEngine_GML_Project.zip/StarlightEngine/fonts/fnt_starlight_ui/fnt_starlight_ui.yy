{
  "$GMFont": "",
  "%Name": "fnt_starlight_ui",
  "AntiAlias": 0,
  "applyKerning": 0,
  "ascender": 15,
  "ascenderOffset": 0,
  "bold": true,
  "canGenerateBitmap": true,
  "charset": 0,
  "first": 0,
  "fontName": "Consolas",
  "glyphOperations": 0,
  "glyphs": {
    "32": {
      "character": 32,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 4,
      "y": 4
    },
    "33": {
      "character": 33,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 22,
      "y": 4
    },
    "34": {
      "character": 34,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 40,
      "y": 4
    },
    "35": {
      "character": 35,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 58,
      "y": 4
    },
    "36": {
      "character": 36,
      "h": 20,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 77,
      "y": 4
    },
    "37": {
      "character": 37,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 95,
      "y": 4
    },
    "38": {
      "character": 38,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 114,
      "y": 4
    },
    "39": {
      "character": 39,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 133,
      "y": 4
    },
    "40": {
      "character": 40,
      "h": 19,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 151,
      "y": 4
    },
    "41": {
      "character": 41,
      "h": 19,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 169,
      "y": 4
    },
    "42": {
      "character": 42,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 187,
      "y": 4
    },
    "43": {
      "character": 43,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 205,
      "y": 4
    },
    "44": {
      "character": 44,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 223,
      "y": 4
    },
    "45": {
      "character": 45,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 241,
      "y": 4
    },
    "46": {
      "character": 46,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 259,
      "y": 4
    },
    "47": {
      "character": 47,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 277,
      "y": 4
    },
    "48": {
      "character": 48,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 295,
      "y": 4
    },
    "49": {
      "character": 49,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 313,
      "y": 4
    },
    "50": {
      "character": 50,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 331,
      "y": 4
    },
    "51": {
      "character": 51,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 349,
      "y": 4
    },
    "52": {
      "character": 52,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 367,
      "y": 4
    },
    "53": {
      "character": 53,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 385,
      "y": 4
    },
    "54": {
      "character": 54,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 403,
      "y": 4
    },
    "55": {
      "character": 55,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 421,
      "y": 4
    },
    "56": {
      "character": 56,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 439,
      "y": 4
    },
    "57": {
      "character": 57,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 457,
      "y": 4
    },
    "58": {
      "character": 58,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 475,
      "y": 4
    },
    "59": {
      "character": 59,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 493,
      "y": 4
    },
    "60": {
      "character": 60,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 511,
      "y": 4
    },
    "61": {
      "character": 61,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 529,
      "y": 4
    },
    "62": {
      "character": 62,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 547,
      "y": 4
    },
    "63": {
      "character": 63,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 565,
      "y": 4
    },
    "64": {
      "character": 64,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 583,
      "y": 4
    },
    "65": {
      "character": 65,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 601,
      "y": 4
    },
    "66": {
      "character": 66,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 619,
      "y": 4
    },
    "67": {
      "character": 67,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 637,
      "y": 4
    },
    "68": {
      "character": 68,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 655,
      "y": 4
    },
    "69": {
      "character": 69,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 673,
      "y": 4
    },
    "70": {
      "character": 70,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 691,
      "y": 4
    },
    "71": {
      "character": 71,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 709,
      "y": 4
    },
    "72": {
      "character": 72,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 727,
      "y": 4
    },
    "73": {
      "character": 73,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 745,
      "y": 4
    },
    "74": {
      "character": 74,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 763,
      "y": 4
    },
    "75": {
      "character": 75,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 781,
      "y": 4
    },
    "76": {
      "character": 76,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 800,
      "y": 4
    },
    "77": {
      "character": 77,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 818,
      "y": 4
    },
    "78": {
      "character": 78,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 836,
      "y": 4
    },
    "79": {
      "character": 79,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 854,
      "y": 4
    },
    "80": {
      "character": 80,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 872,
      "y": 4
    },
    "81": {
      "character": 81,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 890,
      "y": 4
    },
    "82": {
      "character": 82,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 908,
      "y": 4
    },
    "83": {
      "character": 83,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 927,
      "y": 4
    },
    "84": {
      "character": 84,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 945,
      "y": 4
    },
    "85": {
      "character": 85,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 963,
      "y": 4
    },
    "86": {
      "character": 86,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 981,
      "y": 4
    },
    "87": {
      "character": 87,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 999,
      "y": 4
    },
    "88": {
      "character": 88,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 4,
      "y": 30
    },
    "89": {
      "character": 89,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 23,
      "y": 30
    },
    "90": {
      "character": 90,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 42,
      "y": 30
    },
    "91": {
      "character": 91,
      "h": 19,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 60,
      "y": 30
    },
    "92": {
      "character": 92,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 78,
      "y": 30
    },
    "93": {
      "character": 93,
      "h": 19,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 96,
      "y": 30
    },
    "94": {
      "character": 94,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 114,
      "y": 30
    },
    "95": {
      "character": 95,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 132,
      "y": 30
    },
    "96": {
      "character": 96,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 151,
      "y": 30
    },
    "97": {
      "character": 97,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 169,
      "y": 30
    },
    "98": {
      "character": 98,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 187,
      "y": 30
    },
    "99": {
      "character": 99,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 205,
      "y": 30
    },
    "100": {
      "character": 100,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 223,
      "y": 30
    },
    "101": {
      "character": 101,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 241,
      "y": 30
    },
    "102": {
      "character": 102,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 259,
      "y": 30
    },
    "103": {
      "character": 103,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 277,
      "y": 30
    },
    "104": {
      "character": 104,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 295,
      "y": 30
    },
    "105": {
      "character": 105,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 313,
      "y": 30
    },
    "106": {
      "character": 106,
      "h": 22,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 331,
      "y": 30
    },
    "107": {
      "character": 107,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 349,
      "y": 30
    },
    "108": {
      "character": 108,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 367,
      "y": 30
    },
    "109": {
      "character": 109,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 385,
      "y": 30
    },
    "110": {
      "character": 110,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 403,
      "y": 30
    },
    "111": {
      "character": 111,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 421,
      "y": 30
    },
    "112": {
      "character": 112,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 439,
      "y": 30
    },
    "113": {
      "character": 113,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 457,
      "y": 30
    },
    "114": {
      "character": 114,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 475,
      "y": 30
    },
    "115": {
      "character": 115,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 493,
      "y": 30
    },
    "116": {
      "character": 116,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 511,
      "y": 30
    },
    "117": {
      "character": 117,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 529,
      "y": 30
    },
    "118": {
      "character": 118,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 547,
      "y": 30
    },
    "119": {
      "character": 119,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 565,
      "y": 30
    },
    "120": {
      "character": 120,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 584,
      "y": 30
    },
    "121": {
      "character": 121,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 602,
      "y": 30
    },
    "122": {
      "character": 122,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 620,
      "y": 30
    },
    "123": {
      "character": 123,
      "h": 20,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 638,
      "y": 30
    },
    "124": {
      "character": 124,
      "h": 21,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 656,
      "y": 30
    },
    "125": {
      "character": 125,
      "h": 20,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 674,
      "y": 30
    },
    "126": {
      "character": 126,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 692,
      "y": 30
    },
    "8212": {
      "character": 8212,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 710,
      "y": 30
    },
    "8226": {
      "character": 8226,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 729,
      "y": 30
    },
    "9650": {
      "character": 9650,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 747,
      "y": 30
    },
    "9654": {
      "character": 9654,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 766,
      "y": 30
    },
    "9660": {
      "character": 9660,
      "h": 18,
      "offset": 0,
      "shift": 13,
      "w": 13,
      "x": 785,
      "y": 30
    },
    "9733": {
      "character": 9733,
      "h": 18,
      "offset": 0,
      "shift": 12,
      "w": 12,
      "x": 804,
      "y": 30
    }
  },
  "hinting": 0,
  "includeTTF": false,
  "interpreter": 0,
  "italic": false,
  "kerningPairs": [],
  "last": 0,
  "lineHeight": 24,
  "maintainGms1Font": false,
  "name": "fnt_starlight_ui",
  "parent": {
    "name": "Fonts",
    "path": "folders/Engine/Fonts.yy"
  },
  "pointRounding": 0,
  "ranges": [
    {
      "lower": 32,
      "upper": 126
    },
    {
      "lower": 8212,
      "upper": 8226
    },
    {
      "lower": 9650,
      "upper": 9733
    }
  ],
  "regenerateBitmap": false,
  "resourceType": "GMFont",
  "resourceVersion": "2.0",
  "sampleText": "abcdef ABCDEF\n0123456789 .,<>\"'&!?\nthe quick brown fox jumps over the lazy dog\nTHE QUICK BROWN FOX JUMPS OVER THE LAZY DOG\nDefault character: \u25af (9647)",
  "sdfSpread": 8,
  "size": 15.0,
  "styleName": "Bold",
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "TTFName": "",
  "usesSDF": false
}